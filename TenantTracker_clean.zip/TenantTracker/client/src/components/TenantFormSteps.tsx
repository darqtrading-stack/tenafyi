import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { PropertySelector } from "./PropertySelector";
import { Check } from "lucide-react";
import type { InsertApplication } from "@shared/schema";
import { unifiedQuestions, getQuestionsByStep, getSubQuestions, Question, validateAnswer } from "@shared/questions";

interface TenantFormStepsProps {
  currentStep: number;
  formData: Partial<InsertApplication>;
  onFormDataChange: (data: Partial<InsertApplication>) => void;
  showValidationErrors?: boolean;
}

export function TenantFormSteps({ currentStep, formData, onFormDataChange, showValidationErrors = false }: TenantFormStepsProps) {
  const updateFormData = (field: keyof InsertApplication, value: any) => {
    onFormDataChange({ ...formData, [field]: value });
  };

  const renderQuestion = (question: Question) => {
    const fieldValue = formData[question.formField as keyof InsertApplication];
    const validation = validateAnswer(question, fieldValue);
    const hasError = showValidationErrors && question.required && !validation.isValid;
    
    // Special handling for property selection
    if (question.id === 'property') {
      return (
        <PropertySelector 
          key={question.id}
          value={fieldValue as string[] || []}
          onValueChange={(value) => updateFormData(question.formField as keyof InsertApplication, value)}
          multiple={true}
        />
      );
    }
    
    switch (question.type) {
      case 'text':
      case 'email':
      case 'tel':
      case 'number':
        return (
          <div key={question.id}>
            <Label htmlFor={question.id} className={`text-sm font-medium mb-2 block ${hasError ? 'text-red-600' : 'text-gray-700'}`}>
              {question.text} {question.required && <span className="text-red-500">*</span>}
            </Label>
            <Input
              id={question.id}
              type={question.type}
              value={fieldValue?.toString() || ""}
              onChange={(e) => {
                const value = question.type === 'number' ? 
                  (parseInt(e.target.value) || 0) : e.target.value;
                updateFormData(question.formField as keyof InsertApplication, value);
              }}
              placeholder={question.placeholder}
              min={question.validation?.min}
              max={question.validation?.max}
              className={`text-lg p-4 h-14 border-2 rounded-xl focus:border-blue-500 ${hasError ? 'border-red-500 bg-red-50' : 'border-gray-200'}`}
            />
            {hasError && (
              <p className="text-red-600 text-sm mt-1">{validation.message}</p>
            )}
          </div>
        );
      
      case 'textarea':
        return (
          <div key={question.id}>
            <Label htmlFor={question.id} className={`text-sm font-medium mb-2 block ${hasError ? 'text-red-600' : 'text-gray-700'}`}>
              {question.text} {question.required && <span className="text-red-500">*</span>}
            </Label>
            <Textarea
              id={question.id}
              value={fieldValue?.toString() || ""}
              onChange={(e) => updateFormData(question.formField as keyof InsertApplication, e.target.value)}
              placeholder={question.placeholder}
              className={`text-lg p-4 border-2 rounded-xl focus:border-blue-500 min-h-[120px] ${hasError ? 'border-red-500 bg-red-50' : 'border-gray-200'}`}
            />
            {hasError && (
              <p className="text-red-600 text-sm mt-1">{validation.message}</p>
            )}
          </div>
        );
      
      case 'select':
        if (question.options && question.options.length <= 3) {
          // Use simple button selection for 3 or fewer options
          return (
            <div key={question.id}>
              <Label className={`text-lg font-medium mb-4 block ${hasError ? 'text-red-600' : 'text-gray-800'}`}>
                {question.text} {question.required && <span className="text-red-500">*</span>}
              </Label>
              <div className="space-y-3">
                {question.options.map((option) => {
                  // Handle boolean field comparison properly
                  let isSelected = false;
                  if (question.formField === 'hasPets' || question.formField === 'smokes' || question.formField === 'hasTaxReturns') {
                    // For boolean fields, compare with converted values
                    const boolValue = (option === 'Yes' || option === 'yes');
                    isSelected = fieldValue === boolValue;
                  } else {
                    // For string fields, direct comparison
                    isSelected = fieldValue?.toString() === option;
                  }
                  return (
                    <button 
                      key={option} 
                      type="button"
                      className={`w-full p-5 border-2 rounded-xl cursor-pointer transition-all duration-200 text-left ${
                        isSelected 
                          ? 'border-blue-500 bg-blue-50 shadow-md' 
                          : hasError 
                            ? 'border-red-500 bg-red-50 hover:border-red-400'
                            : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50 bg-white'
                      }`}
                      onClick={() => {
                        // Boolean conversion only for specific boolean fields
                        const processedValue = question.formField === 'hasPets' || 
                                             question.formField === 'smokes' || 
                                             question.formField === 'hasTaxReturns' ?
                          (option === 'Yes' || option === 'yes') : option;
                        updateFormData(question.formField as keyof InsertApplication, processedValue);
                      }}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-6 h-6 rounded-full border-2 transition-all flex items-center justify-center ${
                          isSelected ? 'border-blue-500 bg-blue-500' : 'border-gray-300'
                        }`}>
                          {isSelected && (
                            <Check className="w-4 h-4 text-white" />
                          )}
                        </div>
                        <span className={`text-xl font-medium ${
                          isSelected ? 'text-blue-700' : 'text-gray-700'
                        }`}>
                          {option}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
              {hasError && (
                <p className="text-red-600 text-sm mt-2">{validation.message}</p>
              )}
            </div>
          );
        } else {
          // Use dropdown for more than 3 options
          return (
            <div key={question.id}>
              <Label htmlFor={question.id} className="text-sm font-medium text-gray-700 mb-2 block">
                {question.text} {question.required && <span className="text-red-500">*</span>}
              </Label>
              <Select 
                value={fieldValue?.toString() || ""} 
                onValueChange={(value) => updateFormData(question.formField as keyof InsertApplication, value)}
              >
                <SelectTrigger className="text-lg p-4 h-14 border-2 rounded-xl focus:border-blue-500">
                  <SelectValue placeholder={question.placeholder || `Select ${question.text.toLowerCase()}`} />
                </SelectTrigger>
                <SelectContent>
                  {question.options?.map((option) => (
                    <SelectItem key={option} value={option} className="text-lg p-3">{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          );
        }
      
      default:
        return null;
    }
  };

  const renderSubQuestions = (parentQuestion: Question, parentAnswer: any) => {
    const subQuestions = getSubQuestions(parentQuestion, parentAnswer);
    if (subQuestions.length === 0) return null;
    
    return (
      <Card className="bg-blue-50 border-blue-200 mt-4">
        <CardContent className="p-4 space-y-4">
          {subQuestions.map(subQuestion => renderQuestion(subQuestion))}
        </CardContent>
      </Card>
    );
  };

  const renderStep1 = () => {
    const questions = getQuestionsByStep(1);
    return (
      <div className="space-y-6">
        {questions.map(question => (
          <div key={question.id}>
            {renderQuestion(question)}
            {renderSubQuestions(question, formData[question.formField as keyof InsertApplication])}
          </div>
        ))}
      </div>
    );
  };

  const renderStep2 = () => {
    const questions = getQuestionsByStep(2);
    return (
      <div className="space-y-6">
        {questions.map(question => (
          <div key={question.id}>
            {renderQuestion(question)}
            {renderSubQuestions(question, formData[question.formField as keyof InsertApplication])}
          </div>
        ))}
      </div>
    );
  };

  const renderStep3 = () => {
    const questions = getQuestionsByStep(3);
    return (
      <div className="space-y-6">
        {questions.map(question => (
          <div key={question.id}>
            {renderQuestion(question)}
            {renderSubQuestions(question, formData[question.formField as keyof InsertApplication])}
          </div>
        ))}
      </div>
    );
  };

  const renderStep4 = () => {
    const questions = getQuestionsByStep(4);
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {questions.slice(0, 3).map(question => (
            <div key={question.id}>
              {renderQuestion(question)}
              {renderSubQuestions(question, formData[question.formField as keyof InsertApplication])}
            </div>
          ))}
        </div>
        {/* Render remaining questions in full width */}
        <div className="space-y-6">
          {questions.slice(3).map(question => (
            <div key={question.id}>
              {renderQuestion(question)}
              {renderSubQuestions(question, formData[question.formField as keyof InsertApplication])}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const steps = [renderStep1, renderStep2, renderStep3, renderStep4];
  
  return (
    <div className="min-h-[400px]">
      {steps[currentStep - 1]()}
    </div>
  );
}
