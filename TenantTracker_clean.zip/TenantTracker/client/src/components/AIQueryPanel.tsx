import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Send, Clock, Users, TrendingUp, MessageSquare, Download, FileText, Filter } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { ApplicationWithNotes } from "@shared/schema";

interface SearchResult {
  query: string;
  summary: string;
  totalFound: number;
  data: ApplicationWithNotes[];
  applications: ApplicationWithNotes[];
  queryType: 'filter' | 'count' | 'summary' | 'analysis';
  timestamp: string;
  filters: any;
  executionTime?: number;
}

interface SearchPanelProps {
  onUnauthorized: () => void;
}

export function AIQueryPanel({ onUnauthorized }: SearchPanelProps) {
  const [query, setQuery] = useState("");
  const [queryHistory, setQueryHistory] = useState<SearchResult[]>([]);
  const { toast } = useToast();

  // Fetch search suggestions
  const { data: suggestionsData, isLoading: suggestionsLoading } = useQuery({
    queryKey: ["/api/admin/search-suggestions"],
    retry: false,
  });

  // Search Query mutation
  const queryMutation = useMutation({
    mutationFn: async (queryText: string) => {
      const response = await apiRequest("POST", "/api/admin/search-query", { query: queryText });
      console.log("Raw API response:", response);
      return response;
    },
    onSuccess: (result: SearchResult) => {
      console.log("🎯 Search result received:", {
        query: result.query,
        found: result.totalFound || result.data?.length || 0,
        summary: result.summary
      });
      
      setQueryHistory(prev => [result, ...prev.slice(0, 4)]); // Keep last 5 queries
      setQuery("");
      
      toast({
        title: "Search Completed", 
        description: `Found ${result.totalFound || result.data?.length || 0} applications`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        onUnauthorized();
        return;
      }
      toast({
        title: "Query Failed", 
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && !queryMutation.isPending) {
      queryMutation.mutate(query.trim());
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion);
  };

  const formatCurrency = (amount: string | number) => {
    return `£${Number(amount).toLocaleString()}`;
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      'new': 'bg-yellow-100 text-yellow-800',
      'contacted': 'bg-blue-100 text-blue-800', 
      'viewing-arranged': 'bg-purple-100 text-purple-800',
      'approved': 'bg-green-100 text-green-800',
      'rejected': 'bg-red-100 text-red-800',
    };

    return (
      <Badge className={colors[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
      </Badge>
    );
  };

  const renderQueryResult = (result: SearchResult) => {
    if (result.queryType === 'count') {
      return (
        <div className="text-center p-8">
          <div className="text-4xl font-bold text-primary mb-2">{result.data?.length || 0}</div>
          <p className="text-gray-600">{result.summary}</p>
        </div>
      );
    }

    if (result.queryType === 'analysis') {
      return (
        <div className="space-y-4">
          <p className="text-gray-700">{result.summary}</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{applications.length}</div>
              <div className="text-sm text-blue-700">Total Results</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {applications.filter(app => app && Number(app.annualIncome) > 30000).length}
              </div>
              <div className="text-sm text-green-700">High Income (£30k+)</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {applications.filter(app => app && app.hasGuarantor).length}
              </div>
              <div className="text-sm text-purple-700">With Guarantor</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                {applications.filter(app => app && app.hasPets).length}
              </div>
              <div className="text-sm text-orange-700">With Pets</div>
            </div>
          </div>
        </div>
      );
    }

    // List/table view - fix data checking
    const applications = result.applications || result.data || [];
    
    console.log("Debug result rendering:", {
      hasApplications: !!result.applications,
      applicationsLength: result.applications?.length,
      hasData: !!result.data, 
      dataLength: result.data?.length,
      finalApplicationsLength: applications.length,
      totalFound: result.totalFound,
      summary: result.summary
    });
    
    if (applications.length === 0) {
      return (
        <div className="text-center p-8 text-gray-500">
          <Users className="mx-auto h-12 w-12 mb-4 text-gray-300" />
          <p>No applications found matching your query.</p>
          <p className="text-sm mt-2 italic">"{result.query}"</p>
          <p className="text-xs mt-2 text-blue-600">Expected: {result.totalFound || 0} results</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <div className="bg-blue-50 p-4 rounded-lg border">
          <p className="text-blue-800 font-medium">{result.summary}</p>
          <p className="text-blue-600 text-sm mt-1">Found {result.totalFound || result.applications?.length || result.data?.length || 0} matching applications</p>
        </div>
        
        <div className="flex justify-between items-center">
          <h4 className="font-semibold text-gray-900">Results for: "{result.query}"</h4>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const csvData = [
                  ['Name', 'Email', 'Phone', 'Income', 'Occupation', 'Move Date', 'Adults', 'Children', 'Pets', 'Guarantor', 'Status', 'Applied'].join(','),
                  ...applications.map(app => [
                    app.fullName,
                    app.email,
                    app.phone,
                    app.annualIncome,
                    app.occupation,
                    app.moveDate,
                    app.adults,
                    app.children || 0,
                    app.hasPets ? 'Yes' : 'No',
                    app.hasGuarantor ? 'Yes' : 'No',
                    app.status,
                    new Date(app.createdAt!).toLocaleDateString()
                  ].join(','))
                ].join('\n');
                
                const blob = new Blob([csvData], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `query-results-${Date.now()}.csv`;
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const printContent = `
                  <h2>Query Results: ${result.query}</h2>
                  <p><strong>Summary:</strong> ${result.summary}</p>
                  <p><strong>Found:</strong> ${result.data?.length || 0} applications</p>
                  <table border="1" style="border-collapse: collapse; width: 100%; margin-top: 20px;">
                    <thead>
                      <tr style="background-color: #f5f5f5;">
                        <th style="padding: 8px; text-align: left;">Name</th>
                        <th style="padding: 8px; text-align: left;">Email</th>
                        <th style="padding: 8px; text-align: left;">Income</th>
                        <th style="padding: 8px; text-align: left;">Occupation</th>
                        <th style="padding: 8px; text-align: left;">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${applications.map(app => `
                        <tr>
                          <td style="padding: 8px;">${app.fullName}</td>
                          <td style="padding: 8px;">${app.email}</td>
                          <td style="padding: 8px;">£${Number(app.annualIncome).toLocaleString()}</td>
                          <td style="padding: 8px;">${app.occupation}</td>
                          <td style="padding: 8px;">${app.status}</td>
                        </tr>
                      `).join('')}
                    </tbody>
                  </table>
                `;
                
                const printWindow = window.open('', '_blank');
                if (printWindow) {
                  printWindow.document.write(`
                    <html>
                      <head><title>Query Results</title></head>
                      <body>${printContent}</body>
                    </html>
                  `);
                  printWindow.document.close();
                  printWindow.print();
                }
              }}
            >
              <FileText className="h-4 w-4 mr-2" />
              Print
            </Button>
          </div>
        </div>

        <ScrollArea className="h-96">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Income</TableHead>
                <TableHead>Household</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Applied</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {applications.map((app) => (
                <TableRow key={app.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{app.fullName}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="text-blue-600 hover:underline">
                        <a href={`mailto:${app.email}`}>{app.email}</a>
                      </div>
                      <div className="text-gray-500">{app.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="font-medium text-green-600">{formatCurrency(app.annualIncome)}</div>
                      <div className="text-gray-500 capitalize">{app.occupation.replace('-', ' ')}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{app.adults} adult{app.adults !== 1 ? 's' : ''}, {app.children || 0} child{app.children !== 1 ? 'ren' : ''}</div>
                      <div className="text-gray-500">
                        {app.hasPets ? (
                          <span className="text-orange-600">Has pets</span>
                        ) : (
                          'No pets'
                        )} • {app.smokes ? 'Smoker' : 'Non-smoker'}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{getStatusBadge(app.status)}</TableCell>
                  <TableCell className="text-sm text-gray-500">
                    {new Date(app.createdAt!).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Search Query Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5 text-blue-600" />
            Smart Database Search
          </CardTitle>
          <p className="text-sm text-gray-600">
            Search applications using natural language - results appear below
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., Show me all applicants with income over £40,000 who have pets"
              className="flex-1"
              disabled={queryMutation.isPending}
            />
            <Button 
              type="submit" 
              disabled={!query.trim() || queryMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {queryMutation.isPending ? (
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </form>
          
          {queryMutation.isPending && (
            <div className="mt-4 flex items-center gap-2 text-blue-600">
              <div className="animate-spin w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" />
              <span className="text-sm">Searching applications...</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Smart Query Suggestions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            Smart Query Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {suggestionsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-8 w-full" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {suggestionsData?.suggestions && Array.isArray(suggestionsData.suggestions) ? 
                suggestionsData.suggestions.map((suggestion: string, index: number) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="justify-start text-left h-auto p-3 hover:bg-blue-50"
                    disabled={queryMutation.isPending}
                  >
                    <MessageSquare className="h-4 w-4 mr-2 flex-shrink-0" />
                    <span className="truncate">{suggestion}</span>
                  </Button>
                )) : (
                  <div className="col-span-2 text-center text-gray-500">No suggestions available</div>
                )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Query Results */}
      {queryHistory.map((result, index) => (
        <Card key={index}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle className="text-lg">{result.query}</CardTitle>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Clock className="h-4 w-4" />
                  {new Date(result.timestamp).toLocaleString()}
                </div>
              </div>
              <Badge variant="outline" className="capitalize">
                {result.queryType}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {renderQueryResult(result)}
          </CardContent>
        </Card>
      ))}

      {queryHistory.length === 0 && !queryMutation.isPending && (
        <Card className="border-dashed border-2 border-gray-200">
          <CardContent className="text-center py-12">
            <Search className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Search</h3>
            <p className="text-gray-500 mb-4">
              Type a natural language query above and your results will appear here.
            </p>
            <div className="text-sm text-gray-400 space-y-1">
              <p>Example queries:</p>
              <p>"Show high income applicants with pets"</p>
              <p>"Find families with children moving ASAP"</p>
              <p>"List self-employed applicants"</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}