import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { X, Plus, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PropertySelector } from "./PropertySelector";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { InsertApplication } from "@shared/schema";

interface ManualApplicationEntryProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export function ManualApplicationEntry({ isOpen, onClose, onSuccess }: ManualApplicationEntryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState<Partial<InsertApplication>>({
    status: 'new',
    property: [],
    fullName: '',
    email: '',
    phone: '',
    adults: 1,
    children: 0,
    annualIncome: 0,
    occupation: '',
    hasTaxReturns: false,
    hasCCJIVA: false,
    hasAdverseMedia: false,
    hasGuarantor: false,
    hasPets: false,
    petDetails: '',
    smokes: false,
    moveDate: '',
    rentalPeriod: '12 months',
    contactTime: 'anytime',
    contactMethod: 'email',
    additionalNotes: ''
  });

  const submitMutation = useMutation({
    mutationFn: async (data: InsertApplication) => {
      await apiRequest("POST", "/api/applications", data);
    },
    onSuccess: () => {
      toast({
        title: "Application Added",
        description: "The manual application has been successfully added to the system.",
      });
      // Invalidate applications query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/admin/applications"] });
      setFormData({
        status: 'new',
        property: [],
        fullName: '',
        email: '',
        phone: '',
        adults: 1,
        children: 0,
        annualIncome: 0,
        occupation: '',
        hasTaxReturns: false,
        hasCCJIVA: false,
        hasAdverseMedia: false,
        hasGuarantor: false,
        hasPets: false,
        petDetails: '',
        smokes: false,
        moveDate: '',
        rentalPeriod: '12 months',
        contactTime: 'anytime',
        contactMethod: 'email',
        additionalNotes: ''
      });
      onSuccess?.();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error Adding Application",
        description: "Failed to add the manual application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateFormData = (field: keyof InsertApplication, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    // Basic validation
    if (!formData.fullName || !formData.email) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in full name and email.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.property || formData.property.length === 0) {
      toast({
        title: "Property Selection Required",
        description: "Please select at least one property.",
        variant: "destructive",
      });
      return;
    }

    submitMutation.mutate(formData as InsertApplication);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Add Manual Application Entry
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Full Name *</label>
                <Input
                  value={formData.fullName || ''}
                  onChange={(e) => updateFormData('fullName', e.target.value)}
                  placeholder="Enter full name"
                  data-testid="input-full-name"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Email *</label>
                  <Input
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => updateFormData('email', e.target.value)}
                    placeholder="Enter email address"
                    data-testid="input-email"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Phone</label>
                  <Input
                    type="tel"
                    value={formData.phone || ''}
                    onChange={(e) => updateFormData('phone', e.target.value)}
                    placeholder="Enter phone number"
                    data-testid="input-phone"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Property Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Property Selection *</CardTitle>
            </CardHeader>
            <CardContent>
              <PropertySelector
                value={formData.property || []}
                onValueChange={(value) => updateFormData('property', value)}
                multiple={true}
              />
            </CardContent>
          </Card>

          {/* Household Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Household Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Number of Adults</label>
                  <Input
                    type="number"
                    min="1"
                    value={formData.adults || 1}
                    onChange={(e) => updateFormData('adults', parseInt(e.target.value) || 1)}
                    data-testid="input-adults"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Number of Children</label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.children || 0}
                    onChange={(e) => updateFormData('children', parseInt(e.target.value) || 0)}
                    data-testid="input-children"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Financial Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Annual Income (£)</label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.annualIncome || 0}
                    onChange={(e) => updateFormData('annualIncome', parseInt(e.target.value) || 0)}
                    placeholder="Enter annual income"
                    data-testid="input-annual-income"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Occupation</label>
                  <Input
                    value={formData.occupation || ''}
                    onChange={(e) => updateFormData('occupation', e.target.value)}
                    placeholder="Enter occupation"
                    data-testid="input-occupation"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Has Tax Returns</label>
                  <Select value={formData.hasTaxReturns ? "true" : "false"} onValueChange={(value) => updateFormData('hasTaxReturns', value === "true")}>
                    <SelectTrigger data-testid="select-tax-returns">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">CCJ/IVA History</label>
                  <Select value={formData.hasCCJIVA ? "true" : "false"} onValueChange={(value) => updateFormData('hasCCJIVA', value === "true")}>
                    <SelectTrigger data-testid="select-ccj-iva">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Adverse Media</label>
                  <Select value={formData.hasAdverseMedia ? "true" : "false"} onValueChange={(value) => updateFormData('hasAdverseMedia', value === "true")}>
                    <SelectTrigger data-testid="select-adverse-media">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lifestyle Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Lifestyle Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Has Pets</label>
                  <Select value={formData.hasPets ? "true" : "false"} onValueChange={(value) => updateFormData('hasPets', value === "true")}>
                    <SelectTrigger data-testid="select-pets">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Smokes</label>
                  <Select value={formData.smokes ? "true" : "false"} onValueChange={(value) => updateFormData('smokes', value === "true")}>
                    <SelectTrigger data-testid="select-smokes">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Has Guarantor</label>
                  <Select value={formData.hasGuarantor ? "true" : "false"} onValueChange={(value) => updateFormData('hasGuarantor', value === "true")}>
                    <SelectTrigger data-testid="select-guarantor">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Yes</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {formData.hasPets && (
                <div>
                  <label className="text-sm font-medium mb-1 block">Pet Details</label>
                  <Textarea
                    value={formData.petDetails || ''}
                    onChange={(e) => updateFormData('petDetails', e.target.value)}
                    placeholder="Describe pets (type, breed, size, etc.)"
                    data-testid="textarea-pet-details"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Move Date</label>
                  <Input
                    value={formData.moveDate || ''}
                    onChange={(e) => updateFormData('moveDate', e.target.value)}
                    placeholder="e.g., ASAP, Within 2 weeks, 1 month notice"
                    data-testid="input-move-date"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Rental Period</label>
                  <Select value={formData.rentalPeriod || '12 months'} onValueChange={(value) => updateFormData('rentalPeriod', value)}>
                    <SelectTrigger data-testid="select-rental-period">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="6 months">6 months</SelectItem>
                      <SelectItem value="12 months">12 months</SelectItem>
                      <SelectItem value="18 months">18 months</SelectItem>
                      <SelectItem value="24 months">24 months</SelectItem>
                      <SelectItem value="longer">Longer term</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Best Time to Contact</label>
                  <Select value={formData.contactTime || 'anytime'} onValueChange={(value) => updateFormData('contactTime', value)}>
                    <SelectTrigger data-testid="select-contact-time">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning (9-12)</SelectItem>
                      <SelectItem value="afternoon">Afternoon (12-5)</SelectItem>
                      <SelectItem value="evening">Evening (5-8)</SelectItem>
                      <SelectItem value="anytime">Anytime</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Preferred Contact Method</label>
                  <Select value={formData.contactMethod || 'email'} onValueChange={(value) => updateFormData('contactMethod', value)}>
                    <SelectTrigger data-testid="select-contact-method">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="both">Both Email and Phone</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Additional Notes</label>
                <Textarea
                  value={formData.additionalNotes || ''}
                  onChange={(e) => updateFormData('additionalNotes', e.target.value)}
                  placeholder="Any additional information or special requirements"
                  rows={3}
                  data-testid="textarea-additional-notes"
                />
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={submitMutation.isPending}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitMutation.isPending}
              data-testid="button-submit"
            >
              {submitMutation.isPending ? (
                <>Adding...</>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Add Application
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}