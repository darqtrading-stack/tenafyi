import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, Edit, Send, AlertCircle, Home, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface QuestionData {
  property: string;
  fullName: string;
  adults: number;
  children: number;
  adultIncomes: number[];
  totalIncome: number;
  employmentStatuses: string[];
  taxReturnYears: number[];
  hasPets: string;
  hasAdverseCredit: string;
  smokes: string;
  noticePeriod: number;
  email: string;
  phone: string;
  contactTime: string;
  contactMethod: string;
  consent: boolean;
}

interface TenantQualificationBotProps {
  onBack: () => void;
}

const TOTAL_QUESTIONS = 16;

export function TenantQualificationBot({ onBack }: TenantQualificationBotProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [data, setData] = useState<QuestionData>({
    property: '',
    fullName: '',
    adults: 1,
    children: 0,
    adultIncomes: [0],
    totalIncome: 0,
    employmentStatuses: [''],
    taxReturnYears: [0],
    hasPets: '',
    hasAdverseCredit: '',
    smokes: '',
    noticePeriod: 0,
    email: '',
    phone: '',
    contactTime: '',
    contactMethod: '',
    consent: false
  });
  const [isReviewing, setIsReviewing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [availableProperties, setAvailableProperties] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    // Fetch available properties (mock for now)
    setAvailableProperties([
      "10 King Street, Manchester",
      "22 Albert Road, Liverpool", 
      "45 Queen's Road, Birmingham",
      "5 Victoria Place, Leeds",
      "18 Park Lane, Sheffield"
    ]);
  }, []);

  const handleNext = () => {
    if (validateCurrentStep()) {
      if (currentStep < TOTAL_QUESTIONS) {
        setCurrentStep(currentStep + 1);
      } else {
        setIsReviewing(true);
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleRetry = () => {
    toast({
      title: "Question Reset",
      description: "Starting this question again. Take your time.",
    });
  };

  const handleRaiseTicket = () => {
    const timestamp = new Date().toLocaleString();
    const subject = `Tenant Bot Issue - ${timestamp}`;
    const body = `Issue reported at step ${currentStep} on ${timestamp}.\n\nUser was having difficulty with: ${getCurrentQuestionText()}\n\nPlease investigate and assist.`;
    
    const mailtoLink = `mailto:support@jtpropertyconsultants.co.uk?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
    
    toast({
      title: "Support Ticket Created",
      description: "Your email client should open with a pre-filled support request.",
    });
  };

  const validateCurrentStep = (): boolean => {
    switch (currentStep) {
      case 1: return data.property.length > 0;
      case 2: return data.fullName.length > 0;
      case 3: return data.adults >= 1;
      case 4: return true; // Children can be 0
      case 5: return data.adultIncomes.every(income => income > 0);
      case 6: return data.totalIncome > 0;
      case 7: return data.employmentStatuses.every(status => status.length > 0);
      case 8: return true; // Tax returns optional
      case 9: return data.hasPets.length > 0;
      case 10: return data.hasAdverseCredit.length > 0;
      case 11: return data.smokes.length > 0;
      case 12: return true; // Notice period can be 0
      case 13: return /\S+@\S+\.\S+/.test(data.email);
      case 14: return data.phone.length > 0;
      case 15: return data.contactTime.length > 0;
      case 16: return data.contactMethod.length > 0;
      default: return false;
    }
  };

  const handleSubmit = async () => {
    if (!data.consent) {
      toast({
        title: "Consent Required",
        description: "Please agree to the terms before submitting.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Calculate affordability
      const affordabilityRatio = data.totalIncome / 30;
      
      // Transform data for backend
      const applicationData = {
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        moveDate: 'asap', // Default for bot submissions
        adults: data.adults,
        children: data.children,
        rentalPeriod: '1-year', // Default
        hasPets: data.hasPets === 'yes',
        smokes: data.smokes === 'yes',
        occupation: data.employmentStatuses[0] || 'employed',
        hasTaxReturns: data.taxReturnYears[0] > 0,
        annualIncome: data.totalIncome.toString(),
        hasCCJIVA: data.hasAdverseCredit === 'yes',
        hasGuarantor: false, // Not collected in bot
        contactTime: data.contactTime,
        status: 'new'
      };

      await apiRequest("POST", "/api/applications", applicationData);
      
      toast({
        title: "Application Submitted Successfully!",
        description: "We'll review your application and contact you soon.",
      });

      // Reset form
      setIsReviewing(false);
      setCurrentStep(1);
      setData({
        property: '',
        fullName: '',
        adults: 1,
        children: 0,
        adultIncomes: [0],
        totalIncome: 0,
        employmentStatuses: [''],
        taxReturnYears: [0],
        hasPets: '',
        hasAdverseCredit: '',
        smokes: '',
        noticePeriod: 0,
        email: '',
        phone: '',
        contactTime: '',
        contactMethod: '',
        consent: false
      });

    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Please try again or contact support if the problem persists.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCurrentQuestionText = (): string => {
    const questions = [
      "Which property are you interested in?",
      "What is your full name?",
      "How many adults aged 18 or over will be living in the property?",
      "How many children under 18 will be living in the property?",
      "What is the annual income of each adult?",
      "What is the total combined annual income?",
      "What is each adult's employment status?",
      "How many years of tax returns can you provide?",
      "Do you have any pets?",
      "Do you have any adverse credit?",
      "Does anyone in your household smoke?",
      "How many weeks' notice do you need to give?",
      "What is your email address?",
      "What is your mobile number?",
      "When would you prefer to be contacted?",
      "How would you prefer to be contacted?"
    ];
    return questions[currentStep - 1] || "";
  };

  const updateData = (field: keyof QuestionData, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const updateAdultIncome = (index: number, income: number) => {
    const newIncomes = [...data.adultIncomes];
    newIncomes[index] = income;
    setData(prev => ({ 
      ...prev, 
      adultIncomes: newIncomes,
      totalIncome: newIncomes.reduce((sum, inc) => sum + inc, 0)
    }));
  };

  const updateEmploymentStatus = (index: number, status: string) => {
    const newStatuses = [...data.employmentStatuses];
    newStatuses[index] = status;
    setData(prev => ({ ...prev, employmentStatuses: newStatuses }));
  };

  // Effect to update arrays when adults count changes
  useEffect(() => {
    if (data.adults !== data.adultIncomes.length) {
      const newIncomes = Array(data.adults).fill(0).map((_, i) => data.adultIncomes[i] || 0);
      const newStatuses = Array(data.adults).fill('').map((_, i) => data.employmentStatuses[i] || '');
      const newTaxYears = Array(data.adults).fill(0).map((_, i) => data.taxReturnYears[i] || 0);
      
      setData(prev => ({
        ...prev,
        adultIncomes: newIncomes,
        employmentStatuses: newStatuses,
        taxReturnYears: newTaxYears
      }));
    }
  }, [data.adults]);

  if (isReviewing) {
    const affordabilityRatio = data.totalIncome / 30;
    
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Home className="h-6 w-6 text-blue-600" />
                  <CardTitle>Review Your Application</CardTitle>
                </div>
                <Button variant="outline" onClick={() => setIsReviewing(false)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Answers
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">Personal Information</h3>
                  <div className="space-y-3 text-sm">
                    <div><span className="font-medium">Property:</span> {data.property}</div>
                    <div><span className="font-medium">Full Name:</span> {data.fullName}</div>
                    <div><span className="font-medium">Adults:</span> {data.adults}</div>
                    <div><span className="font-medium">Children:</span> {data.children}</div>
                    <div><span className="font-medium">Email:</span> {data.email}</div>
                    <div><span className="font-medium">Phone:</span> {data.phone}</div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">Financial Information</h3>
                  <div className="space-y-3 text-sm">
                    <div><span className="font-medium">Total Income:</span> £{data.totalIncome.toLocaleString()}</div>
                    <div><span className="font-medium">Affordability:</span> £{Math.round(affordabilityRatio).toLocaleString()}/month</div>
                    <div><span className="font-medium">Employment:</span> {data.employmentStatuses.join(', ')}</div>
                    <div><span className="font-medium">Pets:</span> {data.hasPets}</div>
                    <div><span className="font-medium">Adverse Credit:</span> {data.hasAdverseCredit}</div>
                    <div><span className="font-medium">Smoking:</span> {data.smokes}</div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <div className="flex items-start space-x-3">
                  <Checkbox 
                    id="consent"
                    checked={data.consent}
                    onCheckedChange={(checked) => updateData('consent', checked)}
                  />
                  <Label htmlFor="consent" className="text-sm leading-relaxed">
                    I confirm that the information provided is accurate and agree for JT Property 
                    to contact me in relation to this application.
                  </Label>
                </div>
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="outline" onClick={() => setIsReviewing(false)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Application
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={!data.consent || isSubmitting}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isSubmitting ? (
                    "Submitting..."
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Submit Application
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <div className="flex items-center space-x-3">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="font-semibold text-gray-900">Tenant Application</span>
          </div>
        </div>

        {/* Progress */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                Question {currentStep} of {TOTAL_QUESTIONS}
              </span>
              <span className="text-sm text-gray-500">
                {Math.round((currentStep / TOTAL_QUESTIONS) * 100)}% Complete
              </span>
            </div>
            <Progress value={(currentStep / TOTAL_QUESTIONS) * 100} className="h-2" />
          </CardContent>
        </Card>

        {/* Question Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{getCurrentQuestionText()}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Question Content */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <Label>Select a property from our available listings:</Label>
                <Select value={data.property} onValueChange={(value) => updateData('property', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a property..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableProperties.map((property) => (
                      <SelectItem key={property} value={property}>
                        {property}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4">
                <Label htmlFor="fullName">Please enter your full name:</Label>
                <Input
                  id="fullName"
                  value={data.fullName}
                  onChange={(e) => updateData('fullName', e.target.value)}
                  placeholder="e.g. John Smith"
                />
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-4">
                <Label htmlFor="adults">Number of adults (18+):</Label>
                <Select value={data.adults.toString()} onValueChange={(value) => updateData('adults', parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6].map(num => (
                      <SelectItem key={num} value={num.toString()}>{num}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-4">
                <Label htmlFor="children">Number of children (under 18):</Label>
                <Select value={data.children.toString()} onValueChange={(value) => updateData('children', parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[0, 1, 2, 3, 4, 5].map(num => (
                      <SelectItem key={num} value={num.toString()}>{num}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 5 && (
              <div className="space-y-4">
                <Label>Annual income for each adult:</Label>
                {Array(data.adults).fill(0).map((_, index) => (
                  <div key={index} className="space-y-2">
                    <Label htmlFor={`income-${index}`}>Adult {index + 1} annual income (£):</Label>
                    <Input
                      id={`income-${index}`}
                      type="number"
                      value={data.adultIncomes[index] || ''}
                      onChange={(e) => updateAdultIncome(index, parseInt(e.target.value) || 0)}
                      placeholder="e.g. 35000"
                    />
                  </div>
                ))}
              </div>
            )}

            {currentStep === 6 && (
              <div className="space-y-4">
                <Label>Total combined household income:</Label>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-800">
                    £{data.totalIncome.toLocaleString()}
                  </div>
                  <div className="text-sm text-blue-600 mt-1">
                    Monthly affordability: £{Math.round(data.totalIncome / 30).toLocaleString()}
                  </div>
                </div>
                <p className="text-sm text-gray-600">
                  This is calculated automatically from individual incomes. 
                  Affordability is based on income ÷ 30 rule.
                </p>
              </div>
            )}

            {currentStep === 7 && (
              <div className="space-y-4">
                <Label>Employment status for each adult:</Label>
                {Array(data.adults).fill(0).map((_, index) => (
                  <div key={index} className="space-y-2">
                    <Label>Adult {index + 1} employment status:</Label>
                    <RadioGroup 
                      value={data.employmentStatuses[index]} 
                      onValueChange={(value) => updateEmploymentStatus(index, value)}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="employed" id={`emp-${index}`} />
                        <Label htmlFor={`emp-${index}`}>Employed</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="self-employed" id={`self-${index}`} />
                        <Label htmlFor={`self-${index}`}>Self-Employed</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="unemployed" id={`unemp-${index}`} />
                        <Label htmlFor={`unemp-${index}`}>Unemployed</Label>
                      </div>
                    </RadioGroup>
                  </div>
                ))}
              </div>
            )}

            {currentStep === 8 && (
              <div className="space-y-4">
                <Label>Tax returns (for self-employed applicants):</Label>
                <p className="text-sm text-gray-600">
                  If any adults are self-employed, how many years of tax returns can you provide?
                </p>
                <Select value={data.taxReturnYears[0]?.toString() || '0'} onValueChange={(value) => updateData('taxReturnYears', [parseInt(value)])}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select years..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Not applicable / 0 years</SelectItem>
                    <SelectItem value="1">1 year</SelectItem>
                    <SelectItem value="2">2 years</SelectItem>
                    <SelectItem value="3">3+ years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 9 && (
              <div className="space-y-4">
                <Label>Do you have any pets?</Label>
                <RadioGroup value={data.hasPets} onValueChange={(value) => updateData('hasPets', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="pets-yes" />
                    <Label htmlFor="pets-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="pets-no" />
                    <Label htmlFor="pets-no">No</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 10 && (
              <div className="space-y-4">
                <Label>Do you have any adverse credit (such as CCJs or IVAs)?</Label>
                <RadioGroup value={data.hasAdverseCredit} onValueChange={(value) => updateData('hasAdverseCredit', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="credit-yes" />
                    <Label htmlFor="credit-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="credit-no" />
                    <Label htmlFor="credit-no">No</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dont-know" id="credit-unknown" />
                    <Label htmlFor="credit-unknown">Don't know</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 11 && (
              <div className="space-y-4">
                <Label>Does anyone in your household smoke?</Label>
                <RadioGroup value={data.smokes} onValueChange={(value) => updateData('smokes', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="smoke-yes" />
                    <Label htmlFor="smoke-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="smoke-no" />
                    <Label htmlFor="smoke-no">No</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 12 && (
              <div className="space-y-4">
                <Label htmlFor="notice">How many weeks' notice do you need to give your landlord or agent?</Label>
                <Input
                  id="notice"
                  type="text"
                  defaultValue={data.noticePeriod > 0 ? data.noticePeriod.toString() : ''}
                  onBlur={(e) => {
                    const input = e.target.value.toLowerCase().trim();
                    let value = 0;
                    if (input === 'none' || input === 'zero' || input === '0' || input === '') {
                      value = 0;
                    } else {
                      value = parseInt(e.target.value) || 0;
                    }
                    updateData('noticePeriod', value);
                  }}
                  placeholder='Enter number of weeks, or write "none", "zero", or "0"'
                />
                <p className="text-sm text-gray-600">
                  You can write "none", "zero", "0", or any number of weeks.
                </p>
              </div>
            )}

            {currentStep === 13 && (
              <div className="space-y-4">
                <Label htmlFor="email">Email address:</Label>
                <Input
                  id="email"
                  type="email"
                  value={data.email}
                  onChange={(e) => updateData('email', e.target.value)}
                  placeholder="your.email@example.com"
                />
              </div>
            )}

            {currentStep === 14 && (
              <div className="space-y-4">
                <Label htmlFor="phone">Mobile number:</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={data.phone}
                  onChange={(e) => updateData('phone', e.target.value)}
                  placeholder="07xxx xxx xxx"
                />
              </div>
            )}

            {currentStep === 15 && (
              <div className="space-y-4">
                <Label>When would you prefer to be contacted?</Label>
                <RadioGroup value={data.contactTime} onValueChange={(value) => updateData('contactTime', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="morning" id="time-morning" />
                    <Label htmlFor="time-morning">Morning</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="afternoon" id="time-afternoon" />
                    <Label htmlFor="time-afternoon">Afternoon</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="evening" id="time-evening" />
                    <Label htmlFor="time-evening">After 5pm</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 16 && (
              <div className="space-y-4">
                <Label>How would you prefer to be contacted?</Label>
                <RadioGroup value={data.contactMethod} onValueChange={(value) => updateData('contactMethod', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="phone" id="method-phone" />
                    <Label htmlFor="method-phone">Phone call</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="email" id="method-email" />
                    <Label htmlFor="method-email">Email</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between pt-6 border-t">
              <div className="flex space-x-2">
                {currentStep > 1 && (
                  <Button variant="outline" onClick={handlePrevious}>
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Previous
                  </Button>
                )}
                <Button variant="outline" onClick={handleRetry}>
                  Retry Question
                </Button>
                <Button variant="outline" onClick={handleRaiseTicket} className="text-red-600">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Get Help
                </Button>
              </div>
              
              <Button 
                onClick={handleNext}
                disabled={!validateCurrentStep()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {currentStep === TOTAL_QUESTIONS ? 'Review' : 'Next'}
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}