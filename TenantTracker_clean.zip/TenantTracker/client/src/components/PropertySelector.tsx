import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ExternalLink, Building, RefreshCw, X, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Property {
  id: string;
  title: string;
  price: string;
  beds: string;
  thumbnail: string;
  url: string;
  description: string;
}

interface PropertySelectorProps {
  value: string | string[];
  onValueChange: (value: string | string[]) => void;
  multiple?: boolean;
}

// Dynamic properties loaded from API

export function PropertySelector({ value, onValueChange, multiple = false }: PropertySelectorProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch properties dynamically from API
  const { data: properties = [], isLoading, error, refetch } = useQuery({
    queryKey: ['/api/properties'],
    queryFn: () => apiRequest('GET', '/api/properties'),
  });
  
  const propertyList: Property[] = properties.map((p: any, index: number) => ({
    id: `property-${index}`,
    title: p.title,
    price: p.price,
    beds: p.beds,
    thumbnail: p.thumbnail,
    url: p.url,
    description: p.description
  }));
  
  // Handle both single and multi-selection
  const selectedValues = Array.isArray(value) ? value : (value ? [value] : []);
  const selectedProperties = propertyList.filter(p => selectedValues.includes(p.title));
  
  const handlePropertySelect = (propertyTitle: string) => {
    if (multiple) {
      const currentValues = Array.isArray(value) ? value : (value ? [value] : []);
      if (currentValues.includes(propertyTitle)) {
        // Remove if already selected
        const newValues = currentValues.filter(v => v !== propertyTitle);
        onValueChange(newValues);
      } else {
        // Add to selection
        onValueChange([...currentValues, propertyTitle]);
      }
    } else {
      onValueChange(propertyTitle);
    }
  };
  
  const handlePropertyRemove = (propertyTitle: string) => {
    if (multiple) {
      const currentValues = Array.isArray(value) ? value : (value ? [value] : []);
      const newValues = currentValues.filter(v => v !== propertyTitle);
      onValueChange(newValues);
    } else {
      onValueChange('');
    }
  };

  return (
    <div className="space-y-4">
      <Label className="text-sm font-medium text-gray-700 mb-2 block">
        Which {multiple ? 'properties are' : 'property are'} you interested in? <span className="text-red-500">*</span>
        <span className="text-xs text-gray-500 block mt-1">
          This is our most important question - please take your time to choose{multiple ? ' (you can select multiple properties)' : ''}
        </span>
      </Label>
      
      {/* Enhanced Property Selection Area */}
      <div className="border-2 border-blue-200 bg-blue-50 rounded-lg p-6 space-y-4">
        {/* Show selected properties as tags */}
        {selectedProperties.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">
              Selected {multiple ? 'Properties' : 'Property'}:
            </div>
            <div className="flex flex-wrap gap-2">
              {selectedProperties.map((property) => (
                <div key={property.id} className="inline-flex items-center gap-2 bg-green-100 text-green-800 px-3 py-2 rounded-lg border border-green-200">
                  <Building className="h-3 w-3" />
                  <span className="text-xs font-medium truncate max-w-[200px]" title={property.title}>
                    {property.title}
                  </span>
                  <span className="text-xs bg-green-200 px-1 rounded">{property.price}</span>
                  <button
                    onClick={() => handlePropertyRemove(property.title)}
                    className="hover:bg-green-200 rounded p-0.5 transition-colors"
                    aria-label={`Remove ${property.title}`}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {!multiple ? (
          <Select value={Array.isArray(value) ? value[0] || '' : value || ''} onValueChange={handlePropertySelect} disabled={isLoading}>
            <SelectTrigger className="h-12 text-left">
              <SelectValue placeholder={isLoading ? "Loading properties..." : "🏠 Select a property from JT Property Consultants"} />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              {propertyList.map((property: Property) => (
                <SelectItem key={property.id} value={property.title} className="p-3 cursor-pointer">
                  <div className="flex items-center space-x-3">
                    <Building className="h-4 w-4 text-blue-600" />
                    <div>
                      <div className="font-medium text-sm">{property.title}</div>
                      <div className="text-xs text-gray-500">{property.price} • {property.beds}</div>
                    </div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto">
            {propertyList.map((property: Property) => {
              const isSelected = selectedValues.includes(property.title);
              return (
                <div
                  key={property.id}
                  onClick={() => handlePropertySelect(property.title)}
                  className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-green-300 bg-green-50 text-green-800'
                      : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                  }`}
                >
                  <div className={`flex items-center justify-center w-5 h-5 rounded border-2 ${
                    isSelected ? 'border-green-600 bg-green-600' : 'border-gray-300'
                  }`}>
                    {isSelected && <span className="text-white text-xs">✓</span>}
                  </div>
                  <Building className="h-4 w-4 text-blue-600" />
                  <div className="flex-1">
                    <div className="font-medium text-sm">{property.title}</div>
                    <div className="text-xs text-gray-500">{property.price} • {property.beds}</div>
                  </div>
                  {isSelected && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePropertyRemove(property.title);
                      }}
                      className="text-green-600 hover:text-red-600 transition-colors"
                      aria-label={`Remove ${property.title}`}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Browse All Properties Button */}
        <div className="flex space-x-2">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex-1" disabled={isLoading}>
                🏘️ Browse All Properties with Photos
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                JT Property Consultants - Available Properties
              </DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[60vh]">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                {propertyList.map((property) => (
                  <Card key={property.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                    <CardContent className="p-4">
                      <div className="aspect-video mb-3 overflow-hidden rounded-lg">
                        <img
                          src={property.thumbnail}
                          alt={property.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = '/placeholder-property.jpg';
                          }}
                        />
                      </div>
                      <h3 className="font-bold text-sm mb-2 line-clamp-2">
                        {property.title}
                      </h3>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-lg font-semibold text-green-600">
                          {property.price}
                        </span>
                        <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {property.beds}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 mb-3 line-clamp-3">
                        {property.description}
                      </p>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(property.url, '_blank')}
                          className="flex-1"
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          View Details
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => {
                            handlePropertySelect(property.title);
                            if (!multiple) setIsDialogOpen(false);
                          }}
                          className="flex-1"
                          variant={selectedValues.includes(property.title) ? "destructive" : "default"}
                        >
                          {selectedValues.includes(property.title) ? (
                            <>
                              <X className="h-3 w-3 mr-1" />
                              Remove
                            </>
                          ) : (
                            <>
                              <Plus className="h-3 w-3 mr-1" />
                              Select{multiple ? '' : ' This Property'}
                            </>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => refetch()}
          disabled={isLoading}
          className="px-3"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
        </Button>
        </div>

        {/* Show property summary when multiple selected */}
        {multiple && selectedProperties.length > 0 && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <h4 className="font-medium text-sm text-green-800 mb-2">
                ✓ {selectedProperties.length} {selectedProperties.length === 1 ? 'Property' : 'Properties'} Selected
              </h4>
              <div className="text-xs text-gray-600">
                Total properties: {selectedProperties.length} • 
                Price range: £{Math.min(...selectedProperties.map(p => parseInt(p.price.replace(/[£,]/g, ''))))} - £{Math.max(...selectedProperties.map(p => parseInt(p.price.replace(/[£,]/g, ''))))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}