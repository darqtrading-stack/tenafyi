import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, RotateCcw, Home, Send, AlertTriangle, CheckCircle2, Calculator } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface BotData {
  property: string;
  fullName: string;
  adults: number;
  children: number;
  adultIncomes: number[];
  totalIncome: number;
  employmentStatuses: string[];
  taxReturnYears: number;
  hasPets: string;
  smokes: string;
  hasAdverseCredit: string;
  noticePeriod: number;
  email: string;
  mobile: string;
  contactTime: string;
  contactMethod: string;
  consent: boolean;
}

interface TenafyiBotProps {
  onReturn: () => void;
}

const TOTAL_STEPS = 16;

const AVAILABLE_PROPERTIES = [
  "10 King Street, Manchester M1 4LX",
  "22 Albert Road, Liverpool L8 3QE", 
  "45 Queen's Road, Birmingham B4 6AT",
  "5 Victoria Place, Leeds LS2 7JH",
  "18 Park Lane, Sheffield S1 2HE",
  "31 Church Street, Newcastle NE1 5XF",
  "8 Mill Road, Bristol BS2 0JD"
];

const EMPLOYMENT_OPTIONS = ['Employed', 'Self-Employed', 'Unemployed'];
const CONTACT_TIME_OPTIONS = ['Morning', 'Afternoon', 'After 5pm'];
const CONTACT_METHOD_OPTIONS = ['Phone call', 'Email'];

export function TenafyiBot({ onReturn }: TenafyiBotProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [isReviewing, setIsReviewing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [data, setData] = useState<BotData>({
    property: '',
    fullName: '',
    adults: 1,
    children: 0,
    adultIncomes: [0],
    totalIncome: 0,
    employmentStatuses: [''],
    taxReturnYears: 0,
    hasPets: '',
    smokes: '',
    hasAdverseCredit: '',
    noticePeriod: 0,
    email: '',
    mobile: '',
    contactTime: '',
    contactMethod: '',
    consent: false
  });
  const { toast } = useToast();

  const getQuestionTitle = (step: number): string => {
    const questions = [
      "Which property are you interested in?",
      "What is your full name?",
      "How many adults aged 18 or over will be living at the property?",
      "How many children under 18 will be living at the property?",
      "What is the annual income of each adult?",
      "What is your total combined household income?",
      "What is each adult's employment status?",
      "Tax returns for self-employed adults",
      "Do you have any pets?",
      "Do you or anyone in your household smoke?",
      "Do you have any adverse credit, like a CCJ or IVA?",
      "Current rental notice period",
      "What is your email address?",
      "What is your mobile number?",
      "When would you prefer to be contacted?",
      "How would you prefer to be contacted?"
    ];
    return questions[step - 1] || "";
  };

  const validateStep = (): boolean => {
    switch (currentStep) {
      case 1: return data.property.length > 0;
      case 2: return data.fullName.trim().length > 0;
      case 3: return data.adults >= 1;
      case 4: return true; // Children can be 0
      case 5: return data.adultIncomes.every(income => income > 0);
      case 6: return data.totalIncome > 0;
      case 7: return data.employmentStatuses.every(status => status.length > 0);
      case 8: return true; // Tax returns optional based on employment
      case 9: return data.hasPets.length > 0;
      case 10: return data.smokes.length > 0;
      case 11: return data.hasAdverseCredit.length > 0;
      case 12: return true; // Notice period can be 0
      case 13: return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email);
      case 14: return data.mobile.trim().length > 0;
      case 15: return data.contactTime.length > 0;
      case 16: return data.contactMethod.length > 0;
      default: return false;
    }
  };

  const handleNext = () => {
    if (validateStep()) {
      if (currentStep < TOTAL_STEPS) {
        setCurrentStep(currentStep + 1);
      } else {
        setIsReviewing(true);
      }
    } else {
      toast({
        title: "Please complete this step",
        description: "All required fields must be filled before proceeding.",
        variant: "destructive"
      });
    }
  };

  const handleTryAgain = () => {
    toast({
      title: "Question Reset",
      description: "Take your time to answer this question correctly.",
    });
  };

  const handleStartOver = () => {
    setCurrentStep(1);
    setData({
      property: '',
      fullName: '',
      adults: 1,
      children: 0,
      adultIncomes: [0],
      totalIncome: 0,
      employmentStatuses: [''],
      taxReturnYears: 0,
      hasPets: '',
      smokes: '',
      hasAdverseCredit: '',
      noticePeriod: 0,
      email: '',
      mobile: '',
      contactTime: '',
      contactMethod: '',
      consent: false
    });
    toast({
      title: "Application Reset",
      description: "Starting over with a fresh application.",
    });
  };

  const handleRaiseTicket = () => {
    const timestamp = new Date().toLocaleString();
    const subject = `Bot Ticket – ${timestamp}`;
    const currentQuestion = getQuestionTitle(currentStep);
    const body = `Bot Support Ticket

Time: ${timestamp}
Failed Question: ${currentQuestion}
Current Step: ${currentStep}

Issue Description:
User encountered difficulty with this question and requested assistance.

Current User Input:
${JSON.stringify(data, null, 2)}

Please investigate and provide support.`;

    const mailtoLink = `mailto:support@jtpropertyconsultants.co.uk?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
    
    toast({
      title: "Support Ticket Created",
      description: "Your email client will open with a support request.",
    });
  };

  const updateData = (field: keyof BotData, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const updateAdultIncome = (index: number, income: number) => {
    const newIncomes = [...data.adultIncomes];
    newIncomes[index] = income;
    const total = newIncomes.reduce((sum, inc) => sum + inc, 0);
    setData(prev => ({ 
      ...prev, 
      adultIncomes: newIncomes,
      totalIncome: total
    }));
  };

  const updateEmploymentStatus = (index: number, status: string) => {
    const newStatuses = [...data.employmentStatuses];
    newStatuses[index] = status;
    setData(prev => ({ ...prev, employmentStatuses: newStatuses }));
  };

  // Update arrays when adults count changes
  useEffect(() => {
    if (data.adults !== data.adultIncomes.length) {
      const newIncomes = Array(data.adults).fill(0).map((_, i) => data.adultIncomes[i] || 0);
      const newStatuses = Array(data.adults).fill('').map((_, i) => data.employmentStatuses[i] || '');
      
      setData(prev => ({
        ...prev,
        adultIncomes: newIncomes,
        employmentStatuses: newStatuses,
        totalIncome: newIncomes.reduce((sum, inc) => sum + inc, 0)
      }));
    }
  }, [data.adults]);

  const handleSubmit = async () => {
    if (!data.consent) {
      toast({
        title: "Consent Required",
        description: "Please confirm your consent before submitting.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const applicationData = {
        fullName: data.fullName,
        email: data.email,
        phone: data.mobile,
        moveDate: 'asap',
        adults: data.adults,
        children: data.children,
        rentalPeriod: '1-year',
        hasPets: data.hasPets === 'Yes',
        smokes: data.smokes === 'Yes',
        occupation: data.employmentStatuses[0] || 'employed',
        hasTaxReturns: data.taxReturnYears > 0,
        annualIncome: data.totalIncome.toString(),
        hasCCJIVA: data.hasAdverseCredit === 'Yes',
        hasGuarantor: false,
        contactTime: data.contactTime.toLowerCase(),
        status: 'new'
      };

      await apiRequest("POST", "/api/applications", applicationData);
      
      const timestamp = new Date().toLocaleString();
      toast({
        title: "Application Submitted Successfully!",
        description: `Reference: TENAFYI-${Date.now()}`,
      });

      // Reset and return to landing
      setTimeout(() => {
        onReturn();
      }, 3000);

    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Please try again or contact support.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isReviewing) {
    const affordability = Math.round(data.totalIncome / 30);
    
    return (
      <div className="min-h-screen bg-slate-50 py-8">
        <div className="max-w-4xl mx-auto px-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center space-x-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                  <span>Review Your Application</span>
                </span>
                <Button variant="outline" onClick={() => setIsReviewing(false)}>
                  Edit Answers
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800">Property & Personal Details</h3>
                  <div className="space-y-3 text-sm">
                    <div><span className="font-medium">Property:</span> {data.property}</div>
                    <div><span className="font-medium">Full Name:</span> {data.fullName}</div>
                    <div><span className="font-medium">Household:</span> {data.adults} adults, {data.children} children</div>
                    <div><span className="font-medium">Contact:</span> {data.email}</div>
                    <div><span className="font-medium">Mobile:</span> {data.mobile}</div>
                    <div><span className="font-medium">Preferred Contact:</span> {data.contactMethod} ({data.contactTime})</div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800">Financial & Lifestyle</h3>
                  <div className="space-y-3 text-sm">
                    <div><span className="font-medium">Total Income:</span> £{data.totalIncome.toLocaleString()}</div>
                    <div><span className="font-medium">Monthly Affordability:</span> £{affordability.toLocaleString()}</div>
                    <div><span className="font-medium">Employment:</span> {data.employmentStatuses.join(', ')}</div>
                    <div><span className="font-medium">Tax Returns:</span> {data.taxReturnYears} years</div>
                    <div><span className="font-medium">Pets:</span> {data.hasPets}</div>
                    <div><span className="font-medium">Smoking:</span> {data.smokes}</div>
                    <div><span className="font-medium">Adverse Credit:</span> {data.hasAdverseCredit}</div>
                    <div><span className="font-medium">Notice Period:</span> {data.noticePeriod} weeks</div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <div className="flex items-start space-x-3">
                  <Checkbox 
                    id="consent"
                    checked={data.consent}
                    onCheckedChange={(checked) => updateData('consent', checked)}
                  />
                  <Label htmlFor="consent" className="text-sm leading-relaxed">
                    I confirm that the information provided is accurate and agree to be contacted by JT Property.
                  </Label>
                </div>
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="outline" onClick={() => setIsReviewing(false)}>
                  Edit Application
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={!data.consent || isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? "Submitting..." : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Submit Application
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={onReturn}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Return Home
            </Button>
            <div className="flex items-center space-x-3">
              <Home className="w-6 h-6 text-emerald-600" />
              <span className="font-semibold text-slate-800">Tenafyi Application Bot</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Progress */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="font-medium text-slate-700">Step {currentStep} of {TOTAL_STEPS}</span>
              <span className="text-sm text-slate-500">{Math.round((currentStep / TOTAL_STEPS) * 100)}% Complete</span>
            </div>
            <Progress value={(currentStep / TOTAL_STEPS) * 100} className="h-3" />
          </CardContent>
        </Card>

        {/* Question Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-slate-800">
              {getQuestionTitle(currentStep)}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Step Content */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <Label>Select a property from our available listings:</Label>
                <Select value={data.property} onValueChange={(value) => updateData('property', value)}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose a property..." />
                  </SelectTrigger>
                  <SelectContent>
                    {AVAILABLE_PROPERTIES.map((property) => (
                      <SelectItem key={property} value={property}>
                        {property}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {data.property && (
                  <div className="p-4 bg-emerald-50 rounded-lg">
                    <p className="text-sm text-emerald-800">
                      ✓ Property confirmed: {data.property}
                    </p>
                  </div>
                )}
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4">
                <Label htmlFor="fullName">Please enter your full name:</Label>
                <Input
                  id="fullName"
                  value={data.fullName}
                  onChange={(e) => updateData('fullName', e.target.value)}
                  placeholder="e.g. John Smith"
                  className="text-lg"
                />
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-4">
                <Label>Number of adults (18+) living at the property:</Label>
                <Select value={data.adults.toString()} onValueChange={(value) => updateData('adults', parseInt(value))}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6].map(num => (
                      <SelectItem key={num} value={num.toString()}>{num} adult{num > 1 ? 's' : ''}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-4">
                <Label>Number of children (under 18) living at the property:</Label>
                <Select value={data.children.toString()} onValueChange={(value) => updateData('children', parseInt(value))}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[0, 1, 2, 3, 4, 5].map(num => (
                      <SelectItem key={num} value={num.toString()}>{num} {num === 1 ? 'child' : 'children'}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 5 && (
              <div className="space-y-6">
                <Label>Annual income for each adult:</Label>
                {Array(data.adults).fill(0).map((_, index) => (
                  <div key={index} className="space-y-2">
                    <Label htmlFor={`income-${index}`}>Adult {index + 1} annual income (£):</Label>
                    <Input
                      id={`income-${index}`}
                      type="number"
                      value={data.adultIncomes[index] || ''}
                      onChange={(e) => updateAdultIncome(index, parseInt(e.target.value) || 0)}
                      placeholder="e.g. 35000"
                      className="text-lg"
                    />
                  </div>
                ))}
              </div>
            )}

            {currentStep === 6 && (
              <div className="space-y-6">
                <Label>Your total combined household income:</Label>
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Calculator className="w-8 h-8 text-emerald-600" />
                    <div>
                      <div className="text-3xl font-bold text-emerald-800">
                        £{data.totalIncome.toLocaleString()}
                      </div>
                      <div className="text-sm text-emerald-600">
                        Monthly affordability: £{Math.round(data.totalIncome / 30).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-emerald-700">
                    Calculated automatically from individual incomes. Affordability based on total income ÷ 30.
                  </p>
                </div>
              </div>
            )}

            {currentStep === 7 && (
              <div className="space-y-6">
                <Label>Employment status for each adult:</Label>
                {Array(data.adults).fill(0).map((_, index) => (
                  <div key={index} className="space-y-3">
                    <Label className="text-base">Adult {index + 1} employment status:</Label>
                    <RadioGroup 
                      value={data.employmentStatuses[index]} 
                      onValueChange={(value) => updateEmploymentStatus(index, value)}
                    >
                      {EMPLOYMENT_OPTIONS.map(option => (
                        <div key={option} className="flex items-center space-x-2">
                          <RadioGroupItem value={option} id={`${option}-${index}`} />
                          <Label htmlFor={`${option}-${index}`}>{option}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                ))}
              </div>
            )}

            {currentStep === 8 && (
              <div className="space-y-4">
                <Label>Years of tax returns available (for self-employed adults):</Label>
                <p className="text-sm text-slate-600">
                  If any adults are self-employed, how many years of tax returns can you provide?
                </p>
                <Select value={data.taxReturnYears.toString()} onValueChange={(value) => updateData('taxReturnYears', parseInt(value))}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select years..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Not applicable / 0 years</SelectItem>
                    <SelectItem value="1">1 year</SelectItem>
                    <SelectItem value="2">2 years</SelectItem>
                    <SelectItem value="3">3+ years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {currentStep === 9 && (
              <div className="space-y-4">
                <Label>Do you have any pets?</Label>
                <RadioGroup value={data.hasPets} onValueChange={(value) => updateData('hasPets', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Yes" id="pets-yes" />
                    <Label htmlFor="pets-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="No" id="pets-no" />
                    <Label htmlFor="pets-no">No</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 10 && (
              <div className="space-y-4">
                <Label>Do you or anyone in your household smoke?</Label>
                <RadioGroup value={data.smokes} onValueChange={(value) => updateData('smokes', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Yes" id="smoke-yes" />
                    <Label htmlFor="smoke-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="No" id="smoke-no" />
                    <Label htmlFor="smoke-no">No</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 11 && (
              <div className="space-y-4">
                <Label>Do you have any adverse credit, like a CCJ or IVA?</Label>
                <RadioGroup value={data.hasAdverseCredit} onValueChange={(value) => updateData('hasAdverseCredit', value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Yes" id="credit-yes" />
                    <Label htmlFor="credit-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="No" id="credit-no" />
                    <Label htmlFor="credit-no">No</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Don't Know" id="credit-unknown" />
                    <Label htmlFor="credit-unknown">Don't know</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {currentStep === 12 && (
              <div className="space-y-4">
                <Label htmlFor="notice">If you currently rent, how many weeks' notice do you need to give your landlord or agent?</Label>
                <Input
                  id="notice"
                  type="text"
                  defaultValue={data.noticePeriod > 0 ? data.noticePeriod.toString() : ''}
                  onBlur={(e) => {
                    const input = e.target.value.toLowerCase().trim();
                    let value = 0;
                    if (input === 'none' || input === 'zero' || input === '0' || input === '') {
                      value = 0;
                    } else {
                      value = parseInt(e.target.value) || 0;
                    }
                    updateData('noticePeriod', value);
                  }}
                  placeholder='Enter number of weeks, or write "none", "zero", or "0"'
                  className="text-lg"
                />
                <p className="text-sm text-slate-600">
                  You can write "none", "zero", "0", or any number of weeks.
                </p>
              </div>
            )}

            {currentStep === 13 && (
              <div className="space-y-4">
                <Label htmlFor="email">What is your email address?</Label>
                <Input
                  id="email"
                  type="email"
                  value={data.email}
                  onChange={(e) => updateData('email', e.target.value)}
                  placeholder="your.email@example.com"
                  className="text-lg"
                />
              </div>
            )}

            {currentStep === 14 && (
              <div className="space-y-4">
                <Label htmlFor="mobile">What is your mobile number?</Label>
                <Input
                  id="mobile"
                  type="tel"
                  value={data.mobile}
                  onChange={(e) => updateData('mobile', e.target.value)}
                  placeholder="07xxx xxx xxx"
                  className="text-lg"
                />
              </div>
            )}

            {currentStep === 15 && (
              <div className="space-y-4">
                <Label>When would you prefer to be contacted?</Label>
                <RadioGroup value={data.contactTime} onValueChange={(value) => updateData('contactTime', value)}>
                  {CONTACT_TIME_OPTIONS.map(option => (
                    <div key={option} className="flex items-center space-x-2">
                      <RadioGroupItem value={option} id={`time-${option}`} />
                      <Label htmlFor={`time-${option}`}>{option}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            )}

            {currentStep === 16 && (
              <div className="space-y-4">
                <Label>How would you prefer to be contacted?</Label>
                <RadioGroup value={data.contactMethod} onValueChange={(value) => updateData('contactMethod', value)}>
                  {CONTACT_METHOD_OPTIONS.map(option => (
                    <div key={option} className="flex items-center space-x-2">
                      <RadioGroupItem value={option} id={`method-${option}`} />
                      <Label htmlFor={`method-${option}`}>{option}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between pt-8 border-t">
              <div className="flex space-x-3">
                <Button variant="outline" onClick={handleTryAgain}>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button variant="outline" onClick={handleStartOver}>
                  Start Over
                </Button>
                <Button variant="outline" onClick={handleRaiseTicket} className="text-red-600 border-red-200">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Raise a Ticket
                </Button>
              </div>
              
              <Button 
                onClick={handleNext}
                disabled={!validateStep()}
                className="bg-emerald-600 hover:bg-emerald-700 px-8"
              >
                {currentStep === TOTAL_STEPS ? 'Review Application' : 'Continue'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}