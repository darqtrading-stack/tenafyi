import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowLeft, Send, RotateCcw, Home, AlertTriangle, CheckCircle, Edit, Building, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { unifiedQuestions, getQuestionByBotStep, getSubQuestions, validateAnswer, Question } from "@shared/questions";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  options?: string[];
  showInput?: boolean;
  inputType?: 'text' | 'number' | 'email' | 'tel';
  placeholder?: string;
}

interface BotData {
  properties: string[];
  fullName: string;
  adults: number;
  children: number;
  adultIncomes: number[];
  totalIncome: number;
  employmentStatuses: string[];
  taxReturnYears: number;
  hasPets: string;
  petDetails: string;
  smokes: string;
  moveDate: string;
  hasAdverseCredit: string;
  needsGuarantor: string;
  noticePeriod: number;
  email: string;
  mobile: string;
  contactMethod: string;
  consent: boolean;
  paymentFrequency: string;
  paymentAmount: number;
  additionalDetails: string;
}

interface Property {
  id: string;
  title: string;
  price: string;
  beds: string;
  thumbnail: string;
  url: string;
  description: string;
}

interface ConversationalBotProps {
  onReturn: () => void;
}



export function ConversationalBot({ onReturn }: ConversationalBotProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [currentInput, setCurrentInput] = useState('');
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [data, setData] = useState<BotData>({
    properties: [],
    fullName: '',
    adults: 0,
    children: 0,
    adultIncomes: [],
    totalIncome: 0,
    employmentStatuses: [],
    taxReturnYears: 0,
    hasPets: '',
    petDetails: '',
    smokes: '',
    moveDate: '',
    hasAdverseCredit: '',
    needsGuarantor: '',
    noticePeriod: 0,
    email: '',
    mobile: '',
    contactMethod: '',
    consent: false,
    paymentFrequency: '',
    paymentAmount: 0,
    additionalDetails: ''
  });
  const [adultIncomeIndex, setAdultIncomeIndex] = useState(0);
  const [employmentIndex, setEmploymentIndex] = useState(0);
  const [isReviewing, setIsReviewing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [availableProperties, setAvailableProperties] = useState<Property[]>([]);
  const [propertyMatches, setPropertyMatches] = useState<Property[]>([]);
  const [isLoadingProperties, setIsLoadingProperties] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [showPropertyBrowser, setShowPropertyBrowser] = useState(false);
  
  // Fetch properties dynamically from API
  const { data: properties = [], isLoading, error } = useQuery({
    queryKey: ['/api/properties'],
    queryFn: () => apiRequest('GET', '/api/properties'),
  });
  
  const propertyList: Property[] = properties.map((p: any, index: number) => ({
    id: `property-${index}`,
    title: p.title,
    price: p.price,
    beds: p.beds,
    thumbnail: p.thumbnail,
    url: p.url,
    description: p.description
  }));

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Load properties and start conversation
    loadProperties();
    addBotMessage("Hi there! 👋 I'm here to help you with your rental application. Which property are you interested in?", true, 'text', 'Type property name or click "Browse All Properties" to see the full list');
  }, []);

  const loadProperties = async () => {
    setIsLoadingProperties(true);
    try {
      // Live property listings from JT Property Consultants
      const properties: Property[] = [
        { 
          title: "4-bed Bungalow – New Barn Road, Longfield", 
          address: "New Barn Road, Longfield, DA3 7JE", 
          url: "https://jtpropertyconsultants.co.uk/property/4-bed-bungalow-to-rent-in-new-barn-road-longfield-da3-7je/632211",
          rent: "£3,495 per month"
        },
        { 
          title: "4-bed Detached House – Broadacre View", 
          address: "Broadacre View, Watermans Park", 
          url: "https://jtpropertyconsultants.co.uk/property/4-bed-detached-house-to-rent-in-broadacre-view/620718",
          rent: "£2,450 per month"
        },
        { 
          title: "4-bed Chalet – Ufton Lane, Sittingbourne", 
          address: "Ufton Lane, Sittingbourne, Kent, ME10 1EU", 
          url: "https://jtpropertyconsultants.co.uk/property/4-bed-chalet-to-rent-in-ufton-lane-sittingbourne-kent-me10-1eu/613541",
          rent: "£1,995 per month"
        },
        { 
          title: "2-bed Flat – Russet Walk, Greenhithe", 
          address: "Russet Walk, Greenhithe, DA9 9WY", 
          url: "https://jtpropertyconsultants.co.uk/property/2-bed-flat-to-rent-in-russet-walk-greenhithe-da9-9wy/666749",
          rent: "£1,500 per month"
        },
        { 
          title: "2-bed Ground Floor Flat – Henshaaws Vale", 
          address: "Henshaaws Vale, Sittingbourne, Kent, ME10 3NY", 
          url: "https://jtpropertyconsultants.co.uk/property/2-bed-ground-floor-flat-to-rent-in-henshaaws-vale-sittingbourne-kent-me10-3ny/613542",
          rent: "£1,300 per month"
        },
        { 
          title: "1-bed Flat – Park Road, Sittingbourne", 
          address: "Park Road, Sittingbourne, ME10 1DY", 
          url: "https://jtpropertyconsultants.co.uk/property/1-bed-flat-to-rent-in-park-road-sittingbourne-me10-1dy/670583",
          rent: "£895 per month"
        },
        { 
          title: "1-bed Flat – Portland Avenue, Sittingbourne", 
          address: "Portland Avenue, Sittingbourne, Kent, ME10 3QZ", 
          url: "https://jtpropertyconsultants.co.uk/property/1-bed-flat-to-rent-in-portland-avenue-sittingbourne-kent-me10-3qz/663031",
          rent: "£875 per month"
        },
        { 
          title: "Shop – Sidcup Road, London", 
          address: "Sidcup Road, London, SE9 3NS", 
          url: "https://jtpropertyconsultants.co.uk/property/shop-to-rent-in-sidcup-road-london-se9-3ns/662799",
          rent: "£1,500 per month"
        }
      ];
      setAvailableProperties(properties);
    } catch (error) {
      console.error('Failed to load properties:', error);
      toast({
        title: "Property Loading Error",
        description: "Using cached property listings.",
        variant: "destructive"
      });
    } finally {
      setIsLoadingProperties(false);
    }
  };

  const addBotMessage = (text: string, showInput: boolean = false, inputType: 'text' | 'number' | 'email' | 'tel' = 'text', placeholder: string = '', options: string[] = []) => {
    const message: Message = {
      id: Date.now().toString(),
      text,
      isBot: true,
      timestamp: new Date(),
      showInput,
      inputType,
      placeholder,
      options
    };
    setMessages(prev => [...prev, message]);
  };

  const addUserMessage = (text: string) => {
    const message: Message = {
      id: Date.now().toString(),
      text,
      isBot: false,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, message]);
  };

  const fuzzyMatchProperties = (input: string): Property[] => {
    if (!input || input.trim().length === 0) return [];
    
    const inputLower = input.toLowerCase().trim();
    const matches: Property[] = [];
    
    // Handle common misspellings and abbreviations
    const normalizedInput = inputLower
      .replace(/\bval\b/g, 'vale')
      .replace(/\bmiltn\b/g, 'milton')
      .replace(/\bflatt\b/g, 'flat')
      .replace(/\brd\b/g, 'road')
      .replace(/\bst\b/g, 'street')
      .replace(/\bave\b/g, 'avenue');
    
    for (const property of availableProperties) {
      const titleLower = property.title.toLowerCase();
      const addressLower = property.address.toLowerCase();
      let score = 0;
      
      // Exact phrase matching gets highest score
      if (titleLower.includes(normalizedInput) || addressLower.includes(normalizedInput)) {
        score = 100;
      }
      
      // Original input matching
      if (score === 0 && (titleLower.includes(inputLower) || addressLower.includes(inputLower))) {
        score = 90;
      }
      
      // Word-by-word fuzzy matching
      if (score === 0) {
        const inputWords = normalizedInput.split(/\s+/).filter(w => w.length > 1);
        const titleWords = titleLower.split(/\s+/);
        const addressWords = addressLower.split(/\s+/);
        
        let matchedWords = 0;
        for (const word of inputWords) {
          if (titleWords.some(tw => tw.includes(word) || word.includes(tw)) ||
              addressWords.some(aw => aw.includes(word) || word.includes(aw))) {
            matchedWords++;
          }
        }
        
        if (matchedWords > 0) {
          score = (matchedWords / inputWords.length) * 80;
        }
      }
      
      // Partial character matching for very close misspellings
      if (score === 0) {
        const titleChars = titleLower.replace(/\s+/g, '');
        const inputChars = normalizedInput.replace(/\s+/g, '');
        if (titleChars.length > 0 && inputChars.length > 2) {
          let commonChars = 0;
          for (let i = 0; i < Math.min(titleChars.length, inputChars.length); i++) {
            if (titleChars.includes(inputChars[i])) commonChars++;
          }
          const similarity = commonChars / Math.max(titleChars.length, inputChars.length);
          if (similarity > 0.6) {
            score = similarity * 60;
          }
        }
      }
      
      if (score > 30) { // Minimum score threshold
        matches.push({ ...property, score });
      }
    }
    
    // Sort by score and return top matches
    return matches
      .sort((a, b) => (b.score || 0) - (a.score || 0))
      .slice(0, 1); // Return only the best match for confirmation
  };

  const showPropertyListFallback = () => {
    setShowPropertyList(true);
    setPropertyListPage(0);
    
    const propertiesPerPage = 5;
    const totalPages = Math.ceil(availableProperties.length / propertiesPerPage);
    const currentProperties = availableProperties.slice(0, propertiesPerPage);
    
    let listMessage = "I couldn't match your property input. Please select one from the list below to continue:\n\n";
    currentProperties.forEach((prop, index) => {
      listMessage += `${index + 1}. ${prop.title}\n`;
    });
    
    if (totalPages > 1) {
      listMessage += "\nSee More Properties...";
    }
    
    const options = [
      ...currentProperties.map((_, index) => `${index + 1}`),
      ...(totalPages > 1 ? ['See More'] : []),
      'Browse All Properties',
      'Try Again',
      'Raise a Ticket'
    ];
    
    addBotMessage(listMessage, false, 'text', '', options);
  };

  const fuzzyMatch = (input: string, options: string[]): string | null => {
    const inputLower = input.toLowerCase().trim();
    
    // Exact match first
    for (const option of options) {
      if (option.toLowerCase().includes(inputLower) || inputLower.includes(option.toLowerCase())) {
        return option;
      }
    }
    
    // Fuzzy matching for common variations
    const variations: { [key: string]: string } = {
      'self emploied': 'Self-Employed',
      'self employed': 'Self-Employed',
      'unemployed': 'Unemployed',
      'employed': 'Employed',
      'yes': 'Yes',
      'no': 'No',
      'morning': 'Morning',
      'afternoon': 'Afternoon',
      'evening': 'After 5pm',
      'after 5': 'After 5pm',
      'phone': 'Phone',
      'call': 'Phone',
      'email': 'Email',
      'either': 'Either',
      'both': 'Either',
      'asap': 'ASAP',
      '2 weeks': 'Within 2 weeks',
      'within 2 weeks': 'Within 2 weeks',
      'one month': 'I need to give one months notice',
      'one months notice': 'I need to give one months notice',
      '1 month': 'I need to give one months notice',
      'dont know': "I don't know",
      "don't know": "I don't know",
      "idk": "I don't know",
      "not needed": "Not needed",
      "dont need": "Not needed",
      "no need": "Not needed"
    };
    
    for (const [key, value] of Object.entries(variations)) {
      if (inputLower === key) {
        return value;
      }
    }
    
    return null;
  };

  const handleUserInput = () => {
    if (!currentInput.trim()) return;

    addUserMessage(currentInput);
    processStep(currentInput.trim());
    setCurrentInput('');
  };

  const handleOptionClick = (option: string) => {
    if (option === 'Browse All Properties') {
      setShowPropertyBrowser(true);
      return;
    }
    
    if (option === 'Try Again') {
      setShowPropertyList(false);
      setAwaitingPropertyConfirmation(false);
      setPropertyMatches([]);
      addBotMessage("No problem! Let's try that again.");
      setTimeout(() => {
        if (currentStep === 1) {
          addBotMessage("Which property are you interested in?", true, 'text', 'Type property name or click "Browse All Properties" to see the full list');
        } else {
          const currentMessage = messages[messages.length - 2];
          if (currentMessage) {
            addBotMessage(currentMessage.text, true, currentMessage.inputType, currentMessage.placeholder, currentMessage.options);
          }
        }
      }, 1000);
      return;
    }
    
    if (option === 'Start Over') {
      setCurrentStep(1);
      setPropertyMatches([]);
      setShowPropertyList(false);
      setAwaitingPropertyConfirmation(false);
      setData({
        property: '',
        fullName: '',
        adults: 0,
        children: 0,
        adultIncomes: [],
        totalIncome: 0,
        employmentStatuses: [],
        taxReturnYears: 0,
        hasPets: '',
        petDetails: '',
        smokes: '',
        moveDate: '',
        hasAdverseCredit: '',
        needsGuarantor: '',
        noticePeriod: 0,
        email: '',
        mobile: '',
        contactMethod: '',
        consent: false,
        paymentFrequency: '',
        paymentAmount: 0,
        additionalDetails: ''
      });
      setMessages([]);
      addBotMessage("Let's start fresh! Which property are you interested in?", true, 'text', 'Type property name or click "Browse All Properties" to see the full list');
      return;
    }
    
    if (option === 'Raise a Ticket') {
      handleRaiseTicket();
      return;
    }
    
    // Handle property-specific options
    if (currentStep === 1) {
      if (awaitingPropertyConfirmation && option === 'Yes' && propertyMatches.length === 1) {
        const selectedProperty = propertyMatches[0];
        setData(prev => ({ ...prev, property: selectedProperty.title }));
        setAwaitingPropertyConfirmation(false);
        setPropertyMatches([]);
        addBotMessage(`Great – we've selected "${selectedProperty.title}". Let's continue.`);
        setTimeout(() => {
          addBotMessage("Can you tell us your full name?", true, 'text', 'e.g. John Smith');
          setCurrentStep(2);
        }, 1000);
        return;
      } else if (awaitingPropertyConfirmation && option === 'No') {
        setAwaitingPropertyConfirmation(false);
        setPropertyMatches([]);
        showPropertyListFallback();
        return;
      } else if (showPropertyList && option === 'See More') {
        const propertiesPerPage = 5;
        const nextPage = propertyListPage + 1;
        const startIndex = nextPage * propertiesPerPage;
        const endIndex = Math.min(startIndex + propertiesPerPage, availableProperties.length);
        const nextProperties = availableProperties.slice(startIndex, endIndex);
        
        if (nextProperties.length > 0) {
          setPropertyListPage(nextPage);
          let listMessage = "Here are more properties:\n\n";
          nextProperties.forEach((prop, index) => {
            listMessage += `${startIndex + index + 1}. ${prop.title}\n`;
          });
          
          const hasMore = endIndex < availableProperties.length;
          const options = [
            ...nextProperties.map((_, index) => `${startIndex + index + 1}`),
            ...(hasMore ? ['See More'] : []),
            'Browse All Properties',
            'Try Again',
            'Raise a Ticket'
          ];
          
          addBotMessage(listMessage, false, 'text', '', options);
        }
        return;
      } else if (option.match(/^\d+$/)) {
        const index = parseInt(option) - 1;
        if (index >= 0 && index < availableProperties.length) {
          const selectedProperty = availableProperties[index];
          setData(prev => ({ ...prev, property: selectedProperty.title }));
          setShowPropertyList(false);
          setPropertyMatches([]);
          addBotMessage(`Great – we've selected "${selectedProperty.title}". Let's continue.`);
          setTimeout(() => {
            addBotMessage("What's your full name?", true, 'text', 'e.g. John Smith');
            setCurrentStep(2);
          }, 1000);
          return;
        }
      }
    }
    
    addUserMessage(option);
    processStep(option);
  };

  const PropertyBrowser = () => (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-bold">All Available Properties</h2>
          <Button variant="outline" onClick={() => setShowPropertyBrowser(false)}>
            Close
          </Button>
        </div>
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <div className="grid gap-4">
            {availableProperties.map((property, index) => (
              <div key={index} className="border rounded-lg p-4 hover:bg-slate-50">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-slate-800">{property.title}</h3>
                    <p className="text-slate-600 text-sm mt-1">{property.address}</p>
                    {property.rent && (
                      <p className="text-emerald-600 font-semibold mt-2">{property.rent}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        window.open(property.url, '_blank');
                      }}
                    >
                      View Details
                    </Button>
                    <Button
                      size="sm"
                      className="bg-emerald-600 hover:bg-emerald-700"
                      onClick={() => {
                        setData(prev => ({ ...prev, property: property.title }));
                        setShowPropertyBrowser(false);
                        addUserMessage(property.title);
                        processStep(property.title);
                      }}
                    >
                      Select This Property
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 p-4 bg-slate-100 rounded-lg">
            <p className="text-sm text-slate-600">
              Click "View Details" to open the full property listing in a new tab, or "Select This Property" to continue with your application.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );

  const processStep = (input: string) => {
    switch (currentStep) {
      case 1: // Property
        if (isLoadingProperties) {
          addBotMessage("I'm still loading our property listings. Please wait a moment...");
          setTimeout(() => {
            addBotMessage("Which property are you interested in?", true, 'text', 'e.g. Milton Road flat, Vale Road house');
          }, 2000);
          return;
        }

        // Handle empty or very short input
        if (!input || input.trim().length < 2) {
          showPropertyListFallback();
          return;
        }

        const matches = fuzzyMatchProperties(input);
        
        if (matches.length === 0) {
          // No matches found - show property list
          showPropertyListFallback();
        } else {
          // Single best match - ask for confirmation
          setPropertyMatches(matches);
          setAwaitingPropertyConfirmation(true);
          addBotMessage(`Did you mean "${matches[0].title}"?`, false, 'text', '', ['Yes', 'No']);
        }
        break;

      case 2: // Full name
        if (input.length < 2) {
          addBotMessage("That doesn't look like a full name. Would you like to try again or raise a ticket?", false, 'text', '', ['Try Again', 'Start Over', 'Raise a Ticket']);
        } else {
          setData(prev => ({ ...prev, fullName: input }));
          addBotMessage(`Nice to meet you, ${input}!`);
          setTimeout(() => {
            addBotMessage("How many adults aged 18 or over will be living at the property?", true, 'number', 'e.g. 2');
            setCurrentStep(3);
          }, 1000);
        }
        break;

      case 3: // Adults count
        const adults = parseInt(input);
        if (isNaN(adults) || adults < 1 || adults > 10) {
          addBotMessage("Please enter a valid number of adults (1-10). Would you like to try again or raise a ticket?", false, 'text', '', ['Try Again', 'Start Over', 'Raise a Ticket']);
        } else {
          setData(prev => ({ 
            ...prev, 
            adults,
            adultIncomes: Array(adults).fill(0),
            employmentStatuses: Array(adults).fill('')
          }));
          addBotMessage(`Got it, ${adults} adult${adults > 1 ? 's' : ''}.`);
          setTimeout(() => {
            addBotMessage("How many children under 18 will be living there?", true, 'number', 'e.g. 1 (or 0 for none)');
            setCurrentStep(4);
          }, 1000);
        }
        break;

      case 4: // Children
        const children = parseInt(input);
        if (children >= 0 && children <= 10) {
          setData(prev => ({ ...prev, children }));
          addBotMessage(`Perfect! When would you like to move in?`);
          setTimeout(() => {
            addBotMessage("Move-in preference:", false, 'text', '', ['ASAP', 'Within 2 weeks', 'I need to give one months notice']);
            setCurrentStep(4.5);
          }, 1000);
        } else {
          addBotMessage("Please enter a valid number of children (0-10).", true, 'number', '0, 1, 2...');
        }
        break;

      case 4.5: // Move-in Date
        const moveMatch = fuzzyMatch(input, ['ASAP', 'Within 2 weeks', 'I need to give one months notice']);
        if (moveMatch) {
          setData(prev => ({ ...prev, moveDate: moveMatch }));
          addBotMessage(`Great! Now, to help us estimate your annual income, how are you normally paid?`);
          setTimeout(() => {
            addBotMessage("Payment frequency:", false, 'text', '', ['Weekly', 'Monthly', 'Annually']);
            setCurrentStep(5);
          }, 1000);
        } else {
          addBotMessage("Please select a valid option.", false, 'text', '', ['ASAP', 'Within 2 weeks', 'I need to give one months notice']);
        }
        break;

      case 5: // Payment Frequency
        setData(prev => ({ ...prev, paymentFrequency: input }));
        let paymentPrompt = '';
        let placeholder = '';
        
        if (input === 'Weekly') {
          paymentPrompt = 'Roughly how much do you get paid each week? (You can enter in 100s or 1000s)';
          placeholder = 'e.g. 500, 800, 1200';
        } else if (input === 'Monthly') {
          paymentPrompt = 'Roughly how much do you get paid each month? (You can enter in 100s or 1000s)';
          placeholder = 'e.g. 2000, 3500, 5000';
        } else if (input === 'Annually') {
          paymentPrompt = 'Please enter your total annual salary before tax (in 100s or 1000s).';
          placeholder = 'e.g. 25000, 45000, 80000';
        }
        
        addBotMessage(paymentPrompt);
        setTimeout(() => {
          addBotMessage("Payment amount (£):", true, 'number', placeholder);
          setCurrentStep(6);
        }, 1000);
        break;

      case 6: // Payment Amount
        const amount = parseFloat(input);
        if (amount >= 0) {
          setData(prev => ({ ...prev, paymentAmount: amount }));
          
          // Calculate annual income
          let annualIncome = 0;
          if (data.paymentFrequency === 'Weekly') {
            annualIncome = amount * 52;
          } else if (data.paymentFrequency === 'Monthly') {
            annualIncome = amount * 12;
          } else if (data.paymentFrequency === 'Annually') {
            annualIncome = amount;
          }
          
          setData(prev => ({ ...prev, totalIncome: annualIncome }));
          const affordableRent = Math.floor(annualIncome * 0.3 / 12);
          
          addBotMessage(`Thanks, we've estimated your annual income as £${annualIncome.toLocaleString()}. Based on this, you could afford around £${affordableRent}/month in rent. Let's continue.`);
          setTimeout(() => {
            addBotMessage("Can you tell us your employment status?", false, 'text', '', ['Employed', 'Self-Employed', 'Unemployed', 'Student', 'Retired']);
            setCurrentStep(7);
          }, 1500);
        } else {
          addBotMessage("Please enter a valid amount.", true, 'number', 'e.g. 2000, 3500');
        }
        break;

      case 7: // Employment Status
        const employmentMatch = fuzzyMatch(input, ['Employed', 'Self-Employed', 'Unemployed', 'Student', 'Retired']);
        if (employmentMatch) {
          setData(prev => ({ ...prev, employmentStatuses: [employmentMatch] }));
          addBotMessage(`Thanks! Roughly how many years of tax returns can you provide?`);
          setTimeout(() => {
            addBotMessage("Years of tax returns:", true, 'number', '1, 2, 3...');
            setCurrentStep(8);
          }, 1000);
        } else {
          addBotMessage("Please select a valid employment status.", false, 'text', '', ['Employed', 'Self-Employed', 'Unemployed', 'Student', 'Retired']);
        }
        break;

      case 8: // Tax Returns
        const taxYears = parseInt(input);
        if (taxYears >= 0 && taxYears <= 10) {
          setData(prev => ({ ...prev, taxReturnYears: taxYears }));
          addBotMessage(`Great! Can you tell us if you have any pets?`);
          setTimeout(() => {
            addBotMessage("Do you have pets?", false, 'text', '', ['Yes', 'No']);
            setCurrentStep(9);
          }, 1000);
        } else {
          addBotMessage("Please enter a valid number of years (0-10).", true, 'number', '1, 2, 3...');
        }
        break;

      case 9: // Pets
        const petsMatch = fuzzyMatch(input, ['Yes', 'No']);
        if (petsMatch) {
          setData(prev => ({ ...prev, hasPets: petsMatch }));
          if (petsMatch === 'Yes') {
            addBotMessage(`Great! Can you tell us what pets you have?`);
            setTimeout(() => {
              addBotMessage("Pet details:", true, 'text', 'e.g. 1 cat, 2 dogs, budgie');
              setCurrentStep(9.5); // Sub-step for pet details
            }, 1000);
          } else {
            addBotMessage(`Noted! Can you tell us if you smoke?`);
            setTimeout(() => {
              addBotMessage("Do you smoke?", false, 'text', '', ['Yes', 'No']);
              setCurrentStep(10);
            }, 1000);
          }
        } else {
          addBotMessage("Please answer Yes or No.", false, 'text', '', ['Yes', 'No']);
        }
        break;

      case 9.5: // Pet Details
        if (input.trim().length >= 3) {
          setData(prev => ({ ...prev, petDetails: input }));
          addBotMessage(`Perfect! Can you tell us if you smoke?`);
          setTimeout(() => {
            addBotMessage("Do you smoke?", false, 'text', '', ['Yes', 'No']);
            setCurrentStep(10);
          }, 1000);
        } else {
          addBotMessage("Please provide details about your pets.", true, 'text', 'e.g. 1 cat, 2 dogs, budgie');
        }
        break;

      case 10: // Smoking
        const smokingMatch = fuzzyMatch(input, ['Yes', 'No']);
        if (smokingMatch) {
          setData(prev => ({ ...prev, smokes: smokingMatch }));
          addBotMessage(`Thanks for letting us know. Can you tell us if you have any adverse credit history (CCJs, IVAs, missed payments)?`);
          setTimeout(() => {
            addBotMessage("Any adverse credit?", false, 'text', '', ['Yes', 'No', "I don't know"]);
            setCurrentStep(11);
          }, 1000);
        } else {
          addBotMessage("Please answer Yes or No.", false, 'text', '', ['Yes', 'No']);
        }
        break;

      case 11: // Adverse Credit
        const creditMatch = fuzzyMatch(input, ['Yes', 'No', "I don't know"]);
        if (creditMatch) {
          setData(prev => ({ ...prev, hasAdverseCredit: creditMatch }));
          addBotMessage(`Understood. Do you need a UK based guarantor?`);
          setTimeout(() => {
            addBotMessage("Need UK guarantor?", false, 'text', '', ['Yes', 'No', 'Not needed']);
            setCurrentStep(12);
          }, 1000);
        } else {
          addBotMessage("Please select an option.", false, 'text', '', ['Yes', 'No', "I don't know"]);
        }
        break;

      case 12: // Guarantor
        const guarantorMatch = fuzzyMatch(input, ['Yes', 'No', 'Not needed']);
        if (guarantorMatch) {
          setData(prev => ({ ...prev, needsGuarantor: guarantorMatch }));
          addBotMessage(`Got it! Roughly how much notice do you need to give your current landlord or agent?`);
          setTimeout(() => {
            addBotMessage("Notice period (weeks):", true, 'text', 'e.g. 4, 8, 12, or write "none", "zero", or "0"');
            setCurrentStep(13);
          }, 1000);
        } else {
          addBotMessage("Please select an option.", false, 'text', '', ['Yes', 'No', 'Not needed']);
        }
        break;

      case 13: // Notice Period
        // Handle text inputs like "none", "zero", "0" as 0
        const normalizedInput = input.toLowerCase().trim();
        let noticePeriod: number;
        
        if (normalizedInput === 'none' || normalizedInput === 'zero') {
          noticePeriod = 0;
        } else {
          noticePeriod = parseInt(input);
        }
        
        if (!isNaN(noticePeriod) && noticePeriod >= 0 && noticePeriod <= 52) {
          setData(prev => ({ ...prev, noticePeriod }));
          addBotMessage(`Perfect! Now for contact details. Can you tell us your email address?`);
          setTimeout(() => {
            addBotMessage("Email address:", true, 'email', 'your.email@example.com');
            setCurrentStep(14);
          }, 1000);
        } else {
          addBotMessage("Please enter a valid notice period in weeks (0-52) or write 'none'.", true, 'text', 'e.g. 4, 8, 12, or "none"');
        }
        break;

      case 14: // Email
        if (input.includes('@') && input.includes('.')) {
          setData(prev => ({ ...prev, email: input }));
          addBotMessage(`Great! Can you tell us your mobile number?`);
          setTimeout(() => {
            addBotMessage("Mobile number:", true, 'tel', 'e.g. 07123 456789');
            setCurrentStep(15);
          }, 1000);
        } else {
          addBotMessage("Please enter a valid email address.", true, 'email', 'your.email@example.com');
        }
        break;

      case 15: // Mobile
        if (input.length >= 10) {
          setData(prev => ({ ...prev, mobile: input }));
          addBotMessage(`Excellent! How would you prefer us to contact you?`);
          setTimeout(() => {
            addBotMessage("Preferred contact method:", false, 'text', '', ['Phone', 'Email', 'Either']);
            setCurrentStep(16);
          }, 1000);
        } else {
          addBotMessage("Please enter a valid mobile number.", true, 'tel', 'e.g. 07123 456789');
        }
        break;

      case 16: // Contact Method
        const methodMatch = fuzzyMatch(input, ['Phone', 'Email', 'Either']);
        if (methodMatch) {
          setData(prev => ({ ...prev, contactMethod: methodMatch }));
          addBotMessage(`Great! Please provide any additional information you'd like to add to your application. This field is required.`);
          setTimeout(() => {
            addBotMessage("Additional information (required):", true, 'text', 'e.g. viewing preferences, specific requirements, move-in date...');
            setCurrentStep(17);
          }, 1000);
        } else {
          addBotMessage("Please select a valid contact method.", false, 'text', '', ['Phone', 'Email', 'Either']);
        }
        break;

      case 17: // Additional Information
        if (input.trim().length < 3) {
          addBotMessage("Please provide some additional information for your application. This field is required and must be at least 3 characters.", true, 'text', 'e.g. viewing preferences, specific requirements, move-in date...');
        } else {
          setData(prev => ({ ...prev, additionalDetails: input }));
          addBotMessage(`Thank you! Finally, do you consent to us processing your data for this rental application?`);
          setTimeout(() => {
            addBotMessage("Data processing consent:", false, 'text', '', ['Yes, I consent', 'No']);
            setCurrentStep(18);
          }, 1000);
        }
        break;

      case 18: // Consent
        const consentMatch = fuzzyMatch(input, ['Yes, I consent', 'No']);
        if (consentMatch === 'Yes, I consent') {
          setData(prev => ({ ...prev, consent: true }));
          addBotMessage(`Perfect! Let me show you a summary of your application for review.`);
          setTimeout(() => {
            setIsReviewing(true);
            setCurrentStep(19);
          }, 1000);
        } else if (consentMatch === 'No') {
          addBotMessage("I understand. Unfortunately, we cannot process your application without your consent. Would you like to start over or contact our support team?", false, 'text', '', ['Start Over', 'Raise a Ticket']);
        } else {
          addBotMessage("Please select Yes or No.", false, 'text', '', ['Yes, I consent', 'No']);
        }
        break;
    }
  };



  const handleRaiseTicket = () => {
    const timestamp = new Date().toLocaleString();
    const subject = `Bot Ticket – ${timestamp}`;
    const currentQuestion = messages[messages.length - 2]?.text || 'Unknown question';
    const userInput = messages[messages.length - 1]?.text || 'No input provided';
    
    const body = `Conversational Bot Support Ticket

Time: ${timestamp}
Failed Question: ${currentQuestion}
User Input: ${userInput}
Current Step: ${currentStep}

User Data So Far:
${JSON.stringify(data, null, 2)}

Issue: User requested assistance with bot conversation flow.

Please investigate and provide support.`;

    const mailtoLink = `mailto:support@jtpropertyconsultants.co.uk?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
    
    toast({
      title: "Support Ticket Created",
      description: "Your email client will open with a support request.",
    });
  };

  const handleSubmit = async () => {
    if (!data.consent) {
      toast({
        title: "Consent Required",
        description: "Please confirm your consent before submitting.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const applicationData = {
        fullName: data.fullName,
        email: data.email,
        phone: data.mobile,
        moveDate: data.moveDate,
        adults: data.adults,
        children: data.children,
        rentalPeriod: '1-year', // Default value
        hasPets: data.hasPets === 'Yes',
        petDetails: data.petDetails || '',
        smokes: data.smokes === 'Yes',
        occupation: data.employmentStatuses[0] || 'employed',
        hasTaxReturns: data.taxReturnYears > 0,
        annualIncome: data.totalIncome.toString(),
        hasCCJIVA: data.hasAdverseCredit === 'Yes',
        hasGuarantor: data.needsGuarantor === 'Yes',
        contactTime: data.contactMethod,
        contactMethod: data.contactMethod,
        additionalNotes: data.additionalDetails
      };

      await apiRequest("POST", "/api/applications", applicationData);
      
      addBotMessage("🎉 Thanks! Your application has been sent. We'll be in touch soon. Reference: TENAFYI-" + Date.now());
      
      setTimeout(() => {
        onReturn();
      }, 3000);

    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Please try again or contact support.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isReviewing) {
    const affordability = Math.round(data.totalIncome / 30);
    
    return (
      <div className="min-h-screen bg-slate-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <Button variant="outline" onClick={() => setIsReviewing(false)}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Chat
              </Button>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-6 h-6 text-emerald-600" />
                <span className="font-semibold text-slate-800">Application Summary</span>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-4xl mx-auto px-6 py-8">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-2xl font-bold text-slate-800 mb-6">Here's everything you've told me:</h2>
              
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800">Property & Personal</h3>
                  <div className="space-y-2 text-sm">
                    <div><span className="font-medium">Property:</span> {data.property}</div>
                    <div><span className="font-medium">Name:</span> {data.fullName}</div>
                    <div><span className="font-medium">Household:</span> {data.adults} adults, {data.children} children</div>
                    <div><span className="font-medium">Move-in:</span> {data.moveDate}</div>
                    <div><span className="font-medium">Email:</span> {data.email}</div>
                    <div><span className="font-medium">Mobile:</span> {data.mobile}</div>
                    <div><span className="font-medium">Contact Method:</span> {data.contactMethod}</div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800">Financial & Lifestyle</h3>
                  <div className="space-y-2 text-sm">
                    <div><span className="font-medium">Total Income:</span> £{data.totalIncome.toLocaleString()}</div>
                    <div><span className="font-medium">Affordability:</span> £{affordability.toLocaleString()}/month</div>
                    <div><span className="font-medium">Employment:</span> {data.employmentStatuses.join(', ')}</div>
                    <div><span className="font-medium">Tax Returns:</span> {data.taxReturnYears} years</div>
                    <div><span className="font-medium">Pets:</span> {data.hasPets}</div>
                    {data.petDetails && <div><span className="font-medium">Pet Details:</span> {data.petDetails}</div>}
                    <div><span className="font-medium">Smoking:</span> {data.smokes}</div>
                    <div><span className="font-medium">Credit Issues:</span> {data.hasAdverseCredit}</div>
                    <div><span className="font-medium">UK Guarantor:</span> {data.needsGuarantor}</div>
                    <div><span className="font-medium">Notice Period:</span> {data.noticePeriod} weeks</div>
                  </div>
                </div>
              </div>

              {data.additionalDetails && (
                <div className="mb-8">
                  <h3 className="font-semibold text-lg text-slate-800 mb-2">Additional Information</h3>
                  <div className="bg-slate-50 border rounded-lg p-4 text-sm">
                    {data.additionalDetails}
                  </div>
                </div>
              )}

              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                <p className="text-emerald-800">
                  Would you like to make any changes before we send it off?
                </p>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setIsReviewing(false)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Make Changes
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? "Sending..." : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send My Application
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <>
      {showPropertyBrowser && <PropertyBrowser />}
      <div className="min-h-screen bg-slate-50 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <Button variant="outline" onClick={onReturn}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Return Home
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                  <Home className="w-4 h-4 text-white" />
                </div>
                <span className="font-semibold text-slate-800">Tenafyi Chat Bot</span>
                <Button variant="outline" size="sm" onClick={() => setShowPropertyBrowser(true)}>
                  Browse All Properties
                </Button>
              </div>
            </div>
          </div>
        </header>

      {/* Chat Container */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-6 py-6">
        <Card className="h-full flex flex-col">
          {/* Messages */}
          <div className="flex-1 p-6 overflow-y-auto space-y-6 max-h-96 md:max-h-[500px]">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}>
                <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                  message.isBot 
                    ? 'bg-emerald-100 text-emerald-900' 
                    : 'bg-blue-500 text-white'
                }`}>
                  <p className="text-sm">{message.text}</p>
                  {message.options && message.options.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {message.options.map((option, index) => (
                        <Button
                          key={`${message.id}-${option}-${index}`}
                          variant="outline"
                          size="sm"
                          onClick={() => handleOptionClick(option)}
                          className="w-full text-xs"
                        >
                          {option}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          {messages.length > 0 && messages[messages.length - 1]?.showInput && (
            <div className="border-t p-6">
              <div className="flex space-x-3">
                <Input
                  value={currentInput}
                  onChange={(e) => setCurrentInput(e.target.value)}
                  placeholder={messages[messages.length - 1]?.placeholder || "Type your response..."}
                  type={messages[messages.length - 1]?.inputType || 'text'}
                  onKeyPress={(e) => e.key === 'Enter' && handleUserInput()}
                  className="flex-1"
                />
                <Button onClick={handleUserInput} disabled={!currentInput.trim()}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <div className="mt-3 flex justify-center space-x-2">
                <Button variant="outline" size="sm" onClick={() => handleOptionClick('Try Again')}>
                  <RotateCcw className="w-3 h-3 mr-1" />
                  Try Again
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleOptionClick('Start Over')}>
                  Start Over
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleOptionClick('Raise a Ticket')} className="text-red-600">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Get Help
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
    </>
  );
}