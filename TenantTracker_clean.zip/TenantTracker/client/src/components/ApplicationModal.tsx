import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CalendarIcon, Mail, Download, MessageSquare } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ApplicationWithNotes } from "@shared/schema";

interface ApplicationModalProps {
  application: ApplicationWithNotes | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: () => void;
}

export function ApplicationModal({ application, isOpen, onClose, onUpdate }: ApplicationModalProps) {
  const [selectedStatus, setSelectedStatus] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const { toast } = useToast();

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PATCH", `/api/admin/applications/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Status Updated",
        description: "Application status has been updated successfully.",
      });
      onUpdate();
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addNoteMutation = useMutation({
    mutationFn: async ({ applicationId, content }: { applicationId: number; content: string }) => {
      await apiRequest("POST", `/api/admin/applications/${applicationId}/notes`, { content });
    },
    onSuccess: () => {
      toast({
        title: "Note Added",
        description: "Internal note has been added successfully.",
      });
      setNoteContent("");
      onUpdate();
    },
    onError: (error) => {
      toast({
        title: "Failed to Add Note",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStatusUpdate = () => {
    if (application && selectedStatus) {
      updateStatusMutation.mutate({ id: application.id, status: selectedStatus });
    }
  };

  const handleAddNote = () => {
    if (application && noteContent.trim()) {
      addNoteMutation.mutate({ applicationId: application.id, content: noteContent.trim() });
    }
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      'new': 'bg-yellow-100 text-yellow-800',
      'contacted': 'bg-blue-100 text-blue-800',
      'viewing-arranged': 'bg-purple-100 text-purple-800',
      'approved': 'bg-green-100 text-green-800',
      'rejected': 'bg-red-100 text-red-800',
    };

    return (
      <Badge className={colors[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!application) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Application Details</DialogTitle>
        </DialogHeader>

        <div className="space-y-8">
          {/* Applicant Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span className="font-medium">{application.fullName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Email:</span>
                  <a 
                    href={`mailto:${application.email}`}
                    className="font-medium text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                  >
                    {application.email}
                  </a>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Phone:</span>
                  <a 
                    href={`tel:${application.phone}`}
                    className="font-medium text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                  >
                    {application.phone}
                  </a>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Preferred Contact:</span>
                  <span className="font-medium capitalize">{application.contactTime.replace('-', ' ')}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Household Details</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Adults:</span>
                  <span className="font-medium">{application.adults}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Children:</span>
                  <span className="font-medium">{application.children || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Move Date:</span>
                  <span className="font-medium">
                    {application.moveDate === 'asap' ? 'ASAP' : 'In the next few days'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Rental Period:</span>
                  <span className="font-medium capitalize">{application.rentalPeriod.replace('-', ' ')}</span>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Lifestyle & Financial Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Lifestyle</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Pets:</span>
                  <span className="font-medium">{application.hasPets ? 'Yes' : 'No'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Smoking:</span>
                  <span className="font-medium">{application.smokes ? 'Yes' : 'No'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Occupation:</span>
                  <span className="font-medium capitalize">{application.occupation.replace('-', ' ')}</span>
                </div>
                {application.occupation === 'self-employed' && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax Returns:</span>
                    <span className="font-medium">{application.hasTaxReturns ? 'Yes' : 'No'}</span>
                  </div>
                )}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Financial</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Annual Income:</span>
                  <span className="font-medium">£{Number(application.annualIncome).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">CCJ/IVA:</span>
                  <span className="font-medium">{application.hasCCJIVA ? 'Yes' : 'No'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">UK Guarantor:</span>
                  <span className="font-medium">{application.hasGuarantor ? 'Yes' : 'No'}</span>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Status Management */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Status Management</h3>
            <div className="flex items-center space-x-4 mb-4">
              <span className="text-gray-600">Current Status:</span>
              {getStatusBadge(application.status)}
            </div>
            <div className="flex items-center space-x-4">
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Update status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="viewing-arranged">Viewing Arranged</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
              <Button
                onClick={handleStatusUpdate}
                disabled={!selectedStatus || updateStatusMutation.isPending}
              >
                {updateStatusMutation.isPending ? "Updating..." : "Update Status"}
              </Button>
            </div>
          </div>

          <Separator />

          {/* Internal Notes */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Internal Notes</h3>
            <div className="space-y-4">
              {application.notes.length > 0 ? (
                application.notes.map((note) => (
                  <div key={note.id} className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-medium text-gray-900">
                        {note.user.firstName} {note.user.lastName} ({note.user.email})
                      </span>
                      <span className="text-sm text-gray-500">
                        {note.createdAt ? formatDate(note.createdAt.toString()) : 'Unknown date'}
                      </span>
                    </div>
                    <p className="text-gray-700">{note.content}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 italic">No notes added yet.</p>
              )}

              <div className="space-y-2">
                <Textarea
                  rows={3}
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder="Add a new note..."
                  className="w-full"
                />
                <Button
                  onClick={handleAddNote}
                  disabled={!noteContent.trim() || addNoteMutation.isPending}
                  variant="outline"
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  {addNoteMutation.isPending ? "Adding..." : "Add Note"}
                </Button>
              </div>
            </div>
          </div>

          <Separator />

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4">
            <Button className="flex-1 bg-green-600 hover:bg-green-700">
              <CalendarIcon className="mr-2 h-4 w-4" />
              Schedule Viewing
            </Button>
            <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
              <Mail className="mr-2 h-4 w-4" />
              Send Email
            </Button>
            <Button variant="outline" className="px-6">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
