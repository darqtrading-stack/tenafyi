import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Settings, Bot, FormInput, Calculator, FileCheck, Banknote, Shield } from "lucide-react";

export function SettingsPanel() {
  const { toast } = useToast();

  // Fetch settings
  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ['/api/admin/settings'],
  });

  // Fetch letting rules
  const { data: lettingRules, isLoading: rulesLoading } = useQuery({
    queryKey: ['/api/admin/letting-rules'],
  });

  // Update setting mutation
  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: any }) => {
      return await apiRequest('PATCH', `/api/admin/settings/${key}`, { value });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/settings'] });
      toast({
        title: "Setting Updated",
        description: "Your changes have been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update setting. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update letting rule mutation
  const updateRuleMutation = useMutation({
    mutationFn: async ({ name, config }: { name: string; config: any }) => {
      return await apiRequest('PATCH', `/api/admin/letting-rules/${name}`, { config });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/letting-rules'] });
      toast({
        title: "Rule Updated",
        description: "Letting rule has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update letting rule. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleToggleSetting = (key: string, enabled: boolean) => {
    updateSettingMutation.mutate({ key, value: { enabled } });
  };

  const handleUpdateIncomeMultiplier = (multiplier: number) => {
    updateRuleMutation.mutate({
      name: 'income_multiplier',
      config: { multiplier },
    });
  };

  const handleUpdateGuarantorMultiplier = (multiplier: number) => {
    updateRuleMutation.mutate({
      name: 'guarantor_threshold',
      config: { multiplier },
    });
  };

  const handleUpdateSelfEmployedRules = (yearsRequired: number, useProfitNotTurnover: boolean) => {
    updateRuleMutation.mutate({
      name: 'self_employed_tax_returns',
      config: { yearsRequired, useProfitNotTurnover },
    });
  };

  const handleToggleBenefitsAcceptance = (acceptBenefits: boolean, benefitsCountAsIncome: boolean) => {
    updateRuleMutation.mutate({
      name: 'benefits_acceptance',
      config: { acceptBenefits, benefitsCountAsIncome },
    });
  };

  if (settingsLoading || rulesLoading) {
    return <div className="text-center py-8">Loading settings...</div>;
  }

  const aiChatbotEnabled = settings?.ai_chatbot_enabled?.enabled || false;
  const traditionalFormEnabled = settings?.traditional_form_enabled?.enabled !== false;
  const conversationalBotEnabled = settings?.conversational_bot_enabled?.enabled !== false;

  const incomeMultiplier = lettingRules?.income_multiplier?.multiplier || 30;
  const selfEmployedYears = lettingRules?.self_employed_tax_returns?.yearsRequired || 2;
  const useProfitNotTurnover = lettingRules?.self_employed_tax_returns?.useProfitNotTurnover !== false;
  const acceptBenefits = lettingRules?.benefits_acceptance?.acceptBenefits !== false;
  const benefitsCountAsIncome = lettingRules?.benefits_acceptance?.benefitsCountAsIncome !== false;
  const guarantorMultiplier = lettingRules?.guarantor_threshold?.multiplier || 36;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Settings className="h-6 w-6" />
          System Settings
        </h2>
        <p className="text-gray-600 mt-1">Configure application forms and letting rules</p>
      </div>

      {/* Application Forms */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FormInput className="h-5 w-5" />
            Application Forms
          </CardTitle>
          <CardDescription>Choose which application methods are available to tenants</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="ai-chatbot" className="text-base font-medium flex items-center gap-2">
                <Bot className="h-4 w-4 text-purple-500" />
                AI Chatbot (OpenAI Powered)
              </Label>
              <p className="text-sm text-gray-500">
                Intelligent conversational assistant with income calculations and property Q&A
              </p>
            </div>
            <Switch
              id="ai-chatbot"
              checked={aiChatbotEnabled}
              onCheckedChange={(checked) => handleToggleSetting('ai_chatbot_enabled', checked)}
              data-testid="switch-ai-chatbot"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="conversational-bot" className="text-base font-medium">
                Conversational Bot (Rule-Based)
              </Label>
              <p className="text-sm text-gray-500">
                Friendly step-by-step form with predefined questions and property browsing
              </p>
            </div>
            <Switch
              id="conversational-bot"
              checked={conversationalBotEnabled}
              onCheckedChange={(checked) => handleToggleSetting('conversational_bot_enabled', checked)}
              data-testid="switch-conversational-bot"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="traditional-form" className="text-base font-medium">
                Traditional Form
              </Label>
              <p className="text-sm text-gray-500">
                Classic multi-page application form (always available as fallback)
              </p>
            </div>
            <Switch
              id="traditional-form"
              checked={traditionalFormEnabled}
              onCheckedChange={(checked) => handleToggleSetting('traditional_form_enabled', checked)}
              data-testid="switch-traditional-form"
            />
          </div>
        </CardContent>
      </Card>

      {/* Letting Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Income Calculation Rules
          </CardTitle>
          <CardDescription>Configure how tenant income is assessed and validated</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Label htmlFor="income-multiplier" className="flex items-center gap-2">
              <Banknote className="h-4 w-4 text-green-500" />
              Income Multiplier
            </Label>
            <p className="text-sm text-gray-500">
              Required annual income = Monthly rent × {incomeMultiplier}
            </p>
            <div className="flex items-center gap-4">
              <Input
                id="income-multiplier"
                type="number"
                min="1"
                max="100"
                value={incomeMultiplier}
                onChange={(e) => handleUpdateIncomeMultiplier(parseInt(e.target.value) || 30)}
                className="w-32"
                data-testid="input-income-multiplier"
              />
              <span className="text-sm text-gray-600">
                Example: £1,000/month rent = £{(1000 * incomeMultiplier).toLocaleString()} annual income required
              </span>
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <FileCheck className="h-4 w-4 text-blue-500" />
              Self-Employed Requirements
            </Label>
            <div className="space-y-4 ml-6">
              <div className="flex items-center gap-4">
                <Label htmlFor="self-employed-years" className="text-sm w-48">
                  Years of tax returns required:
                </Label>
                <Input
                  id="self-employed-years"
                  type="number"
                  min="1"
                  max="5"
                  value={selfEmployedYears}
                  onChange={(e) => handleUpdateSelfEmployedRules(parseInt(e.target.value) || 2, useProfitNotTurnover)}
                  className="w-24"
                  data-testid="input-self-employed-years"
                />
              </div>
              <div className="flex items-center gap-4">
                <Label htmlFor="use-profit" className="text-sm w-48">
                  Use profit (not turnover):
                </Label>
                <Switch
                  id="use-profit"
                  checked={useProfitNotTurnover}
                  onCheckedChange={(checked) => handleUpdateSelfEmployedRules(selfEmployedYears, checked)}
                  data-testid="switch-use-profit"
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-orange-500" />
              Benefits & Guarantor Policy
            </Label>
            <div className="space-y-4 ml-6">
              <div className="flex items-center gap-4">
                <Label htmlFor="accept-benefits" className="text-sm w-48">
                  Accept benefits as income:
                </Label>
                <Switch
                  id="accept-benefits"
                  checked={acceptBenefits}
                  onCheckedChange={(checked) => handleToggleBenefitsAcceptance(checked, benefitsCountAsIncome)}
                  data-testid="switch-accept-benefits"
                />
              </div>
              <div className="flex items-center gap-4">
                <Label htmlFor="guarantor-multiplier" className="text-sm w-48">
                  Guarantor Income Multiplier:
                </Label>
                <Input
                  id="guarantor-multiplier"
                  type="number"
                  min="1"
                  max="100"
                  value={guarantorMultiplier}
                  onChange={(e) => handleUpdateGuarantorMultiplier(parseInt(e.target.value) || 36)}
                  className="w-24"
                  data-testid="input-guarantor-multiplier"
                />
                <span className="text-sm text-gray-500">
                  Guarantor needs {guarantorMultiplier}× monthly rent annually
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rules Summary */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <h3 className="font-semibold text-blue-900 mb-2">Current Rules Summary</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Rent × {incomeMultiplier} = required annual income</li>
            <li>• Self-employed must provide {selfEmployedYears} years of {useProfitNotTurnover ? 'profit' : 'turnover'}</li>
            <li>• Benefits {acceptBenefits ? 'are accepted' : 'are not accepted'} as income</li>
            <li>• Guarantor must earn {guarantorMultiplier}× monthly rent annually</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
