import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowLeft, Send, RotateCcw, Home, Building, ExternalLink, X, RefreshCw, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  options?: string[];
  showInput?: boolean;
  inputType?: 'text' | 'number' | 'email' | 'tel' | 'textarea';
  placeholder?: string;
  showPropertySelector?: boolean;
}

interface Property {
  id: string;
  title: string;
  price: string;
  beds: string;
  thumbnail: string;
  url: string;
  description: string;
}

interface BotData {
  properties: string[];
  fullName: string;
  adults: number;
  children: number;
  moveDate: string;
  rentalPeriod: string;
  hasPets: string;
  petDetails: string;
  smokes: string;
  occupation: string;
  hasTaxReturns: string;
  annualIncome: number;
  hasCCJIVA: string;
  hasAdverseMedia: string;
  hasGuarantor: string;
  email: string;
  phone: string;
  contactTime: string;
  contactMethod: string;
  additionalNotes: string;
}

interface ConversationalBotProps {
  onReturn: () => void;
}

export function ConversationalBotNew({ onReturn }: ConversationalBotProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [currentInput, setCurrentInput] = useState('');
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [showPropertyBrowser, setShowPropertyBrowser] = useState(false);
  const [isIdle, setIsIdle] = useState(false);
  const [idleTimer, setIdleTimer] = useState<NodeJS.Timeout | null>(null);
  
  const [data, setData] = useState<BotData>({
    properties: [],
    fullName: '',
    adults: 0,
    children: 0,
    moveDate: '',
    rentalPeriod: '',
    hasPets: '',
    petDetails: '',
    smokes: '',
    occupation: '',
    hasTaxReturns: '',
    annualIncome: 0,
    hasCCJIVA: '',
    hasAdverseMedia: '',
    hasGuarantor: '',
    email: '',
    phone: '',
    contactTime: '',
    contactMethod: '',
    additionalNotes: ''
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch properties dynamically from API
  const { data: properties = [], isLoading } = useQuery({
    queryKey: ['/api/properties'],
    queryFn: () => apiRequest('GET', '/api/properties'),
    staleTime: 5 * 60 * 1000, // 5 minutes - property data can become stale
    refetchOnWindowFocus: true, // Refetch when user returns to tab
  });

  // Property refresh mutation
  const refreshPropertiesMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/properties/refresh', {}),
    onSuccess: () => {
      // Invalidate and refetch properties
      queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
      toast({
        title: "Properties Refreshed",
        description: "Property listings have been updated with the latest data.",
      });
    },
    onError: (error) => {
      toast({
        title: "Refresh Failed",
        description: "Unable to refresh properties. Please try again.",
        variant: "destructive",
      });
    }
  });

  const propertyList: Property[] = properties.map((p: any, index: number) => ({
    id: `property-${index}`,
    title: p.title,
    price: p.price,
    beds: p.beds,
    thumbnail: p.thumbnail,
    url: p.url,
    description: p.description
  }));

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => scrollToBottom(), [messages]);

  // Idle detection
  const resetIdleTimer = () => {
    setIsIdle(false);
    if (idleTimer) {
      clearTimeout(idleTimer);
    }
    
    const timer = setTimeout(() => {
      setIsIdle(true);
    }, 60000); // 60 seconds of inactivity
    
    setIdleTimer(timer);
  };

  // Reset idle timer on user interaction
  useEffect(() => {
    resetIdleTimer();
    return () => {
      if (idleTimer) clearTimeout(idleTimer);
    };
  }, [messages, currentInput]);

  const handleFaultReport = () => {
    // Navigate back to landing page where they can report a fault
    onReturn(); // Use the proper return function instead of window.location
  };

  const addBotMessage = (text: string, options?: string[], showInput?: boolean, inputType?: 'text' | 'number' | 'email' | 'tel' | 'textarea', placeholder?: string, showPropertySelector?: boolean) => {
    const message: Message = {
      id: `${Date.now()}-${Math.random()}`,
      text,
      isBot: true,
      timestamp: new Date(),
      options,
      showInput,
      inputType,
      placeholder,
      showPropertySelector
    };
    setMessages(prev => [...prev, message]);
  };

  const addUserMessage = (text: string) => {
    const message: Message = {
      id: `${Date.now()}-${Math.random()}`,
      text,
      isBot: false,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, message]);
  };

  const handlePropertySelect = (propertyTitle: string) => {
    const currentProps = [...data.properties];
    if (currentProps.includes(propertyTitle)) {
      // Remove if already selected
      setData(prev => ({
        ...prev,
        properties: prev.properties.filter(p => p !== propertyTitle)
      }));
    } else {
      // Add to selection
      setData(prev => ({
        ...prev,
        properties: [...prev.properties, propertyTitle]
      }));
    }
  };

  const handleAnswerSelect = (answer: string) => {
    // Prevent multiple clicks
    if (selectedAnswer === answer) return;
    
    setSelectedAnswer(answer);
    // Immediate processing without delay to prevent stalling
    processAnswer(answer);
    setSelectedAnswer('');
  };

  const processAnswer = (answer: string) => {
    addUserMessage(answer);
    
    switch (currentStep) {
      case 1: // Property selection
        if (answer === "Continue with selected properties") {
          if (data.properties.length === 0) {
            addBotMessage("Please select at least one property before continuing.", [], false);
            return;
          }
          setCurrentStep(2);
          addBotMessage(`Great! You've selected ${data.properties.length} propert${data.properties.length === 1 ? 'y' : 'ies'}. Now, what's your full name?`, [], true, 'text', 'Enter your full name');
        } else if (answer === "Browse all properties") {
          setShowPropertyBrowser(true);
        }
        break;
        
      case 2: // Full name
        if (answer.trim().length < 2) {
          addBotMessage("Please enter your full name (at least 2 characters).", [], true, 'text', 'Enter your full name');
          return;
        }
        setData(prev => ({ ...prev, fullName: answer }));
        setCurrentStep(3);
        addBotMessage(`Nice to meet you, ${answer}! How many adults will be living in the property?`, ['1', '2', '3', '4', '5 or more']);
        break;
        
      case 3: // Adults
        const adults = answer === '5 or more' ? 5 : parseInt(answer);
        setData(prev => ({ ...prev, adults }));
        setCurrentStep(4);
        addBotMessage("How many children will be living in the property?", ['0', '1', '2', '3', '4 or more']);
        break;
        
      case 4: // Children
        const children = answer === '4 or more' ? 4 : parseInt(answer);
        setData(prev => ({ ...prev, children }));
        setCurrentStep(5);
        addBotMessage("When would you like to move in?", ['ASAP', 'Within 2 weeks', 'I need to give one months notice', 'Flexible']);
        break;
        
      case 5: // Move date
        setData(prev => ({ ...prev, moveDate: answer }));
        setCurrentStep(6);
        addBotMessage("How long would you like to rent for?", ['6 months', '1 year', '2+ years']);
        break;
        
      case 6: // Rental period
        setData(prev => ({ ...prev, rentalPeriod: answer }));
        setCurrentStep(7);
        addBotMessage("Do you have any pets?", ['No', 'Yes']);
        break;
        
      case 7: // Pets
        setData(prev => ({ ...prev, hasPets: answer }));
        if (answer === 'Yes') {
          setCurrentStep(8);
          addBotMessage("Please tell us about your pets:", [], true, 'textarea', 'Type of pet, breed, size, age, etc.');
        } else {
          setCurrentStep(9);
          addBotMessage("Do you smoke?", ['No', 'Yes']);
        }
        break;
        
      case 8: // Pet details
        setData(prev => ({ ...prev, petDetails: answer }));
        setCurrentStep(9);
        addBotMessage("Do you smoke?", ['No', 'Yes']);
        break;
        
      case 9: // Smoking
        setData(prev => ({ ...prev, smokes: answer }));
        setCurrentStep(10);
        addBotMessage("What's your employment status?", ['Employed', 'Self-employed', 'Unemployed', 'Student', 'Retired']);
        break;
        
      case 10: // Employment
        setData(prev => ({ ...prev, occupation: answer }));
        if (answer === 'Self-Employed') {
          setCurrentStep(11);
          addBotMessage("Do you have at least 1 year of tax returns?", ['Yes', 'No']);
        } else {
          setCurrentStep(12);
          addBotMessage("What is your total yearly income before tax?", [], true, 'number', 'Enter amount in £');
        }
        break;
        
      case 11: // Tax returns (Self-employed only)
        setData(prev => ({ ...prev, hasTaxReturns: answer }));
        setCurrentStep(12);
        addBotMessage("What is your total yearly income before tax?", [], true, 'number', 'Enter amount in £');
        break;
        
      case 12: // Annual income
        const income = parseFloat(answer);
        if (isNaN(income) || income < 0) {
          addBotMessage("Please enter a valid income amount.", [], true, 'number', 'Enter amount in £');
          return;
        }
        setData(prev => ({ ...prev, annualIncome: income }));
        setCurrentStep(13);
        addBotMessage("Do you have any adverse credit history (CCJs, IVAs, defaults)?", ['Yes', 'No', "I don't know"]);
        break;
        
      case 13: // CCJs
        setData(prev => ({ ...prev, hasCCJIVA: answer }));
        setCurrentStep(14);
        addBotMessage("Do you have any adverse media?", ['Yes', 'No', "I don't know"]);
        break;
        
      case 14: // Adverse media
        setData(prev => ({ ...prev, hasAdverseMedia: answer }));
        setCurrentStep(15);
        addBotMessage("Can you provide a UK-based guarantor if needed?", ['Yes', 'No', 'Not needed']);
        break;
        
      case 15: // Guarantor
        setData(prev => ({ ...prev, hasGuarantor: answer }));
        setCurrentStep(16);
        addBotMessage("What's your email address?", [], true, 'email', 'Enter your email');
        break;
        
      case 16: // Email
        if (!answer.includes('@')) {
          addBotMessage("Please enter a valid email address.", [], true, 'email', 'Enter your email');
          return;
        }
        setData(prev => ({ ...prev, email: answer }));
        setCurrentStep(17);
        addBotMessage("What's your phone number?", [], true, 'tel', 'Enter your phone number');
        break;
        
      case 17: // Phone
        setData(prev => ({ ...prev, phone: answer }));
        setCurrentStep(18);
        addBotMessage("When's the best time to contact you?", ['Morning', 'Afternoon', 'Evening', 'Anytime']);
        break;
        
      case 18: // Contact time
        setData(prev => ({ ...prev, contactTime: answer }));
        setCurrentStep(19);
        addBotMessage("How would you prefer to be contacted?", ['Phone call', 'Email', 'Either']);
        break;
        
      case 19: // Contact method
        setData(prev => ({ ...prev, contactMethod: answer }));
        setCurrentStep(20);
        addBotMessage("Any additional notes or questions?", [], true, 'textarea', 'Optional - anything else you\'d like us to know');
        break;
        
      case 20: // Final notes
        setData(prev => ({ ...prev, additionalNotes: answer }));
        setCurrentStep(21);
        showSummary();
        break;
        
      case 21: // Confirmation
        if (answer === 'Yes, submit application') {
          handleSubmit();
        } else if (answer === 'Start over') {
          startOver();
        }
        break;
    }
  };

  const showSummary = () => {
    const summaryParts = [
      `📋 **Application Summary**`,
      ``,
      `**Selected Properties:**`,
      `${data.properties.join(', ')}`,
      ``,
      `**Personal Information:**`,
      `• Full Name: ${data.fullName}`,
      `• Email: ${data.email}`,
      `• Phone: ${data.phone}`,
      `• Best time to contact: ${data.contactTime}`,
      `• Preferred contact method: ${data.contactMethod}`,
      ``,
      `**Household Details:**`,
      `• Adults: ${data.adults}`,
      `• Children: ${data.children}`,
      `• Move-in date: ${data.moveDate}`,
      `• Rental period: ${data.rentalPeriod}`,
      ``,
      `**Lifestyle:**`,
      `• Pets: ${data.hasPets}${data.hasPets === 'Yes' && data.petDetails ? ` (${data.petDetails})` : ''}`,
      `• Smoking: ${data.smokes}`,
      ``,
      `**Employment & Financial:**`,
      `• Occupation: ${data.occupation}`,
      data.occupation === 'Self-employed' ? `• Tax returns available: ${data.hasTaxReturns}` : null,
      `• Annual income: £${data.annualIncome.toLocaleString()} before tax`,
      ``,
      `**Credit & References:**`,
      `• Adverse credit (CCJ/IVA): ${data.hasCCJIVA}`,
      `• Adverse media: ${data.hasAdverseMedia}`,
      `• UK Guarantor available: ${data.hasGuarantor}`,
    ].filter(Boolean); // Remove null entries
    
    if (data.additionalNotes?.trim()) {
      summaryParts.push('', `**Additional Notes:**`, data.additionalNotes);
    }
    
    const summary = summaryParts.join('\n');
    
    addBotMessage(summary);
    addBotMessage("Does everything look correct?", ['Yes, submit application', 'Start over']);
  };

  const handleSubmit = async () => {
    try {
      const applicationData = {
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        moveDate: data.moveDate,
        adults: data.adults,
        children: data.children,
        rentalPeriod: data.rentalPeriod,
        hasPets: data.hasPets === 'Yes',
        petDetails: data.petDetails,
        smokes: data.smokes === 'Yes',
        occupation: data.occupation,
        hasTaxReturns: data.hasTaxReturns === 'Yes',
        annualIncome: data.annualIncome,
        hasCCJIVA: data.hasCCJIVA === 'Yes',
        hasAdverseMedia: data.hasAdverseMedia === 'Yes',
        hasGuarantor: data.hasGuarantor === 'Yes',
        property: data.properties, // Multiple properties
        contactTime: data.contactTime,
        contactMethod: data.contactMethod,
        additionalNotes: data.additionalNotes,
        status: 'new'
      };

      await apiRequest('POST', '/api/applications', applicationData);
      addBotMessage("🎉 Thank you! Your application has been submitted successfully. We'll be in touch soon!");
      
    } catch (error) {
      addBotMessage("Sorry, there was an error submitting your application. Please try again or contact us directly.");
    }
  };

  const goBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
      // Remove last bot message and user response
      setMessages(prev => prev.slice(0, -2));
    }
  };

  const startOver = () => {
    setCurrentStep(1);
    setMessages([]);
    setData({
      properties: [],
      fullName: '',
      adults: 0,
      children: 0,
      moveDate: '',
      rentalPeriod: '',
      hasPets: '',
      petDetails: '',
      smokes: '',
      occupation: '',
      hasTaxReturns: '',
      annualIncome: 0,
      hasCCJIVA: '',
      hasAdverseMedia: '',
      hasGuarantor: '',
      email: '',
      phone: '',
      contactTime: '',
      contactMethod: '',
      additionalNotes: ''
    });
    
    // Restart with property selection
    setTimeout(() => {
      addBotMessage("👋 Welcome back! Let's start fresh. Please select which properties you're interested in:", [], false, undefined, undefined, true);
    }, 500);
  };

  // Initialize on mount
  useEffect(() => {
    if (messages.length === 0) {
      addBotMessage("👋 Hi! Welcome to Tenafyi - Tenant Qualification at its Best! I'm here to help you find your perfect property and complete your tenancy application.", []);
      setTimeout(() => {
        addBotMessage("Let's start by selecting which properties you're interested in from our live listings:", [], false, undefined, undefined, true);
      }, 1500);
    }
  }, []);

  const currentMessage = messages[messages.length - 1];

  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="bg-white border-b p-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" onClick={onReturn}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h2 className="font-semibold text-lg">Tenafyi Chat Assistant</h2>
            <p className="text-sm text-gray-500">Tenant Qualification at its Best</p>
          </div>
        </div>
        <div className="flex space-x-2">
          {currentStep > 1 && (
            <Button variant="outline" size="sm" onClick={goBack}>
              ← Previous
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={startOver}>
            <RotateCcw className="h-4 w-4 mr-1" />
            Start Over
          </Button>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4 max-w-4xl mx-auto">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={`max-w-sm md:max-w-lg px-4 py-3 rounded-lg ${
                  message.isBot
                    ? 'bg-white border border-gray-200 shadow-sm'
                    : 'bg-blue-600 text-white'
                }`}
              >
                <div className="whitespace-pre-wrap">{message.text}</div>
                
                {/* Property Selector */}
                {message.showPropertySelector && (
                  <div className="mt-4 space-y-3">
                    {/* Selected Properties Tags */}
                    {data.properties.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Selected Properties:</div>
                        <div className="flex flex-wrap gap-2">
                          {data.properties.map((propTitle, index) => (
                            <div key={index} className="inline-flex items-center gap-1 bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                              <Building className="h-3 w-3" />
                              <span className="truncate max-w-[150px]" title={propTitle}>{propTitle}</span>
                              <button onClick={() => handlePropertySelect(propTitle)}>
                                <X className="h-3 w-3 hover:text-red-600" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Property Refresh Button */}
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-sm font-medium text-gray-600">
                        {propertyList.length} properties available
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => refreshPropertiesMutation.mutate()}
                        disabled={refreshPropertiesMutation.isPending}
                        className="text-xs"
                      >
                        <RefreshCw className={`w-3 h-3 mr-1 ${refreshPropertiesMutation.isPending ? 'animate-spin' : ''}`} />
                        {refreshPropertiesMutation.isPending ? 'Refreshing...' : 'Refresh'}
                      </Button>
                    </div>

                    {/* Property List */}
                    <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto">
                      {isLoading ? (
                        <div className="text-center py-4 text-gray-500">Loading properties...</div>
                      ) : propertyList.length === 0 ? (
                        <div className="text-center py-4 text-gray-500">
                          <div>No properties available</div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => refreshPropertiesMutation.mutate()}
                            className="mt-2"
                          >
                            <RefreshCw className="w-3 h-3 mr-1" />
                            Refresh Properties
                          </Button>
                        </div>
                      ) : (
                        propertyList.map((property) => {
                          const isSelected = data.properties.includes(property.title);
                          return (
                            <div
                              key={property.id}
                              onClick={() => handlePropertySelect(property.title)}
                              className={`flex items-center space-x-3 p-2 rounded border cursor-pointer transition-all text-xs ${
                                isSelected
                                  ? 'border-green-300 bg-green-50 text-green-800'
                                  : 'border-gray-200 bg-white hover:border-blue-300'
                              }`}
                            >
                              <div className={`flex items-center justify-center w-4 h-4 rounded border ${
                                isSelected ? 'border-green-600 bg-green-600' : 'border-gray-300'
                              }`}>
                                {isSelected && <span className="text-white text-xs">✓</span>}
                              </div>
                              <img src={property.thumbnail} alt="" className="w-8 h-8 object-cover rounded" />
                              <div className="flex-1 min-w-0">
                                <div className="font-medium truncate">{property.title}</div>
                                <div className="text-gray-500">{property.price} • {property.beds}</div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                    
                    {data.properties.length > 0 && (
                      <button 
                        onClick={() => processAnswer("Continue with selected properties")}
                        className="w-full p-4 bg-blue-600 text-white rounded-xl font-medium text-lg hover:bg-blue-700 transition-colors"
                      >
                        Continue with {data.properties.length} selected propert{data.properties.length === 1 ? 'y' : 'ies'}
                      </button>
                    )}
                  </div>
                )}
                
                {/* Answer Options */}
                {message.options && message.options.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {message.options.map((option) => (
                      <button
                        key={option}
                        className={`w-full p-4 text-left rounded-xl border-2 transition-all font-medium text-lg ${
                          selectedAnswer === option 
                            ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-md' 
                            : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50 text-gray-700'
                        }`}
                        onClick={() => handleAnswerSelect(option)}
                        disabled={selectedAnswer !== ''}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-5 h-5 rounded-full border-2 transition-all ${
                            selectedAnswer === option 
                              ? 'bg-blue-500 border-blue-500' 
                              : 'border-gray-300'
                          }`}>
                            {selectedAnswer === option && (
                              <div className="w-full h-full rounded-full bg-white scale-50 border border-blue-500"></div>
                            )}
                          </div>
                          <span>{option}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      {currentMessage?.showInput && (
        <div className="p-4 border-t bg-white">
          <div className="max-w-4xl mx-auto flex space-x-2">
            {currentMessage.inputType === 'textarea' ? (
              <Textarea
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                placeholder={currentMessage.placeholder}
                className="flex-1 text-lg p-4 border-2 rounded-xl focus:border-blue-500"
                rows={3}
              />
            ) : (
              <Input
                type={currentMessage.inputType}
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                placeholder={currentMessage.placeholder}
                className="flex-1 text-lg p-4 h-14 border-2 rounded-xl focus:border-blue-500"
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && currentInput.trim()) {
                    processAnswer(currentInput);
                    setCurrentInput('');
                  }
                }}
              />
            )}
            <button
              onClick={() => {
                if (currentInput.trim()) {
                  processAnswer(currentInput);
                  setCurrentInput('');
                }
              }}
              disabled={!currentInput.trim()}
              className="bg-blue-600 text-white p-4 rounded-xl hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}

      {/* Special handling for final step */}
      {currentStep === 21 && (
        <div className="p-4 border-t bg-white">
          <div className="max-w-4xl mx-auto flex space-x-2">
            <Button 
              onClick={() => {
                addBotMessage("Thank you for using Tenafyi! We appreciate your time. Goodbye! 👋");
                setTimeout(() => {
                  onReturn();
                }, 2000);
              }} 
              className="flex-1 bg-gray-600 hover:bg-gray-700"
            >
              Close Application
            </Button>
          </div>
        </div>
      )}

      {/* Idle State - Fault Report Option */}
      {isIdle && (
        <div className="fixed bottom-4 right-4 z-50 max-w-sm">
          <Card className="bg-orange-50 border-orange-200 shadow-xl">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm font-medium text-orange-800">Need Help?</div>
                  <div className="text-xs text-orange-700 mt-1">
                    Having trouble with the chat? You can continue the conversation or report a technical issue.
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => setIsIdle(false)}
                      className="text-xs"
                      data-testid="button-continue-chat"
                    >
                      Continue Chat
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={handleFaultReport}
                      className="text-xs bg-orange-600 hover:bg-orange-700"
                      data-testid="button-report-issue"
                    >
                      Report Issue
                    </Button>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsIdle(false)}
                  className="p-1 h-auto"
                  data-testid="button-close-help"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}