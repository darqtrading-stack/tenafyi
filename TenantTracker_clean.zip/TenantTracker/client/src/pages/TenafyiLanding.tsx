import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, AlertTriangle, Building2, Users, FileText, ArrowLeft, Sparkles } from "lucide-react";
import { ConversationalBotNew } from "@/components/ConversationalBotNew";
import { AITenantBot } from "@/components/AITenantBot";
import { QuickFaultReport } from "@/components/QuickFaultReport";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Footer } from "@/components/Footer";

export default function TenafyiLanding() {
  const [currentView, setCurrentView] = useState<'landing' | 'choice' | 'bot' | 'ai-bot' | 'fault'>('landing');

  // Fetch public feature toggles to determine which options to show
  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ['/api/settings/public'],
    retry: false,
  });

  if (currentView === 'bot') {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <main className="flex-1 flex flex-col">
          <ConversationalBotNew onReturn={() => setCurrentView('choice')} />
        </main>
        <Footer />
      </div>
    );
  }

  if (currentView === 'ai-bot') {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <div className="flex items-center justify-between">
              <Link href="/">
                <div className="flex items-center space-x-4 cursor-pointer hover:opacity-80 transition-opacity">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-slate-800">AI Tenant Assistant</h1>
                    <p className="text-slate-600">Powered by OpenAI GPT-4o</p>
                  </div>
                </div>
              </Link>
              <Button 
                variant="outline" 
                onClick={() => setCurrentView('choice')}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </div>
          </div>
        </header>
        <main className="flex-1 max-w-7xl mx-auto px-6 py-8">
          <AITenantBot />
        </main>
        <Footer />
      </div>
    );
  }

  if (currentView === 'fault') {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <main className="flex-1 flex flex-col">
          <QuickFaultReport onReturn={() => setCurrentView('landing')} />
        </main>
        <Footer />
      </div>
    );
  }

  if (currentView === 'choice') {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <div className="flex items-center justify-between">
              <Link href="/">
                <div className="flex items-center space-x-4 cursor-pointer hover:opacity-80 transition-opacity">
                  <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-slate-800">Tenafyi</h1>
                    <p className="text-slate-600">Tenant Qualification at its Best</p>
                  </div>
                </div>
              </Link>
              <Button 
                variant="outline" 
                onClick={() => setCurrentView('landing')}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </div>
          </div>
        </header>

        {/* Choice Content */}
        <main className="flex-1 max-w-7xl mx-auto px-6 py-16">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-slate-800 mb-6">
              Choose Your Application Method
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Select how you'd like to complete your tenant application. 
              Both options are secure and lead to the same result.
            </p>
          </div>

          {/* Application Method Cards */}
          <div className={`grid gap-12 max-w-6xl mx-auto ${
            (settings as any)?.ai_chatbot_enabled?.enabled || (settings as any)?.conversational_bot_enabled?.enabled || (settings as any)?.traditional_form_enabled?.enabled !== false
              ? 'lg:grid-cols-3' 
              : 'lg:grid-cols-2'
          }`}>
            
            {/* AI Chatbot Option (conditionally shown) */}
            {(settings as any)?.ai_chatbot_enabled?.enabled && (
              <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-purple-200 hover:border-purple-400 cursor-pointer"
                    onClick={() => setCurrentView('ai-bot')}
                    data-testid="card-ai-chatbot">
                <CardContent className="p-12 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:from-purple-200 group-hover:to-indigo-200 transition-colors">
                    <Sparkles className="w-10 h-10 text-purple-600" />
                  </div>
                  <div className="mb-2">
                    <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 mb-2">
                      AI-Powered
                    </Badge>
                  </div>
                  <h3 className="text-3xl font-bold text-slate-800 mb-4">Smart AI Assistant</h3>
                  <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                    Chat with our OpenAI-powered assistant. Get personalized property recommendations, 
                    instant income calculations, and smart qualification guidance.
                  </p>
                  <div className="mb-6 space-y-2 text-sm text-slate-500">
                    <div className="flex items-center justify-center gap-2">
                      ✓ Natural language conversations
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      ✓ Real-time income calculations
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      ✓ Property matching & Q&A
                    </div>
                  </div>
                  <Button 
                    size="lg" 
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-8 py-4 text-lg font-semibold"
                  >
                    Try AI Assistant
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Conversational Bot Option (conditionally shown) */}
            {((settings as any)?.conversational_bot_enabled?.enabled !== false) && (
              <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-emerald-200 hover:border-emerald-400 cursor-pointer"
                    onClick={() => setCurrentView('bot')}>
                <CardContent className="p-12 text-center">
                  <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:bg-emerald-200 transition-colors">
                    <MessageCircle className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h3 className="text-3xl font-bold text-slate-800 mb-4">Chat Bot</h3>
                  <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                    Have a conversation with our friendly bot. Just like texting - 
                    ask questions, get instant help, and complete your application naturally.
                  </p>
                  <div className="mb-6 space-y-2 text-sm text-slate-500">
                    <div className="flex items-center justify-center gap-2">
                      ✓ Browse live property listings
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      ✓ Get instant answers to questions
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      ✓ Mobile-friendly chat interface
                    </div>
                  </div>
                  <Button 
                    size="lg" 
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 text-lg font-semibold"
                  >
                    Start Chat
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Traditional Form Option (conditionally shown) */}
            {((settings as any)?.traditional_form_enabled?.enabled !== false) && (
              <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-blue-200 hover:border-blue-400 cursor-pointer">
                <Link href="/apply">
                  <CardContent className="p-12 text-center">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:bg-blue-200 transition-colors">
                      <FileText className="w-10 h-10 text-blue-600" />
                    </div>
                    <h3 className="text-3xl font-bold text-slate-800 mb-4">Traditional Form</h3>
                    <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                      Complete a structured form with all fields visible at once. 
                      Perfect if you prefer the traditional application method.
                    </p>
                    <div className="mb-6 space-y-2 text-sm text-slate-500">
                      <div className="flex items-center justify-center gap-2">
                        ✓ All fields visible at once
                      </div>
                      <div className="flex items-center justify-center gap-2">
                        ✓ Familiar form interface
                      </div>
                      <div className="flex items-center justify-center gap-2">
                        ✓ Complete at your own pace
                      </div>
                    </div>
                    <Button 
                      size="lg" 
                      variant="outline"
                      className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 text-lg font-semibold"
                    >
                      Use Form
                    </Button>
                  </CardContent>
                </Link>
              </Card>
            )}

          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center">
              <Building2 className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-800">Tenafyi</h1>
              <p className="text-slate-600">Tenant Qualification at its Best</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-slate-800 mb-6">
            Apply for Your Next Rental
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Start your tenant application journey with our guided process. 
            Quick, secure, and designed to match you with the perfect property.
          </p>
        </div>

        {/* Main Action Card */}
        <div className="flex justify-center mb-20">
          <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-emerald-200 hover:border-emerald-400 cursor-pointer max-w-lg"
                onClick={() => setCurrentView('choice')}>
            <CardContent className="p-16 text-center">
              <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:bg-emerald-200 transition-colors">
                <Building2 className="w-12 h-12 text-emerald-600" />
              </div>
              <h3 className="text-4xl font-bold text-slate-800 mb-6">Start Application</h3>
              <p className="text-xl text-slate-600 mb-10 leading-relaxed">
                Begin your tenant application process. We'll guide you through 
                every step to find your perfect rental property.
              </p>
              <Button 
                size="lg" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-12 py-6 text-xl font-semibold"
              >
                Get Started
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Secondary Action Card */}
        <div className="flex justify-center">
          <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-red-200 hover:border-red-400 cursor-pointer max-w-lg"
                onClick={() => setCurrentView('fault')}>
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:bg-red-200 transition-colors">
                <AlertTriangle className="w-10 h-10 text-red-600" />
              </div>
              <h3 className="text-3xl font-bold text-slate-800 mb-4">Report a Fault</h3>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Experiencing technical issues? Report problems quickly 
                and get direct support from our technical team.
              </p>
              <Button 
                size="lg" 
                variant="outline"
                className="border-red-300 text-red-700 hover:bg-red-50 px-8 py-4 text-lg font-semibold"
              >
                Report Technical Issue
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-6">
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
            <h4 className="text-xl font-semibold text-slate-800 mb-3">Chat Experience</h4>
            <p className="text-slate-600">
              Natural conversation flow that feels like messaging a real person, but with perfect memory.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Users className="w-8 h-8 text-purple-600" />
            </div>
            <h4 className="text-xl font-semibold text-slate-800 mb-3">Household Support</h4>
            <p className="text-slate-600">
              Handle applications for multiple adults and children with individual income tracking.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Building2 className="w-8 h-8 text-orange-600" />
            </div>
            <h4 className="text-xl font-semibold text-slate-800 mb-3">Property Matching</h4>
            <p className="text-slate-600">
              Get matched with available properties and calculate your affordability automatically.
            </p>
          </div>
        </div>

      </main>
      <Footer />
    </div>
  );
}