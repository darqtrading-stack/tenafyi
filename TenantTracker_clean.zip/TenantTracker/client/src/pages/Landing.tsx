import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Building2, MessageCircle, Sparkles, ArrowRight, Shield, Zap, Users } from "lucide-react";
import { Footer } from "@/components/Footer";

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Navigation */}
      <nav className="glass-effect border-b border-white/20 px-6 py-6 sticky top-0 z-50">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <Link href="/">
            <div className="flex items-center space-x-4 cursor-pointer hover:opacity-90 transition-opacity">
              <div className="w-10 h-10 modern-gradient rounded-xl flex items-center justify-center">
                <Building2 className="text-white w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">Tenafyi</h1>
                <p className="text-xs text-slate-600 font-medium">AI-Powered Tenant Matching</p>
              </div>
            </div>
          </Link>
          <div className="flex items-center space-x-3">
            <Link href="/login">
              <Button variant="ghost" size="sm" className="text-slate-600 hover:text-slate-900">
                Admin Login
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 modern-gradient opacity-5"></div>
        <div className="max-w-7xl mx-auto px-6 py-24 lg:py-32 relative">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-white/60 border border-white/20 rounded-full px-4 py-2 mb-8 text-sm font-medium text-slate-700">
              <Sparkles className="w-4 h-4 text-blue-600" />
              AI-Powered Tenant Qualification
            </div>
            
            <h1 className="text-balance font-black text-slate-900 mb-8">
              Find Your Perfect Rental with Our Smart Chat Assistant
            </h1>
            
            <p className="text-xl text-slate-600 mb-12 max-w-2xl mx-auto leading-relaxed">
              Skip the paperwork. Our intelligent chat bot guides you through the entire rental application process, 
              matches you with suitable properties, and gets you approved faster.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link href="/tenafyi">
                <Button size="lg" className="modern-gradient text-white border-0 px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 group">
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Start Chat Application
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center justify-center gap-8 text-sm text-slate-500">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-600" />
                <span>Bank-Grade Security</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-blue-600" />
                <span>5-Minute Applications</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-600" />
                <span>1000+ Happy Tenants</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-slate-900 mb-4">Why Choose Our Chat Assistant?</h2>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Experience a new way to apply for rentals with our intelligent, conversational interface.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 modern-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 modern-gradient rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Natural Conversation</h3>
                <p className="text-slate-600 leading-relaxed">
                  Chat like you're texting a friend. Our AI understands natural language and guides you through each step seamlessly.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 modern-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Smart Property Matching</h3>
                <p className="text-slate-600 leading-relaxed">
                  Browse live property listings, get personalized recommendations, and calculate affordability in real-time.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 modern-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Instant Processing</h3>
                <p className="text-slate-600 leading-relaxed">
                  Get immediate feedback, instant application confirmation, and fast-track approval with our automated system.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="modern-gradient rounded-3xl p-12 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="relative">
              <h2 className="text-white mb-6">Ready to Find Your Next Home?</h2>
              <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
                Join thousands of satisfied tenants who found their perfect rental through our intelligent chat system.
              </p>
              <Link href="/tenafyi">
                <Button size="lg" variant="secondary" className="bg-white text-slate-900 hover:bg-white/90 px-8 py-4 text-lg font-semibold">
                  Start Your Application Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
