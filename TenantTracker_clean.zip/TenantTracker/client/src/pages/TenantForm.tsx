import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { HomeIcon, ArrowLeft, ArrowRight, Check } from "lucide-react";
import { TenantFormSteps } from "@/components/TenantFormSteps";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertApplication } from "@shared/schema";
import { getQuestionsByStep, validateAnswer } from "@shared/questions";

export default function TenantForm() {
  // Always start from step 1 when component mounts (fresh page load)
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<Partial<InsertApplication>>({});
  const [showValidationErrors, setShowValidationErrors] = useState(false);
  const { toast } = useToast();
  const totalSteps = 4;

  const submitMutation = useMutation({
    mutationFn: async (data: InsertApplication) => {
      await apiRequest("POST", "/api/applications", data);
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted!",
        description: "You will receive a confirmation email shortly.",
      });
      // Reset form
      setFormData({});
      setCurrentStep(1);
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const stepTitles = [
    "Personal Details",
    "Lifestyle Questions", 
    "Financial Information",
    "Contact Information"
  ];

  const progress = (currentStep / totalSteps) * 100;

  const validateCurrentStep = (): { isValid: boolean; message?: string; firstErrorField?: string } => {
    const currentStepQuestions = getQuestionsByStep(currentStep);
    
    for (const question of currentStepQuestions) {
      if (question.required) {
        const fieldValue = formData[question.formField as keyof InsertApplication];
        const validation = validateAnswer(question, fieldValue);
        
        if (!validation.isValid) {
          return { isValid: false, message: validation.message, firstErrorField: question.id };
        }
      }
    }
    
    return { isValid: true };
  };

  const handleNext = () => {
    const validation = validateCurrentStep();
    
    if (!validation.isValid) {
      setShowValidationErrors(true);
      
      toast({
        title: "Please Complete Required Fields",
        description: validation.message || "All required fields must be filled before proceeding.",
        variant: "destructive",
      });
      
      // Scroll to first error field
      if (validation.firstErrorField) {
        setTimeout(() => {
          const errorElement = document.getElementById(validation.firstErrorField!);
          if (errorElement) {
            errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            errorElement.focus();
          }
        }, 100);
      }
      return;
    }
    
    // Reset validation errors when proceeding successfully
    setShowValidationErrors(false);
    
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      // Scroll to top of page
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      // Scroll to top of page
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmit = () => {
    if (isFormComplete(formData)) {
      submitMutation.mutate(formData as InsertApplication);
    } else {
      toast({
        title: "Incomplete Form",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
    }
  };

  const isFormComplete = (data: Partial<InsertApplication>): boolean => {
    const required = [
      'fullName', 'email', 'phone', 'moveDate', 'adults', 'rentalPeriod',
      'hasPets', 'smokes', 'occupation', 'annualIncome', 'hasCCJIVA', 
      'hasGuarantor', 'contactTime'
    ];
    
    return required.every(field => data[field as keyof InsertApplication] !== undefined);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <Link href="/">
            <div className="flex items-center space-x-4 cursor-pointer">
              <HomeIcon className="text-primary text-2xl" />
              <h1 className="text-xl font-semibold text-gray-900">Tenafyi</h1>
            </div>
          </Link>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </nav>

      {/* Form Container */}
      <div className="max-w-4xl mx-auto p-6">
        <Card className="shadow-lg">
          {/* Form Header */}
          <CardHeader className="bg-gradient-to-r from-primary to-primary/80 text-white">
            <CardTitle className="text-3xl font-bold">Tenafyi Application</CardTitle>
            <p className="text-primary-100">Tenant Qualification at its Best - Complete your application in minutes</p>
          </CardHeader>

          {/* Progress Indicator */}
          <div className="px-8 py-6 bg-gray-50 border-b">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-600">
                Step {currentStep} of {totalSteps}
              </span>
              <span className="text-sm text-gray-500">{stepTitles[currentStep - 1]}</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Form Content */}
          <CardContent className="p-8">
            <TenantFormSteps
              currentStep={currentStep}
              formData={formData}
              onFormDataChange={setFormData}
              showValidationErrors={showValidationErrors}
            />

            {/* Navigation Buttons */}
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
              <Button
                type="button"
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
                className={currentStep === 1 ? "invisible" : ""}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>

              <div className="flex space-x-4">
                {currentStep < totalSteps ? (
                  <Button onClick={handleNext}>
                    Next Step
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button 
                    onClick={handleSubmit}
                    disabled={submitMutation.isPending}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {submitMutation.isPending ? (
                      "Submitting..."
                    ) : (
                      <>
                        <Check className="mr-2 h-4 w-4" />
                        Submit Application
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
