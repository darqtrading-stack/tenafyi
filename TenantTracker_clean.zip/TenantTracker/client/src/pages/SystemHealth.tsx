import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, CheckCircle, Clock, Mail, Play, Settings, Shield, HomeIcon, Users, Database } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

interface HealthCheckResult {
  timestamp: string;
  status: 'healthy' | 'warning' | 'critical';
  tests: TestResult[];
  summary: string;
  errors: string[];
  warnings: string[];
}

interface TestResult {
  name: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
  duration: number;
  details?: any;
}

interface SystemSettings {
  alertEmail?: string;
  enabled: boolean;
}

export default function SystemHealth() {
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();
  const [settings, setSettings] = useState<SystemSettings>({ enabled: true });
  const [lastResult, setLastResult] = useState<HealthCheckResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', { method: 'POST', credentials: 'include' });
      window.location.href = '/';
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (authLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) {
    window.location.href = '/login';
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Redirecting to login...</div>;
  }

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const response = await fetch('/api/admin/health-check/settings');
      if (response.ok) {
        const data = await response.json();
        setSettings(data);
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  };

  const saveSettings = async () => {
    setIsSaving(true);
    
    try {
      const response = await fetch('/api/admin/health-check/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(settings),
      });

      if (!response.ok) {
        throw new Error('Failed to save settings');
      }

      const result = await response.json();
      
      toast({
        title: "Settings Saved",
        description: result.message,
        duration: 3000,
      });
      
    } catch (error) {
      console.error('Failed to save settings:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save health check settings. Please try again.",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const runHealthCheck = async () => {
    setIsRunning(true);
    
    try {
      console.log('🔄 Starting manual health check...');
      
      const response = await fetch('/api/admin/health-check/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to run health check');
      }

      const data = await response.json();
      setLastResult(data.result);
      
      toast({
        title: "Health Check Completed",
        description: data.result.summary,
        duration: 5000,
      });
      
    } catch (error) {
      console.error('Health check failed:', error);
      toast({
        title: "Health Check Failed",
        description: "Failed to run system health check. Please try again.",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsRunning(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'pass':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'critical':
      case 'fail':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadgeVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'healthy':
      case 'pass':
        return 'default';
      case 'warning':
        return 'secondary';
      case 'critical':
      case 'fail':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <Link href="/">
            <div className="flex items-center space-x-4 cursor-pointer">
              <HomeIcon className="text-primary text-2xl" />
              <h1 className="text-xl font-semibold text-gray-900">Tenafyi</h1>
            </div>
          </Link>
          <div className="flex items-center space-x-6">
            <div className="hidden md:flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
                  <Users className="w-4 h-4 mr-2" />
                  Applications
                </Button>
              </Link>
              <Link href="/admin/properties">
                <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
                  <Database className="w-4 h-4 mr-2" />
                  Properties
                </Button>
              </Link>
              <Link href="/admin/health">
                <Button variant="ghost" className="text-gray-600 hover:text-gray-900 bg-gray-100">
                  <Shield className="w-4 h-4 mr-2" />
                  System Health
                </Button>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">
                Welcome, {user?.firstName || user?.email}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">System Health Monitor</h1>
          <p className="text-muted-foreground">
            Automated system monitoring and fault detection
          </p>
        </div>
        
        <Button 
          onClick={runHealthCheck} 
          disabled={isRunning}
          className="flex items-center gap-2"
        >
          <Play className={`h-4 w-4 ${isRunning ? 'animate-spin' : ''}`} />
          {isRunning ? 'Running Check...' : 'Run Health Check'}
        </Button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="results">Latest Results</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Health Status</CardTitle>
                {getStatusIcon(lastResult?.status || 'unknown')}
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {lastResult?.status?.toUpperCase() || 'UNKNOWN'}
                </div>
                <p className="text-xs text-muted-foreground">
                  {lastResult ? 'Last check: ' + new Date(lastResult.timestamp).toLocaleString() : 'No checks run yet'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Auto Monitoring</CardTitle>
                <Shield className={`h-4 w-4 ${settings.enabled ? 'text-green-500' : 'text-gray-500'}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {settings.enabled ? 'ENABLED' : 'DISABLED'}
                </div>
                <p className="text-xs text-muted-foreground">
                  Daily checks at 12:00 AM
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Alert Email</CardTitle>
                <Mail className={`h-4 w-4 ${settings.alertEmail ? 'text-blue-500' : 'text-gray-500'}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {settings.alertEmail ? 'CONFIGURED' : 'NOT SET'}
                </div>
                <p className="text-xs text-muted-foreground">
                  Fault notifications
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                System Health Checks
              </CardTitle>
              <CardDescription>
                The system performs comprehensive daily health checks including:
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-1" />
                  <div>
                    <p className="font-medium">Database Connectivity</p>
                    <p className="text-sm text-muted-foreground">Tests database connections and table access</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-1" />
                  <div>
                    <p className="font-medium">Property Scraping Service</p>
                    <p className="text-sm text-muted-foreground">Verifies property data availability and freshness</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-1" />
                  <div>
                    <p className="font-medium">Application Submission</p>
                    <p className="text-sm text-muted-foreground">Tests complete application flow with test data</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-1" />
                  <div>
                    <p className="font-medium">Search Functionality</p>
                    <p className="text-sm text-muted-foreground">Validates search and filtering capabilities</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-1" />
                  <div>
                    <p className="font-medium">Email Service</p>
                    <p className="text-sm text-muted-foreground">Checks email configuration and connectivity</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-1" />
                  <div>
                    <p className="font-medium">API Endpoints</p>
                    <p className="text-sm text-muted-foreground">Tests critical API endpoint availability</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Health Check Configuration</CardTitle>
              <CardDescription>
                Configure automated system monitoring and fault reporting
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="enabled"
                  checked={settings.enabled}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({ ...prev, enabled: checked }))
                  }
                />
                <Label htmlFor="enabled">Enable automatic health checks</Label>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="alertEmail">Alert Email Address</Label>
                <Input
                  id="alertEmail"
                  type="email"
                  placeholder="admin@example.com"
                  value={settings.alertEmail || ''}
                  onChange={(e) => 
                    setSettings(prev => ({ ...prev, alertEmail: e.target.value }))
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Email address to receive fault notifications and health reports
                </p>
              </div>
              
              <Button 
                onClick={saveSettings} 
                disabled={isSaving}
                className="w-full"
              >
                {isSaving ? 'Saving...' : 'Save Settings'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          {lastResult ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(lastResult.status)}
                    Health Check Results
                  </CardTitle>
                  <CardDescription>
                    {lastResult.summary} - {new Date(lastResult.timestamp).toLocaleString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {lastResult.tests.filter(t => t.status === 'pass').length}
                      </div>
                      <p className="text-sm text-muted-foreground">Passed</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600">
                        {lastResult.tests.filter(t => t.status === 'warning').length}
                      </div>
                      <p className="text-sm text-muted-foreground">Warnings</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">
                        {lastResult.tests.filter(t => t.status === 'fail').length}
                      </div>
                      <p className="text-sm text-muted-foreground">Failed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Test Results</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {lastResult.tests.map((test, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(test.status)}
                        <div>
                          <p className="font-medium">{test.name}</p>
                          <p className="text-sm text-muted-foreground">{test.message}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={getStatusBadgeVariant(test.status)}>
                          {test.status.toUpperCase()}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          {test.duration}ms
                        </p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {(lastResult.errors.length > 0 || lastResult.warnings.length > 0) && (
                <Card>
                  <CardHeader>
                    <CardTitle>Issues Found</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {lastResult.errors.length > 0 && (
                      <div>
                        <h4 className="font-medium text-red-600 mb-2">Critical Errors</h4>
                        <ul className="space-y-1">
                          {lastResult.errors.map((error, index) => (
                            <li key={index} className="text-sm text-red-600 flex items-start gap-2">
                              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                              {error}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {lastResult.warnings.length > 0 && (
                      <div>
                        <h4 className="font-medium text-yellow-600 mb-2">Warnings</h4>
                        <ul className="space-y-1">
                          {lastResult.warnings.map((warning, index) => (
                            <li key={index} className="text-sm text-yellow-600 flex items-start gap-2">
                              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                              {warning}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p className="text-muted-foreground">No health check results available</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Click "Run Health Check" to perform a manual system health check
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}