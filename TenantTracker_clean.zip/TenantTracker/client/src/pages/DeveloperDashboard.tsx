import { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { apiRequest } from '@/lib/queryClient';
import { Brain, Code, Settings, MessageSquare, BarChart3, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface SystemReport {
  summary: string;
  healthScore: number;
  criticalIssues: string[];
  quickWins: string[];
  longTermGoals: string[];
}

interface SystemAnalysis {
  analysis: string;
  recommendations: string[];
  priority: 'low' | 'medium' | 'high' | 'critical';
  actions: string[];
}

export default function DeveloperDashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [improvementContext, setImprovementContext] = useState('');
  const [specificArea, setSpecificArea] = useState('');
  const [codeSnippet, setCodeSnippet] = useState('');
  const [codeContext, setCodeContext] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // System Report Query
  const { data: systemReport, isLoading: reportLoading } = useQuery({
    queryKey: ['/api/developer/system-report'],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // System Analysis Mutation
  const systemAnalysisMutation = useMutation({
    mutationFn: () => apiRequest('/api/developer/analyze-system', 'POST', {}),
    onSuccess: (data) => {
      toast({
        title: "System Analysis Complete",
        description: `Priority: ${data.priority}. Found ${data.recommendations.length} recommendations.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Chat Mutation
  const chatMutation = useMutation({
    mutationFn: ({ message, conversationHistory }: { message: string; conversationHistory: any[] }) => 
      apiRequest('/api/developer/chat', 'POST', { message, conversationHistory }),
    onSuccess: (data, variables) => {
      const userMessage: Message = {
        id: Date.now().toString(),
        role: 'user',
        content: variables.message,
        timestamp: new Date()
      };
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        timestamp: new Date()
      };
      setChatMessages(prev => [...prev, userMessage, assistantMessage]);
      setCurrentMessage('');
    },
    onError: (error) => {
      toast({
        title: "Chat Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Improvement Suggestions Mutation
  const improvementsMutation = useMutation({
    mutationFn: () => apiRequest('/api/developer/suggest-improvements', 'POST', {
      context: improvementContext,
      specificArea: specificArea || undefined
    }),
    onSuccess: (data) => {
      toast({
        title: "Improvement Suggestions Generated",
        description: `Found ${data.suggestions.length} suggestions.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Suggestions Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Code Review Mutation
  const codeReviewMutation = useMutation({
    mutationFn: () => apiRequest('/api/developer/review-code', 'POST', {
      codeSnippet,
      context: codeContext
    }),
    onSuccess: (data) => {
      toast({
        title: "Code Review Complete",
        description: `Rating: ${data.rating}/10. Found ${data.issues.length} issues.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Code Review Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleSendMessage = () => {
    if (!currentMessage.trim()) return;
    
    const conversationHistory = chatMessages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
    
    chatMutation.mutate({ message: currentMessage, conversationHistory });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const getPriorityBadge = (priority: string) => {
    const colors = {
      low: 'bg-green-500',
      medium: 'bg-yellow-500',
      high: 'bg-orange-500',
      critical: 'bg-red-500'
    };
    return <Badge className={colors[priority as keyof typeof colors]}>{priority}</Badge>;
  };

  return (
    <div className="container mx-auto p-6" data-testid="developer-dashboard">
      <div className="flex items-center gap-2 mb-6">
        <Brain className="h-8 w-8 text-blue-600" />
        <h1 className="text-3xl font-bold">Developer Dashboard</h1>
        <Badge variant="secondary">ChatGPT Agent</Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview" data-testid="tab-overview">
            <BarChart3 className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="chat" data-testid="tab-chat">
            <MessageSquare className="w-4 h-4 mr-2" />
            AI Chat
          </TabsTrigger>
          <TabsTrigger value="analysis" data-testid="tab-analysis">
            <Settings className="w-4 h-4 mr-2" />
            System Analysis
          </TabsTrigger>
          <TabsTrigger value="improvements" data-testid="tab-improvements">
            <CheckCircle className="w-4 h-4 mr-2" />
            Improvements
          </TabsTrigger>
          <TabsTrigger value="code-review" data-testid="tab-code-review">
            <Code className="w-4 h-4 mr-2" />
            Code Review
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  System Health Report
                </CardTitle>
              </CardHeader>
              <CardContent>
                {reportLoading ? (
                  <div className="text-center py-8">Loading system report...</div>
                ) : systemReport ? (
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Health Score</span>
                        <span className="text-2xl font-bold">{(systemReport as SystemReport).healthScore}%</span>
                      </div>
                      <Progress value={(systemReport as SystemReport).healthScore} className="h-3" />
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Summary</h4>
                      <p className="text-gray-700 dark:text-gray-300">{(systemReport as SystemReport).summary}</p>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-red-500" />
                            Critical Issues
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {(systemReport as SystemReport).criticalIssues.length === 0 ? (
                            <p className="text-green-600">No critical issues</p>
                          ) : (
                            <ul className="space-y-1">
                              {(systemReport as SystemReport).criticalIssues.map((issue: string, idx: number) => (
                                <li key={idx} className="text-sm text-red-600">• {issue}</li>
                              ))}
                            </ul>
                          )}
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            Quick Wins
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-1">
                            {(systemReport as SystemReport).quickWins.map((win: string, idx: number) => (
                              <li key={idx} className="text-sm">• {win}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Clock className="w-4 h-4 text-blue-500" />
                            Long-term Goals
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-1">
                            {(systemReport as SystemReport).longTermGoals.map((goal: string, idx: number) => (
                              <li key={idx} className="text-sm">• {goal}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">No system report available</div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="chat">
          <Card className="h-[600px] flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Chat with AI Agent
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <ScrollArea className="flex-1 border rounded-lg p-4 mb-4">
                <div className="space-y-4">
                  {chatMessages.length === 0 ? (
                    <div className="text-center text-gray-500 py-8">
                      Start a conversation with the AI agent about system improvements, architecture decisions, or debugging help.
                    </div>
                  ) : (
                    chatMessages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] p-3 rounded-lg ${
                            message.role === 'user'
                              ? 'bg-blue-600 text-white'
                              : 'bg-gray-100 dark:bg-gray-800'
                          }`}
                        >
                          <p className="whitespace-pre-wrap">{message.content}</p>
                          <div className="text-xs opacity-70 mt-1">
                            {message.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
              
              <div className="flex gap-2">
                <Textarea
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask about system architecture, improvements, debugging..."
                  className="resize-none"
                  rows={2}
                  data-testid="input-chat-message"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!currentMessage.trim() || chatMutation.isPending}
                  data-testid="button-send-message"
                >
                  Send
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  System Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => systemAnalysisMutation.mutate()}
                  disabled={systemAnalysisMutation.isPending}
                  className="mb-4"
                  data-testid="button-analyze-system"
                >
                  {systemAnalysisMutation.isPending ? 'Analyzing...' : 'Run System Analysis'}
                </Button>

                {systemAnalysisMutation.data && (
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-semibold">Priority:</span>
                        {getPriorityBadge(systemAnalysisMutation.data.priority)}
                      </div>
                      <p className="text-gray-700 dark:text-gray-300">{systemAnalysisMutation.data.analysis}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Recommendations</h4>
                      <ul className="space-y-1">
                        {systemAnalysisMutation.data.recommendations.map((rec: string, idx: number) => (
                          <li key={idx} className="text-sm">• {rec}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Immediate Actions</h4>
                      <ul className="space-y-1">
                        {systemAnalysisMutation.data.actions.map((action: string, idx: number) => (
                          <li key={idx} className="text-sm">• {action}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="improvements">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Improvement Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Context</label>
                <Textarea
                  value={improvementContext}
                  onChange={(e) => setImprovementContext(e.target.value)}
                  placeholder="Describe the current system or area you want to improve..."
                  rows={4}
                  data-testid="input-improvement-context"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Specific Area (optional)</label>
                <Input
                  value={specificArea}
                  onChange={(e) => setSpecificArea(e.target.value)}
                  placeholder="e.g., performance, security, user experience..."
                  data-testid="input-specific-area"
                />
              </div>

              <Button
                onClick={() => improvementsMutation.mutate()}
                disabled={!improvementContext.trim() || improvementsMutation.isPending}
                data-testid="button-get-suggestions"
              >
                {improvementsMutation.isPending ? 'Analyzing...' : 'Get Improvement Suggestions'}
              </Button>

              {improvementsMutation.data && (
                <div className="space-y-4 mt-6">
                  <div>
                    <h4 className="font-semibold mb-2">Suggestions</h4>
                    <ul className="space-y-2">
                      {improvementsMutation.data.suggestions.map((suggestion: string, idx: number) => (
                        <li key={idx} className="text-sm bg-gray-50 dark:bg-gray-800 p-2 rounded">• {suggestion}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Implementation Steps</h4>
                    <ol className="space-y-2">
                      {improvementsMutation.data.implementation.map((step: string, idx: number) => (
                        <li key={idx} className="text-sm bg-blue-50 dark:bg-blue-900/20 p-2 rounded">
                          {idx + 1}. {step}
                        </li>
                      ))}
                    </ol>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Expected Impact</h4>
                    <p className="text-sm bg-green-50 dark:bg-green-900/20 p-3 rounded">
                      {improvementsMutation.data.impact}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code-review">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                AI Code Review
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Code Snippet</label>
                <Textarea
                  value={codeSnippet}
                  onChange={(e) => setCodeSnippet(e.target.value)}
                  placeholder="Paste your code here for review..."
                  rows={8}
                  className="font-mono text-sm"
                  data-testid="input-code-snippet"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Context</label>
                <Input
                  value={codeContext}
                  onChange={(e) => setCodeContext(e.target.value)}
                  placeholder="Describe what this code does or where it's used..."
                  data-testid="input-code-context"
                />
              </div>

              <Button
                onClick={() => codeReviewMutation.mutate()}
                disabled={!codeSnippet.trim() || !codeContext.trim() || codeReviewMutation.isPending}
                data-testid="button-review-code"
              >
                {codeReviewMutation.isPending ? 'Reviewing...' : 'Review Code'}
              </Button>

              {codeReviewMutation.data && (
                <div className="space-y-4 mt-6">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">Quality Rating:</span>
                    <Badge variant={codeReviewMutation.data.rating >= 8 ? 'default' : 
                                  codeReviewMutation.data.rating >= 6 ? 'secondary' : 'destructive'}>
                      {codeReviewMutation.data.rating}/10
                    </Badge>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Review</h4>
                    <p className="text-sm bg-gray-50 dark:bg-gray-800 p-3 rounded whitespace-pre-wrap">
                      {codeReviewMutation.data.review}
                    </p>
                  </div>

                  {codeReviewMutation.data.issues.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2 text-red-600">Issues Found</h4>
                      <ul className="space-y-2">
                        {codeReviewMutation.data.issues.map((issue: string, idx: number) => (
                          <li key={idx} className="text-sm bg-red-50 dark:bg-red-900/20 p-2 rounded">• {issue}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div>
                    <h4 className="font-semibold mb-2 text-green-600">Improvements</h4>
                    <ul className="space-y-2">
                      {codeReviewMutation.data.improvements.map((improvement: string, idx: number) => (
                        <li key={idx} className="text-sm bg-green-50 dark:bg-green-900/20 p-2 rounded">• {improvement}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}