import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import TenantForm from "@/pages/TenantForm";
import AdminDashboard from "@/pages/AdminDashboard";
import DeveloperDashboard from "@/pages/DeveloperDashboard";
import SystemHealth from "@/pages/SystemHealth";
import PropertyManagement from "@/pages/PropertyManagement";
import TenafyiLanding from "@/pages/TenafyiLanding";
import LoginPage from "@/pages/LoginPage";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/apply" component={TenantForm} />
      <Route path="/tenafyi" component={TenafyiLanding} />
      <Route path="/login" component={LoginPage} />
      
      {/* Admin routes - will redirect to login if not authenticated */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/health" component={SystemHealth} />
      <Route path="/admin/properties" component={PropertyManagement} />
      
      {/* Developer route */}
      <Route path="/developer" component={DeveloperDashboard} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
