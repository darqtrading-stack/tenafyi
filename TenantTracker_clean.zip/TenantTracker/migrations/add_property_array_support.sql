-- Migration to add property array support to applications table
-- This enables multiple property selection instead of just one

-- Add the new property array column
ALTER TABLE applications ADD COLUMN property_array TEXT[] DEFAULT '{}';

-- Migrate existing single property values to array format  
UPDATE applications SET property_array = CASE 
  WHEN property IS NOT NULL AND property != '' THEN ARRAY[property]
  ELSE '{}'
END WHERE property IS NOT NULL;

-- Drop the old single property column
ALTER TABLE applications DROP COLUMN IF EXISTS property;

-- Rename the new array column to property
ALTER TABLE applications RENAME COLUMN property_array TO property;

-- Set property column to NOT NULL with default empty array
ALTER TABLE applications ALTER COLUMN property SET NOT NULL;
ALTER TABLE applications ALTER COLUMN property SET DEFAULT '{}';