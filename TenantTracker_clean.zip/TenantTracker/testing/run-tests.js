/**
 * Test Runner Script - Tests both bot and form with fictional applicants
 * Run with: node testing/run-tests.js
 */

import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:5000';

// Test data
const availableProperties = [
  "4 bed bungalow to rent in New Barn Road, Longfield, DA3 7JE",
  "4 bed detached house to rent in Broadacre View", 
  "4 bed chalet to rent in Ufton Lane, Sittingbourne, Kent, ME10 1EU",
  "Shop to rent in Sidcup Road, London, SE9 3NS",
  "2 bed flat to rent in Russet Walk, Greenhithe, DA9 9WY",
  "2 bed ground floor flat to rent in Henshaaws Vale, Sittingbourne, Kent, ME10 3NY",
  "1 bed flat to rent in Park Road, Sittingbourne, ME10 1DY",
  "1 bed flat to rent in Portland Avenue, Sittingbourne, Kent, ME10 3QZ"
];

// Generate test applicant
function generateTestApplicant(index) {
  const scenarios = [
    "Young professional", "Family with pets", "Student", "Senior citizen", 
    "Self-employed", "High earner", "Single parent", "Large family",
    "International applicant", "First-time renter", "Business owner",
    "Healthcare worker", "Teacher", "IT consultant", "Chef",
    "Retail worker", "Unemployed", "Artist", "Military", "Apprentice"
  ];
  
  const firstNames = ["James", "Sarah", "Michael", "Emma", "David", "Lisa", "Robert", "Sophie", "John", "Maria", "William", "Anna", "Thomas", "Lucy", "Daniel", "Grace", "Paul", "Amy", "Mark", "Helen"];
  const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"];
  
  const moveOptions = ["ASAP", "Within 2 weeks", "I need to give one months notice"];
  const rentalOptions = ["6 months", "1 year", "2+ years"];
  const occupationOptions = ["Employed", "Self-Employed", "Student", "Unemployed", "Retired"];
  const contactTimeOptions = ["Morning", "Afternoon", "Evening", "Anytime"];
  const contactMethodOptions = ["Phone call", "Text/SMS", "Email", "WhatsApp"];
  
  const firstName = firstNames[index % firstNames.length];
  const lastName = lastNames[Math.floor(index / firstNames.length) % lastNames.length];
  const hasPets = Math.random() > 0.7;
  const occupation = occupationOptions[Math.floor(Math.random() * occupationOptions.length)];
  const isStudent = occupation === "Student";
  const isRetired = occupation === "Retired";
  const isSelfEmployed = occupation === "Self-Employed";
  
  return {
    fullName: `${firstName} ${lastName}`,
    email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}${index}@email.com`,
    phone: `077009${(10000 + index).toString().substr(-5)}`,
    adults: Math.floor(Math.random() * 3) + 1,
    children: isStudent ? 0 : Math.floor(Math.random() * 4),
    moveDate: moveOptions[Math.floor(Math.random() * moveOptions.length)],
    rentalPeriod: rentalOptions[Math.floor(Math.random() * rentalOptions.length)],
    hasPets: hasPets,
    petDetails: hasPets ? "1 cat (domestic, 3 years old)" : "",
    smokes: Math.random() > 0.85,
    occupation: occupation,
    hasTaxReturns: isSelfEmployed ? Math.random() > 0.3 : null,
    annualIncome: isStudent ? 
      Math.floor(Math.random() * 15000) + 8000 : 
      isRetired ? 
        Math.floor(Math.random() * 40000) + 15000 :
        Math.floor(Math.random() * 70000) + 18000,
    hasCCJIVA: Math.random() > 0.88,
    hasAdverseMedia: Math.random() > 0.96,
    hasGuarantor: isStudent ? true : Math.random() > 0.4,
    contactTime: contactTimeOptions[Math.floor(Math.random() * contactTimeOptions.length)],
    contactMethod: contactMethodOptions[Math.floor(Math.random() * contactMethodOptions.length)],
    additionalNotes: `Test case ${index + 1} - ${scenarios[index % scenarios.length]}`,
    property: [availableProperties[Math.floor(Math.random() * availableProperties.length)]],
    testScenario: scenarios[index % scenarios.length],
    status: 'new'
  };
}

// Test results tracking
let testResults = {
  totalTests: 0,
  successfulSubmissions: 0,
  failedSubmissions: 0,
  errors: [],
  warnings: [],
  testCases: []
};

// Test API endpoints
async function testAPI() {
  console.log('🔄 Testing API endpoints...');
  
  try {
    // Test property endpoint
    const propertiesResponse = await axios.get(`${BASE_URL}/api/properties`);
    console.log(`✅ Properties endpoint: ${propertiesResponse.data.length} properties loaded`);
    testResults.warnings.push(`Properties available: ${propertiesResponse.data.length}`);
    
    return true;
  } catch (error) {
    console.log('❌ API test failed:', error.message);
    testResults.errors.push(`API Error: ${error.message}`);
    return false;
  }
}

// Submit application via API
async function submitApplication(applicant, testIndex) {
  try {
    const response = await axios.post(`${BASE_URL}/api/applications`, applicant);
    
    if (response.status === 200 || response.status === 201) {
      console.log(`✅ Test ${testIndex + 1}: ${applicant.fullName} - SUCCESS`);
      testResults.successfulSubmissions++;
      testResults.testCases.push({
        index: testIndex + 1,
        name: applicant.fullName,
        scenario: applicant.testScenario,
        status: 'SUCCESS',
        income: applicant.annualIncome,
        pets: applicant.hasPets,
        occupation: applicant.occupation
      });
      return true;
    } else {
      throw new Error(`Unexpected response status: ${response.status}`);
    }
  } catch (error) {
    console.log(`❌ Test ${testIndex + 1}: ${applicant.fullName} - FAILED: ${error.message}`);
    testResults.failedSubmissions++;
    testResults.errors.push(`Test ${testIndex + 1} (${applicant.fullName}): ${error.message}`);
    testResults.testCases.push({
      index: testIndex + 1,
      name: applicant.fullName,
      scenario: applicant.testScenario,
      status: 'FAILED',
      error: error.message,
      income: applicant.annualIncome,
      pets: applicant.hasPets,
      occupation: applicant.occupation
    });
    return false;
  }
}

// Main testing function
async function runTests() {
  console.log('🚀 Starting Tenafyi Comprehensive Testing');
  console.log('================================================');
  
  // Test API first
  const apiWorking = await testAPI();
  if (!apiWorking) {
    console.log('❌ API tests failed. Cannot proceed with application testing.');
    return;
  }
  
  console.log('📝 Generating and testing 50 fictional applicants...\n');
  
  // Generate and test 50 applicants
  for (let i = 0; i < 50; i++) {
    const applicant = generateTestApplicant(i);
    testResults.totalTests++;
    
    await submitApplication(applicant, i);
    
    // Add small delay to avoid overwhelming the server
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  
  // Generate test report
  const report = generateTestReport();
  
  // Save report to file
  fs.writeFileSync('testing/test-report.json', JSON.stringify(testResults, null, 2));
  fs.writeFileSync('testing/test-report.txt', report);
  
  console.log('\n' + report);
  console.log('\n📊 Full results saved to testing/test-report.json and testing/test-report.txt');
}

function generateTestReport() {
  const successRate = ((testResults.successfulSubmissions / testResults.totalTests) * 100).toFixed(1);
  
  let report = `
TENAFYI TESTING REPORT
=====================

SUMMARY:
- Total Tests: ${testResults.totalTests}
- Successful: ${testResults.successfulSubmissions} (${successRate}%)
- Failed: ${testResults.failedSubmissions}

TEST SCENARIOS COVERAGE:
`;

  const scenarioStats = {};
  testResults.testCases.forEach(testCase => {
    if (!scenarioStats[testCase.scenario]) {
      scenarioStats[testCase.scenario] = { total: 0, success: 0 };
    }
    scenarioStats[testCase.scenario].total++;
    if (testCase.status === 'SUCCESS') {
      scenarioStats[testCase.scenario].success++;
    }
  });

  Object.entries(scenarioStats).forEach(([scenario, stats]) => {
    const rate = ((stats.success / stats.total) * 100).toFixed(0);
    report += `- ${scenario}: ${stats.success}/${stats.total} (${rate}%)\n`;
  });

  if (testResults.errors.length > 0) {
    report += `\nERRORS FOUND:\n`;
    testResults.errors.forEach((error, index) => {
      report += `${index + 1}. ${error}\n`;
    });
  }

  if (testResults.warnings.length > 0) {
    report += `\nWARNINGS:\n`;
    testResults.warnings.forEach((warning, index) => {
      report += `${index + 1}. ${warning}\n`;
    });
  }

  report += `\nRECOMMENDations:`;
  if (testResults.failedSubmissions === 0) {
    report += `\n✅ All tests passed! System is working correctly.`;
  } else {
    report += `\n⚠️  ${testResults.failedSubmissions} tests failed. Review errors above.`;
  }

  if (successRate < 95) {
    report += `\n🔧 Success rate (${successRate}%) is below 95%. Investigation needed.`;
  }

  return report;
}

// Run the tests
if (import.meta.url === `file://${process.argv[1]}`) {
  runTests().catch(error => {
    console.error('❌ Test runner failed:', error);
    process.exit(1);
  });
}

export { runTests, generateTestApplicant };