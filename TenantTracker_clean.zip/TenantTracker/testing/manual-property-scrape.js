#!/usr/bin/env node

/**
 * Manual Property Scraping Test
 * Manually scrape JT Property Consultants and update database
 */

import axios from 'axios';

async function manualScrape() {
  console.log('🔧 Manual Property Scraping Test');
  console.log('================================\n');
  
  try {
    // Fetch live website
    console.log('1. Fetching JT Property Consultants website...');
    const response = await axios.get('https://jtpropertyconsultants.co.uk/property-to-rent', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    const html = response.data;
    console.log(`✅ Website fetched (${html.length} characters)`);
    
    // Extract property data
    console.log('\n2. Extracting property data...');
    
    // Property URLs
    const propertyUrlPattern = /\/property\/[^"'\s>]+/g;
    const allUrls = [...new Set(html.match(propertyUrlPattern) || [])];
    const validUrls = allUrls.filter(url => 
      url.includes('/property/') && 
      !url.includes('/image/') && 
      !url.includes('#arrangeviewing') &&
      url.match(/\/property\/[^\/]*to-rent-in/)
    );
    
    // Titles
    const titlePattern = /(\d+\s*bed[^<"']*(?:to\s*rent|house|flat|bungalow|chalet)[^<"']*)/gi;
    const titles = html.match(titlePattern) || [];
    
    // Prices  
    const priceValuePattern = /price-value">£([\d,]+)</gi;
    let prices = [];
    let priceMatch;
    while ((priceMatch = priceValuePattern.exec(html)) !== null) {
      prices.push(priceMatch[1]);
    }
    
    console.log(`Found ${allUrls.length} total URLs, ${validUrls.length} valid property URLs`);
    console.log(`Found ${titles.length} property titles`);
    console.log(`Found ${prices.length} prices`);
    
    if (validUrls.length > 0) {
      console.log('\n📋 Valid Property URLs:');
      validUrls.forEach((url, index) => {
        console.log(`  ${index + 1}. https://jtpropertyconsultants.co.uk${url}`);
      });
    }
    
    if (titles.length > 0) {
      console.log('\n🏠 Property Titles:');
      titles.forEach((title, index) => {
        console.log(`  ${index + 1}. ${title.replace(/[<>"]/g, '').trim()}`);
      });
    }
    
    if (prices.length > 0) {
      console.log('\n💰 Prices:');
      prices.forEach((price, index) => {
        console.log(`  ${index + 1}. £${price} per month`);
      });
    }
    
    // Build property objects
    const properties = [];
    const maxProperties = Math.min(titles.length, prices.length, validUrls.length);
    
    for (let i = 0; i < maxProperties; i++) {
      const title = titles[i].replace(/[<>"]/g, '').trim();
      const price = prices[i];
      
      properties.push({
        title: title,
        price: `£${price} per month`,
        beds: extractBedInfo(title),
        thumbnail: 'https://cdn2-property.estateapps.co.uk/files/property/443/image/default.jpg',
        url: `https://jtpropertyconsultants.co.uk${validUrls[i]}`,
        description: `Property available to rent in ${extractLocation(title)}`
      });
    }
    
    console.log(`\n🎯 Successfully created ${properties.length} property objects`);
    
    if (properties.length > 0) {
      console.log('\n📊 Final Properties:');
      properties.forEach((prop, index) => {
        console.log(`  ${index + 1}. ${prop.title}`);
        console.log(`     Price: ${prop.price}`);
        console.log(`     Beds: ${prop.beds}`);
        console.log(`     URL: ${prop.url}`);
        console.log('');
      });
      
      // Insert into database
      console.log('3. Inserting properties into database...');
      const insertResponse = await axios.post('http://localhost:5000/api/admin/manual-update-properties', {
        properties: properties
      });
      
      console.log(`✅ Database updated successfully`);
    } else {
      console.log('\n⚠️  No properties found - this confirms the test removal worked!');
    }
    
    return properties;
    
  } catch (error) {
    console.error('❌ Manual scraping failed:', error.message);
    return [];
  }
}

function extractBedInfo(title) {
  const bedMatch = title.match(/(\d+)\s*bed/i);
  if (bedMatch) {
    return `${bedMatch[1]} bed, 1 bath`;
  }
  return 'Studio';
}

function extractLocation(title) {
  const locationMatch = title.match(/in\s+([^,]+)/i);
  return locationMatch ? locationMatch[1].trim() : 'Kent area';
}

// Run manual scrape
manualScrape().catch(console.error);