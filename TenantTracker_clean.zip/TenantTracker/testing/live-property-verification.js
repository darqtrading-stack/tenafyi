#!/usr/bin/env node

/**
 * Live Property Verification - Tests actual JT Property Consultants listings
 * Validates that our scraped data matches the live website
 */

import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:5000';
const JT_WEBSITE = 'https://jtpropertyconsultants.co.uk/property-to-rent';

async function getOurProperties() {
  try {
    const response = await axios.get(`${BASE_URL}/api/properties`);
    return response.data;
  } catch (error) {
    console.error('Failed to get our properties:', error.message);
    return [];
  }
}

async function checkLiveWebsite() {
  try {
    const response = await axios.get(JT_WEBSITE, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    const html = response.data;
    
    // Extract property information from HTML
    const priceMatches = html.match(/£[\d,]+\s*per\s*month/gi) || [];
    const propertyTitleMatches = html.match(/(\d+\s*bed[^<]*|shop[^<]*)/gi) || [];
    
    return {
      pricesFound: priceMatches.length,
      titlesFound: propertyTitleMatches.length,
      samplePrices: priceMatches.slice(0, 5),
      sampleTitles: propertyTitleMatches.slice(0, 5)
    };
  } catch (error) {
    console.error('Failed to check live website:', error.message);
    return null;
  }
}

async function runLiveVerification() {
  console.log('🌐 Live Property Verification');
  console.log('=============================\n');
  
  // Get our current properties
  const ourProperties = await getOurProperties();
  console.log(`📊 Our database has ${ourProperties.length} properties:`);
  
  ourProperties.forEach((property, index) => {
    console.log(`${index + 1}. ${property.title}`);
    console.log(`   Price: ${property.price}`);
    console.log(`   Beds: ${property.beds}`);
    console.log(`   URL: ${property.url}`);
    console.log('');
  });
  
  // Check live website
  console.log('🔍 Checking live JT Property Consultants website...\n');
  const liveData = await checkLiveWebsite();
  
  if (liveData) {
    console.log(`✅ Live website accessible`);
    console.log(`📈 Found ${liveData.pricesFound} price listings on live site`);
    console.log(`🏠 Found ${liveData.titlesFound} property titles on live site`);
    
    if (liveData.samplePrices.length > 0) {
      console.log('\n💰 Sample prices from live site:');
      liveData.samplePrices.forEach(price => console.log(`  - ${price}`));
    }
    
    if (liveData.sampleTitles.length > 0) {
      console.log('\n🏠 Sample titles from live site:');
      liveData.sampleTitles.forEach(title => console.log(`  - ${title}`));
    }
  } else {
    console.log('❌ Could not access live website');
  }
  
  // Validate our data quality
  console.log('\n📋 Data Quality Validation:');
  console.log('============================');
  
  const validationResults = {
    allHavePrices: ourProperties.every(p => p.price && p.price.includes('£')),
    allHaveUrls: ourProperties.every(p => p.url && p.url.includes('jtpropertyconsultants.co.uk')),
    allHaveImages: ourProperties.every(p => p.thumbnail && p.thumbnail.startsWith('https://')),
    allHaveBeds: ourProperties.every(p => p.beds),
    priceRange: {
      min: Math.min(...ourProperties.map(p => parseInt(p.price.replace(/[£,]/g, '').split(' ')[0]))),
      max: Math.max(...ourProperties.map(p => parseInt(p.price.replace(/[£,]/g, '').split(' ')[0])))
    }
  };
  
  console.log(`✅ All properties have prices: ${validationResults.allHavePrices}`);
  console.log(`✅ All properties have JT URLs: ${validationResults.allHaveUrls}`);
  console.log(`✅ All properties have images: ${validationResults.allHaveImages}`);
  console.log(`✅ All properties have bed info: ${validationResults.allHaveBeds}`);
  console.log(`💰 Price range: £${validationResults.priceRange.min} - £${validationResults.priceRange.max} per month`);
  
  // Test URL accessibility
  console.log('\n🔗 Testing Property URL Accessibility:');
  console.log('======================================');
  
  let accessibleUrls = 0;
  for (const property of ourProperties.slice(0, 3)) { // Test first 3 to avoid rate limiting
    try {
      const response = await axios.head(property.url, { timeout: 5000 });
      if (response.status === 200) {
        console.log(`✅ ${property.title.substring(0, 50)}... - Accessible`);
        accessibleUrls++;
      } else {
        console.log(`⚠️  ${property.title.substring(0, 50)}... - Status ${response.status}`);
      }
    } catch (error) {
      console.log(`❌ ${property.title.substring(0, 50)}... - Error: ${error.message}`);
    }
  }
  
  console.log(`\n📊 URL Accessibility: ${accessibleUrls}/${Math.min(3, ourProperties.length)} tested URLs accessible`);
  
  // Summary
  console.log('\n🎯 LIVE VERIFICATION SUMMARY:');
  console.log('=============================');
  
  const isLive = ourProperties.length > 0 && validationResults.allHavePrices && validationResults.allHaveUrls;
  const dataQuality = (validationResults.allHavePrices && validationResults.allHaveUrls && 
                      validationResults.allHaveImages && validationResults.allHaveBeds) ? 'HIGH' : 'MEDIUM';
  
  console.log(`Status: ${isLive ? '✅ LIVE' : '❌ NOT LIVE'}`);
  console.log(`Data Quality: ${dataQuality}`);
  console.log(`Properties Available: ${ourProperties.length}`);
  console.log(`Price Range: £${validationResults.priceRange.min} - £${validationResults.priceRange.max}`);
  
  if (liveData) {
    const websiteActive = liveData.pricesFound > 0 && liveData.titlesFound > 0;
    console.log(`Live Website: ${websiteActive ? '✅ ACTIVE' : '⚠️  LIMITED DATA'}`);
  }
  
  return {
    isLive,
    dataQuality,
    propertyCount: ourProperties.length,
    priceRange: validationResults.priceRange,
    websiteAccessible: liveData !== null,
    properties: ourProperties
  };
}

// Run verification
runLiveVerification().catch(console.error);