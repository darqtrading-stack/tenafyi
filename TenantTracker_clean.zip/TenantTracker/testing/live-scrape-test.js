#!/usr/bin/env node

/**
 * Live Website Scraping Test
 * Tests real-time scraping from JT Property Consultants
 */

import axios from 'axios';

async function testLiveScraping() {
  console.log('🌐 Testing Live JT Property Consultants Scraping');
  console.log('================================================\n');
  
  try {
    console.log('1. Fetching live website data...');
    const response = await axios.get('https://jtpropertyconsultants.co.uk/property-to-rent', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      timeout: 10000
    });
    
    const html = response.data;
    console.log(`✅ Website accessed successfully (${html.length} characters)`);
    
    // Look for property URLs
    console.log('\n2. Extracting property URLs...');
    const propertyUrlPattern = /\/property\/[^"'\s>]+(?=["'\s>])/g;
    const propertyUrls = [...new Set(html.match(propertyUrlPattern) || [])];
    
    console.log(`Found ${propertyUrls.length} unique property URLs:`);
    propertyUrls.slice(0, 8).forEach((url, index) => {
      console.log(`  ${index + 1}. https://jtpropertyconsultants.co.uk${url}`);
    });
    
    // Look for prices
    console.log('\n3. Extracting prices...');
    const pricePatterns = [
      /£[\d,]+\s*(?:per\s*month|pcm)/gi,
      /price-value">£([\d,]+)</gi,
      /"£([\d,]+)"/gi
    ];
    
    let allPrices = [];
    pricePatterns.forEach((pattern, index) => {
      const matches = html.match(pattern) || [];
      console.log(`  Pattern ${index + 1}: Found ${matches.length} price matches`);
      if (matches.length > 0) {
        console.log(`    Sample: ${matches.slice(0, 3).join(', ')}`);
        allPrices.push(...matches);
      }
    });
    
    // Look for property titles
    console.log('\n4. Extracting property titles...');
    const titlePatterns = [
      /(\d+\s*bed[^<"']*(?:to\s*rent|house|flat|bungalow|chalet)[^<"']*)/gi,
      /"([^"]*\d+\s*bed[^"]*to\s*rent[^"]*)"/gi,
      />([^<]*\d+\s*bed[^<]*to\s*rent[^<]*)</gi
    ];
    
    let allTitles = [];
    titlePatterns.forEach((pattern, index) => {
      const matches = html.match(pattern) || [];
      console.log(`  Pattern ${index + 1}: Found ${matches.length} title matches`);
      if (matches.length > 0) {
        const cleanTitles = matches.slice(0, 3).map(m => m.replace(/[<>"]/g, '').trim());
        console.log(`    Sample: ${cleanTitles.join(' | ')}`);
        allTitles.push(...matches);
      }
    });
    
    // Extract structured property data
    console.log('\n5. Attempting structured extraction...');
    
    // Look for property cards or blocks
    const propertyBlockPattern = /<[^>]*property[^>]*>[\s\S]*?<\/[^>]*>/gi;
    const propertyBlocks = html.match(propertyBlockPattern) || [];
    console.log(`Found ${propertyBlocks.length} potential property blocks`);
    
    // Check if there are property listings in the HTML
    const hasPropertyListings = html.includes('property-to-rent') || 
                               html.includes('bed') && html.includes('rent') ||
                               html.includes('£') && html.includes('month');
    
    console.log('\n📊 EXTRACTION SUMMARY:');
    console.log('======================');
    console.log(`Property URLs found: ${propertyUrls.length}`);
    console.log(`Price matches found: ${allPrices.length}`);
    console.log(`Title matches found: ${allTitles.length}`);
    console.log(`Has property listings: ${hasPropertyListings ? 'Yes' : 'No'}`);
    console.log(`Website responsive: ${response.status === 200 ? 'Yes' : 'No'}`);
    
    if (propertyUrls.length === 0 && allPrices.length === 0) {
      console.log('\n⚠️  WARNING: No properties detected on live website');
      console.log('This could mean:');
      console.log('- Properties have been removed (as per your test)');
      console.log('- Website structure has changed');
      console.log('- Scraping patterns need updating');
    }
    
    return {
      success: true,
      propertyUrls: propertyUrls.length,
      prices: allPrices.length,
      titles: allTitles.length,
      hasListings: hasPropertyListings,
      websiteStatus: response.status
    };
    
  } catch (error) {
    console.error('❌ Live scraping failed:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
}

// Run the test
testLiveScraping().then(result => {
  if (result.success) {
    console.log('\n🎯 LIVE SCRAPING TEST RESULT: SUCCESS');
    console.log(`Current live properties detected: ${result.propertyUrls}`);
  } else {
    console.log('\n❌ LIVE SCRAPING TEST RESULT: FAILED');
    console.log(`Error: ${result.error}`);
  }
}).catch(console.error);