#!/usr/bin/env node

/**
 * Property URL Checker - Verifies live JT Property Consultants URLs
 * Checks if property URLs have changed and finds correct ones
 */

import axios from 'axios';
import fs from 'fs';

const JT_BASE_URL = 'https://jtpropertyconsultants.co.uk';
const JT_LISTINGS_URL = 'https://jtpropertyconsultants.co.uk/property-to-rent';

async function getCurrentProperties() {
  try {
    const response = await axios.get('http://localhost:5000/api/properties');
    return response.data;
  } catch (error) {
    console.error('Failed to get current properties:', error.message);
    return [];
  }
}

async function checkJTWebsiteStructure() {
  console.log('🔍 Checking JT Property Consultants website structure...\n');
  
  try {
    const response = await axios.get(JT_LISTINGS_URL, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      timeout: 10000
    });
    
    const html = response.data;
    
    // Look for property URLs in the HTML
    const propertyUrlPattern = /\/property\/[^"'\s>]+/g;
    const propertyUrls = [...new Set(html.match(propertyUrlPattern) || [])];
    
    // Look for prices
    const pricePattern = /£[\d,]+\s*(?:per\s*month|pcm)/gi;
    const prices = html.match(pricePattern) || [];
    
    // Look for property titles
    const titlePattern = /(\d+\s*bed[^<"']*(?:to\s*rent|house|flat|bungalow|chalet)[^<"']*)/gi;
    const titles = html.match(titlePattern) || [];
    
    console.log(`✅ Found ${propertyUrls.length} property URLs on live site`);
    console.log(`💰 Found ${prices.length} prices on live site`);
    console.log(`🏠 Found ${titles.length} property titles on live site`);
    
    if (propertyUrls.length > 0) {
      console.log('\n🔗 Sample property URLs found:');
      propertyUrls.slice(0, 5).forEach(url => {
        console.log(`  - ${JT_BASE_URL}${url}`);
      });
    }
    
    if (prices.length > 0) {
      console.log('\n💰 Sample prices found:');
      prices.slice(0, 5).forEach(price => {
        console.log(`  - ${price}`);
      });
    }
    
    if (titles.length > 0) {
      console.log('\n🏠 Sample titles found:');
      titles.slice(0, 5).forEach(title => {
        console.log(`  - ${title.trim()}`);
      });
    }
    
    return {
      propertyUrls: propertyUrls.map(url => `${JT_BASE_URL}${url}`),
      prices,
      titles,
      websiteAccessible: true
    };
    
  } catch (error) {
    console.error('❌ Failed to access JT website:', error.message);
    return {
      propertyUrls: [],
      prices: [],
      titles: [],
      websiteAccessible: false,
      error: error.message
    };
  }
}

async function verifyPropertyUrls(properties) {
  console.log('\n🔗 Verifying individual property URLs...\n');
  
  const results = [];
  
  for (const property of properties) {
    try {
      const response = await axios.head(property.url, {
        timeout: 5000,
        maxRedirects: 5,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      console.log(`✅ ${property.title.substring(0, 60)}... - Accessible (${response.status})`);
      results.push({
        property: property.title,
        url: property.url,
        status: 'accessible',
        statusCode: response.status
      });
      
    } catch (error) {
      if (error.response) {
        console.log(`❌ ${property.title.substring(0, 60)}... - ${error.response.status} ${error.response.statusText}`);
        results.push({
          property: property.title,
          url: property.url,
          status: 'error',
          statusCode: error.response.status,
          error: error.response.statusText
        });
      } else {
        console.log(`❌ ${property.title.substring(0, 60)}... - ${error.message}`);
        results.push({
          property: property.title,
          url: property.url,
          status: 'error',
          error: error.message
        });
      }
    }
    
    // Small delay to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  return results;
}

async function runPropertyUrlCheck() {
  console.log('🌐 Property URL Verification & Update Check');
  console.log('===========================================\n');
  
  // Get current properties
  const properties = await getCurrentProperties();
  console.log(`📊 Checking ${properties.length} properties in our database\n`);
  
  // Check website structure
  const websiteData = await checkJTWebsiteStructure();
  
  // Verify individual URLs
  const urlResults = await verifyPropertyUrls(properties);
  
  // Analysis
  const accessibleUrls = urlResults.filter(r => r.status === 'accessible').length;
  const errorUrls = urlResults.filter(r => r.status === 'error').length;
  
  console.log('\n📊 URL VERIFICATION SUMMARY:');
  console.log('============================');
  console.log(`✅ Accessible URLs: ${accessibleUrls}/${properties.length}`);
  console.log(`❌ Error URLs: ${errorUrls}/${properties.length}`);
  console.log(`🌐 Website accessible: ${websiteData.websiteAccessible ? 'Yes' : 'No'}`);
  console.log(`🔗 Live URLs found: ${websiteData.propertyUrls.length}`);
  
  // Recommendations
  console.log('\n🎯 RECOMMENDATIONS:');
  console.log('===================');
  
  if (errorUrls > 0) {
    console.log(`⚠️  ${errorUrls} property URLs are not accessible`);
    console.log('- Properties may have been moved or removed');
    console.log('- Need to update scraping service');
  }
  
  if (websiteData.propertyUrls.length > properties.length) {
    console.log(`📈 Live site has ${websiteData.propertyUrls.length} URLs vs our ${properties.length} properties`);
    console.log('- New properties may be available');
    console.log('- Consider running fresh scrape');
  }
  
  if (!websiteData.websiteAccessible) {
    console.log('❌ Cannot access JT Property Consultants website');
    console.log('- Check network connectivity');
    console.log('- Website may be down temporarily');
  }
  
  // Save detailed results
  const report = {
    timestamp: new Date().toISOString(),
    summary: {
      totalProperties: properties.length,
      accessibleUrls: accessibleUrls,
      errorUrls: errorUrls,
      websiteAccessible: websiteData.websiteAccessible,
      liveUrlsFound: websiteData.propertyUrls.length
    },
    urlResults: urlResults,
    websiteData: websiteData,
    properties: properties
  };
  
  fs.writeFileSync('testing/property-url-check-report.json', JSON.stringify(report, null, 2));
  console.log('\n📊 Detailed results saved to testing/property-url-check-report.json');
  
  return report;
}

// Run the check
runPropertyUrlCheck().catch(console.error);