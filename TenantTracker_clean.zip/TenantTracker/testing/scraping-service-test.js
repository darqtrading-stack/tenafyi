#!/usr/bin/env node

/**
 * Scraping Service Verification
 * Tests the property scraping service functionality
 */

import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:5000';

async function testScrapingService() {
  console.log('🔧 Testing Property Scraping Service');
  console.log('===================================\n');
  
  // Check if manual scrape endpoint exists
  try {
    console.log('1. Testing manual scrape endpoint...');
    const scrapeResponse = await axios.post(`${BASE_URL}/api/admin/scrape-properties`, {}, {
      timeout: 30000
    });
    
    console.log(`✅ Manual scrape endpoint responded: ${scrapeResponse.status}`);
    console.log(`Response: ${JSON.stringify(scrapeResponse.data, null, 2)}`);
    
  } catch (error) {
    if (error.response) {
      console.log(`⚠️  Manual scrape endpoint exists but returned: ${error.response.status}`);
      console.log(`Response: ${JSON.stringify(error.response.data, null, 2)}`);
    } else {
      console.log(`❌ Manual scrape endpoint not available: ${error.message}`);
    }
  }
  
  // Get properties before and after
  console.log('\n2. Checking current properties...');
  const propertiesBefore = await getProperties();
  console.log(`Properties in database: ${propertiesBefore.length}`);
  
  if (propertiesBefore.length > 0) {
    console.log('Last updated properties:');
    propertiesBefore.slice(0, 3).forEach((prop, index) => {
      console.log(`  ${index + 1}. ${prop.title}`);
      console.log(`     Price: ${prop.price}`);
      console.log(`     Updated: ${prop.scrapedAt || 'Unknown'}`);
    });
  }
  
  // Test fallback properties
  console.log('\n3. Testing fallback property data...');
  const fallbackProperties = [
    {
      title: '4 bed bungalow to rent in New Barn Road, Longfield, DA3 7JE',
      expectedPrice: '£3,495 per month',
      expectedBeds: '4 bed, 3 bath'
    },
    {
      title: 'Shop to rent in Sidcup Road, London, SE9 3NS', 
      expectedPrice: '£1,500 per month',
      expectedBeds: 'Commercial'
    },
    {
      title: '1 bed flat to rent in Portland Avenue, Sittingbourne, Kent, ME10 3QZ',
      expectedPrice: '£875 per month',
      expectedBeds: '1 bed, 1 bath'
    }
  ];
  
  let matchingProperties = 0;
  fallbackProperties.forEach(expected => {
    const found = propertiesBefore.find(p => p.title === expected.title);
    if (found) {
      console.log(`✅ Found: ${expected.title}`);
      console.log(`   Price: ${found.price} (expected: ${expected.expectedPrice})`);
      console.log(`   Beds: ${found.beds} (expected: ${expected.expectedBeds})`);
      matchingProperties++;
    } else {
      console.log(`❌ Missing: ${expected.title}`);
    }
  });
  
  console.log(`\nFallback data verification: ${matchingProperties}/${fallbackProperties.length} properties match`);
  
  return {
    totalProperties: propertiesBefore.length,
    fallbackMatches: matchingProperties,
    properties: propertiesBefore
  };
}

async function getProperties() {
  try {
    const response = await axios.get(`${BASE_URL}/api/properties`);
    return response.data;
  } catch (error) {
    console.error('Failed to get properties:', error.message);
    return [];
  }
}

async function testUrlAccessibility() {
  console.log('\n4. Testing property URL accessibility (sample)...');
  
  const properties = await getProperties();
  const testUrls = properties.slice(0, 3); // Test first 3
  
  for (const property of testUrls) {
    try {
      const response = await axios.head(property.url, {
        timeout: 5000,
        maxRedirects: 5
      });
      console.log(`✅ ${property.title.substring(0, 50)}... - Accessible`);
    } catch (error) {
      if (error.response && error.response.status === 404) {
        console.log(`❌ ${property.title.substring(0, 50)}... - 404 Not Found`);
      } else {
        console.log(`⚠️  ${property.title.substring(0, 50)}... - ${error.message}`);
      }
    }
  }
}

// Run the test
testScrapingService()
  .then(results => {
    console.log('\n📊 SCRAPING SERVICE SUMMARY');
    console.log('===========================');
    console.log(`Total properties: ${results.totalProperties}`);
    console.log(`Fallback matches: ${results.fallbackMatches}/3`);
    console.log(`Service status: ${results.totalProperties > 0 ? '✅ WORKING' : '❌ NOT WORKING'}`);
    
    if (results.totalProperties > 0) {
      console.log('\nThe scraping service is providing property data.');
      console.log('Properties are being served from fallback data source.');
    } else {
      console.log('\nThe scraping service is not providing any property data.');
    }
    
    return testUrlAccessibility();
  })
  .catch(console.error);