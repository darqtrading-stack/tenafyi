#!/usr/bin/env node

/**
 * Comprehensive Validation Testing for Tenafyi
 * 1. Validates property listings are correct and updated
 * 2. Tests all questions with 100 diverse applicants
 * 3. Validates both bot and form question alignment
 */

import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:5000';

// Expected property listings from JT Property Consultants
const EXPECTED_PROPERTIES = [
  '4 bed bungalow to rent in New Barn Road, Longfield, DA3 7JE',
  '4 bed detached house to rent in Broadacre View',
  '4 bed chalet to rent in Ufton Lane, Sittingbourne, Kent, ME10 1EU',
  'Shop to rent in Sidcup Road, London, SE9 3NS',
  '2 bed flat to rent in Russet Walk, Greenhithe, DA9 9WY',
  '2 bed ground floor flat to rent in Henshaaws Vale, Sittingbourne, Kent, ME10 3NY',
  '1 bed flat to rent in Park Road, Sittingbourne, ME10 1DY',
  '1 bed flat to rent in Portland Avenue, Sittingbourne, Kent, ME10 3QZ'
];

// Generate 100 diverse test applicants
function generateTestApplicants() {
  const firstNames = ['James', 'Sarah', 'Michael', 'Emma', 'David', 'Lisa', 'Robert', 'Sophie', 'John', 'Maria', 
                     'William', 'Anna', 'Thomas', 'Lucy', 'Daniel', 'Grace', 'Paul', 'Amy', 'Mark', 'Helen'];
  const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
                    'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin'];
  const occupations = ['Employed', 'Self-employed', 'Student', 'Unemployed', 'Retired'];
  const moveDates = ['ASAP', 'Within 2 weeks', 'I need to give one months notice'];
  const rentalPeriods = ['6 months', '1 year', '2+ years'];
  const contactTimes = ['Morning', 'Afternoon', 'Evening', 'Anytime'];
  const contactMethods = ['Phone call', 'Text/SMS', 'Email', 'WhatsApp'];
  
  const applicants = [];
  
  for (let i = 1; i <= 100; i++) {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const occupation = occupations[Math.floor(Math.random() * occupations.length)];
    const hasPets = Math.random() > 0.6; // 40% have pets
    const smokes = Math.random() > 0.8; // 20% smoke
    const hasCCJ = Math.random() > 0.85; // 15% have CCJs
    const hasAdverseMedia = Math.random() > 0.95; // 5% have adverse media
    const hasGuarantor = Math.random() > 0.3; // 70% have guarantor
    const adults = Math.floor(Math.random() * 4) + 1; // 1-4 adults
    const children = Math.random() > 0.5 ? Math.floor(Math.random() * 3) : 0; // 0-2 children
    const income = Math.floor(Math.random() * 80000) + 20000; // £20k-£100k
    
    // Select 1-3 random properties
    const numProperties = Math.floor(Math.random() * 3) + 1;
    const selectedProperties = [];
    const shuffledProperties = [...EXPECTED_PROPERTIES].sort(() => 0.5 - Math.random());
    for (let j = 0; j < numProperties; j++) {
      selectedProperties.push(shuffledProperties[j]);
    }
    
    const applicant = {
      fullName: `${firstName} ${lastName}`,
      email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}${i}@test.com`,
      phone: `077${String(Math.floor(Math.random() * 100000000)).padStart(8, '0')}`,
      adults: adults,
      children: children,
      moveDate: moveDates[Math.floor(Math.random() * moveDates.length)],
      rentalPeriod: rentalPeriods[Math.floor(Math.random() * rentalPeriods.length)],
      hasPets: hasPets,
      petDetails: hasPets ? `${Math.floor(Math.random() * 2) + 1} pet(s) - details here` : '',
      smokes: smokes,
      occupation: occupation,
      hasTaxReturns: occupation === 'Self-employed' ? Math.random() > 0.2 : undefined,
      annualIncome: income,
      hasCCJIVA: hasCCJ,
      hasAdverseMedia: hasAdverseMedia,
      hasGuarantor: hasGuarantor,
      contactTime: contactTimes[Math.floor(Math.random() * contactTimes.length)],
      contactMethod: contactMethods[Math.floor(Math.random() * contactMethods.length)],
      additionalNotes: Math.random() > 0.7 ? `Additional notes for applicant ${i}` : '',
      property: selectedProperties
    };
    
    applicants.push(applicant);
  }
  
  return applicants;
}

async function validatePropertyListings() {
  console.log('🏠 Validating Property Listings');
  console.log('================================');
  
  try {
    const response = await axios.get(`${BASE_URL}/api/properties`);
    const properties = response.data;
    
    console.log(`✅ Retrieved ${properties.length} properties from API`);
    
    // Check each property has required fields
    const requiredFields = ['title', 'price', 'beds', 'thumbnail', 'url', 'description'];
    let validProperties = 0;
    const issues = [];
    
    properties.forEach((property, index) => {
      const missing = requiredFields.filter(field => !property[field]);
      if (missing.length === 0) {
        validProperties++;
      } else {
        issues.push(`Property ${index + 1}: Missing fields - ${missing.join(', ')}`);
      }
    });
    
    console.log(`✅ ${validProperties}/${properties.length} properties have all required fields`);
    
    // Check if properties match expected listings
    const propertyTitles = properties.map(p => p.title);
    const missingProperties = EXPECTED_PROPERTIES.filter(expected => 
      !propertyTitles.some(title => title.includes(expected.split(' to rent in ')[1]) || expected.includes(title))
    );
    
    if (missingProperties.length === 0) {
      console.log('✅ All expected properties are present');
    } else {
      console.log(`⚠️  ${missingProperties.length} expected properties missing:`);
      missingProperties.forEach(prop => console.log(`   - ${prop}`));
    }
    
    // Check for recent updates
    const recentProperties = properties.filter(p => {
      const scrapedAt = new Date(p.scrapedAt);
      const hoursSinceUpdate = (Date.now() - scrapedAt.getTime()) / (1000 * 60 * 60);
      return hoursSinceUpdate < 24; // Updated within 24 hours
    });
    
    console.log(`✅ ${recentProperties.length}/${properties.length} properties updated within 24 hours`);
    
    if (issues.length > 0) {
      console.log('\n⚠️  Property Issues Found:');
      issues.forEach(issue => console.log(`   ${issue}`));
    }
    
    return {
      total: properties.length,
      valid: validProperties,
      recent: recentProperties.length,
      issues: issues,
      properties: properties
    };
    
  } catch (error) {
    console.log('❌ Failed to validate properties:', error.message);
    return null;
  }
}

async function testAllQuestions() {
  console.log('\n📝 Testing All Questions with 100 Applicants');
  console.log('==============================================');
  
  const applicants = generateTestApplicants();
  let successCount = 0;
  let failureCount = 0;
  const errors = [];
  const questionValidation = {
    fullName: { tested: 0, passed: 0 },
    email: { tested: 0, passed: 0 },
    phone: { tested: 0, passed: 0 },
    adults: { tested: 0, passed: 0 },
    children: { tested: 0, passed: 0 },
    moveDate: { tested: 0, passed: 0 },
    rentalPeriod: { tested: 0, passed: 0 },
    hasPets: { tested: 0, passed: 0 },
    petDetails: { tested: 0, passed: 0 },
    smokes: { tested: 0, passed: 0 },
    occupation: { tested: 0, passed: 0 },
    hasTaxReturns: { tested: 0, passed: 0 },
    annualIncome: { tested: 0, passed: 0 },
    hasCCJIVA: { tested: 0, passed: 0 },
    hasAdverseMedia: { tested: 0, passed: 0 },
    hasGuarantor: { tested: 0, passed: 0 },
    contactTime: { tested: 0, passed: 0 },
    contactMethod: { tested: 0, passed: 0 },
    property: { tested: 0, passed: 0 }
  };
  
  console.log('Submitting 100 test applications...\n');
  
  for (let i = 0; i < applicants.length; i++) {
    const applicant = applicants[i];
    
    try {
      // Count field testing
      Object.keys(questionValidation).forEach(field => {
        if (applicant[field] !== undefined && applicant[field] !== '') {
          questionValidation[field].tested++;
        }
      });
      
      const response = await axios.post(`${BASE_URL}/api/applications`, applicant);
      
      if (response.status === 201) {
        successCount++;
        
        // Count successful field validations
        Object.keys(questionValidation).forEach(field => {
          if (applicant[field] !== undefined && applicant[field] !== '') {
            questionValidation[field].passed++;
          }
        });
        
        if ((i + 1) % 10 === 0) {
          console.log(`✅ ${i + 1}/100 applications submitted successfully`);
        }
      }
      
    } catch (error) {
      failureCount++;
      errors.push({
        applicant: `${applicant.fullName} (#${i + 1})`,
        error: error.response?.data?.message || error.message,
        data: applicant
      });
      
      console.log(`❌ Application ${i + 1} failed: ${error.response?.data?.message || error.message}`);
    }
  }
  
  return {
    total: applicants.length,
    successful: successCount,
    failed: failureCount,
    errors: errors,
    questionValidation: questionValidation
  };
}

async function runComprehensiveValidation() {
  console.log('🧪 Starting Comprehensive Tenafyi Validation');
  console.log('===============================================');
  console.log(`Testing with 100 diverse applicants at ${new Date().toISOString()}\n`);
  
  // Step 1: Validate Properties
  const propertyValidation = await validatePropertyListings();
  
  // Step 2: Test All Questions
  const questionTesting = await testAllQuestions();
  
  // Generate comprehensive report
  console.log('\n\n📊 COMPREHENSIVE VALIDATION REPORT');
  console.log('===================================\n');
  
  // Property Summary
  console.log('🏠 PROPERTY VALIDATION:');
  if (propertyValidation) {
    console.log(`- Total Properties: ${propertyValidation.total}`);
    console.log(`- Valid Properties: ${propertyValidation.valid}`);
    console.log(`- Recently Updated: ${propertyValidation.recent}`);
    console.log(`- Issues Found: ${propertyValidation.issues.length}`);
  } else {
    console.log('- ❌ Property validation failed');
  }
  
  // Question Testing Summary
  console.log('\n📝 QUESTION TESTING:');
  console.log(`- Total Applications: ${questionTesting.total}`);
  console.log(`- Successful: ${questionTesting.successful} (${((questionTesting.successful/questionTesting.total)*100).toFixed(1)}%)`);
  console.log(`- Failed: ${questionTesting.failed}`);
  
  // Field-by-field validation
  console.log('\n🔍 FIELD VALIDATION RESULTS:');
  Object.entries(questionTesting.questionValidation).forEach(([field, stats]) => {
    if (stats.tested > 0) {
      const successRate = ((stats.passed / stats.tested) * 100).toFixed(1);
      console.log(`- ${field}: ${stats.passed}/${stats.tested} (${successRate}%)`);
    }
  });
  
  // Error Analysis
  if (questionTesting.errors.length > 0) {
    console.log('\n❌ ERRORS FOUND:');
    const errorTypes = {};
    questionTesting.errors.forEach(error => {
      const errorType = error.error.split(':')[0] || error.error;
      errorTypes[errorType] = (errorTypes[errorType] || 0) + 1;
    });
    
    Object.entries(errorTypes).forEach(([errorType, count]) => {
      console.log(`- ${errorType}: ${count} occurrences`);
    });
    
    console.log('\nFirst 5 errors:');
    questionTesting.errors.slice(0, 5).forEach((error, index) => {
      console.log(`${index + 1}. ${error.applicant}: ${error.error}`);
    });
  }
  
  // Overall Assessment
  const overallSuccess = questionTesting.successful / questionTesting.total;
  console.log('\n🎯 OVERALL ASSESSMENT:');
  if (overallSuccess >= 0.95) {
    console.log('✅ EXCELLENT - System performing optimally');
  } else if (overallSuccess >= 0.90) {
    console.log('✅ GOOD - Minor issues detected');
  } else if (overallSuccess >= 0.80) {
    console.log('⚠️  FAIR - Some issues need attention');
  } else {
    console.log('❌ POOR - Significant issues require immediate attention');
  }
  
  // Save detailed results
  const detailedReport = {
    timestamp: new Date().toISOString(),
    propertyValidation: propertyValidation,
    questionTesting: {
      summary: {
        total: questionTesting.total,
        successful: questionTesting.successful,
        failed: questionTesting.failed,
        successRate: ((questionTesting.successful/questionTesting.total)*100).toFixed(1) + '%'
      },
      fieldValidation: questionTesting.questionValidation,
      errors: questionTesting.errors
    },
    overallAssessment: {
      successRate: (overallSuccess * 100).toFixed(1) + '%',
      status: overallSuccess >= 0.95 ? 'EXCELLENT' : overallSuccess >= 0.90 ? 'GOOD' : overallSuccess >= 0.80 ? 'FAIR' : 'POOR'
    }
  };
  
  fs.writeFileSync('testing/comprehensive-validation-report.json', JSON.stringify(detailedReport, null, 2));
  console.log('\n📊 Detailed results saved to testing/comprehensive-validation-report.json');
  
  return detailedReport;
}

// Run the comprehensive validation
runComprehensiveValidation().catch(console.error);