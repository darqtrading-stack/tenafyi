#!/usr/bin/env node

/**
 * Comprehensive Form Validation Testing for Tenafyi
 * Tests all form interactions, validation, and error handling
 */

import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:5000';

// Test data for various form validation scenarios
const testScenarios = [
  {
    name: "Complete Valid Application",
    data: {
      fullName: "John Smith",
      email: "john.smith@test.com",
      phone: "07700900001",
      adults: 2,
      children: 0,
      moveDate: "ASAP",
      rentalPeriod: "1 year",
      hasPets: false,
      petDetails: "",
      smokes: false,
      occupation: "Employed",
      annualIncome: 45000,
      hasCCJIVA: false,
      hasAdverseMedia: false,
      hasGuarantor: true,
      contactTime: "Evening",
      contactMethod: "Email",
      additionalNotes: "Looking forward to hearing from you",
      property: ["1 bed flat to rent in Portland Avenue, Sittingbourne, Kent, ME10 3QZ"]
    },
    shouldPass: true,
    description: "Standard valid application with all required fields"
  },
  {
    name: "Missing Required Fields",
    data: {
      fullName: "",
      email: "test@email.com",
      phone: "",
      adults: 1,
      children: 0
    },
    shouldPass: false,
    description: "Application with missing required fields"
  },
  {
    name: "Invalid Email Format",
    data: {
      fullName: "Jane Doe",
      email: "invalid-email",
      phone: "07700900002",
      adults: 1,
      children: 0,
      moveDate: "Within 2 weeks",
      rentalPeriod: "6 months",
      hasPets: false,
      smokes: false,
      occupation: "Student",
      annualIncome: 25000,
      hasCCJIVA: false,
      hasAdverseMedia: false,
      hasGuarantor: true,
      contactTime: "Morning",
      contactMethod: "Phone call",
      property: ["2 bed flat to rent in Russet Walk, Greenhithe, DA9 9WY"]
    },
    shouldPass: false,
    description: "Application with invalid email format"
  },
  {
    name: "Self-Employed with Pets",
    data: {
      fullName: "Sarah Johnson",
      email: "sarah.johnson@test.com",
      phone: "07700900003",
      adults: 2,
      children: 1,
      moveDate: "I need to give one months notice",
      rentalPeriod: "2+ years",
      hasPets: true,
      petDetails: "1 small dog (Jack Russell, 5 years old, house trained)",
      smokes: false,
      occupation: "Self-employed",
      hasTaxReturns: true,
      annualIncome: 38000,
      hasCCJIVA: false,
      hasAdverseMedia: false,
      hasGuarantor: true,
      contactTime: "Afternoon",
      contactMethod: "WhatsApp",
      additionalNotes: "Flexible on move-in date if needed",
      property: ["4 bed detached house to rent in Broadacre View"]
    },
    shouldPass: true,
    description: "Self-employed applicant with pets and detailed information"
  },
  {
    name: "Invalid Income Value",
    data: {
      fullName: "Michael Brown",
      email: "michael.brown@test.com",
      phone: "07700900004",
      adults: 1,
      children: 0,
      moveDate: "ASAP",
      rentalPeriod: "1 year",
      hasPets: false,
      smokes: false,
      occupation: "Employed",
      annualIncome: -5000, // Invalid negative income
      hasCCJIVA: false,
      hasAdverseMedia: false,
      hasGuarantor: false,
      contactTime: "Anytime",
      contactMethod: "Email",
      property: ["Shop to rent in Sidcup Road, London, SE9 3NS"]
    },
    shouldPass: false,
    description: "Application with negative income (should fail validation)"
  },
  {
    name: "Large Family Application",
    data: {
      fullName: "David Wilson",
      email: "david.wilson@test.com", 
      phone: "07700900005",
      adults: 3,
      children: 4,
      moveDate: "Within 2 weeks",
      rentalPeriod: "2+ years",
      hasPets: true,
      petDetails: "2 cats (Persian, 3 and 5 years old) and 1 goldfish",
      smokes: false,
      occupation: "Employed",
      annualIncome: 65000,
      hasCCJIVA: false,
      hasAdverseMedia: false,
      hasGuarantor: true,
      contactTime: "Evening",
      contactMethod: "Phone call",
      additionalNotes: "Looking for a family-friendly property with garden",
      property: ["4 bed bungalow to rent in New Barn Road, Longfield, DA3 7JE"]
    },
    shouldPass: true,
    description: "Large family with multiple pets and high income"
  },
  {
    name: "Multiple Properties Selection",
    data: {
      fullName: "Emma Thompson",
      email: "emma.thompson@test.com",
      phone: "07700900006",
      adults: 2,
      children: 0,
      moveDate: "ASAP",
      rentalPeriod: "1 year",
      hasPets: false,
      smokes: false,
      occupation: "Employed",
      annualIncome: 55000,
      hasCCJIVA: false,
      hasAdverseMedia: false,
      hasGuarantor: true,
      contactTime: "Morning",
      contactMethod: "Email",
      additionalNotes: "Interested in multiple properties",
      property: [
        "1 bed flat to rent in Portland Avenue, Sittingbourne, Kent, ME10 3QZ",
        "2 bed flat to rent in Russet Walk, Greenhithe, DA9 9WY"
      ]
    },
    shouldPass: true,
    description: "Application with multiple property selections"
  }
];

async function testFormValidation() {
  console.log('🧪 Starting Comprehensive Form Validation Testing');
  console.log('==================================================');
  
  let totalTests = testScenarios.length;
  let passedTests = 0;
  let failedTests = 0;
  const results = [];

  // Test properties endpoint first
  try {
    const propertiesResponse = await axios.get(`${BASE_URL}/api/properties`);
    console.log(`✅ Properties endpoint: ${propertiesResponse.data.length} properties loaded`);
  } catch (error) {
    console.log('❌ Properties endpoint failed:', error.message);
    return;
  }

  console.log('\n📝 Testing form validation scenarios...\n');

  for (const scenario of testScenarios) {
    try {
      const response = await axios.post(`${BASE_URL}/api/applications`, scenario.data);
      
      if (scenario.shouldPass) {
        console.log(`✅ ${scenario.name} - PASSED (Expected success, got success)`);
        passedTests++;
        results.push({
          test: scenario.name,
          status: 'PASSED',
          expected: 'success',
          actual: 'success',
          description: scenario.description
        });
      } else {
        console.log(`❌ ${scenario.name} - FAILED (Expected failure, got success)`);
        failedTests++;
        results.push({
          test: scenario.name,
          status: 'FAILED',
          expected: 'failure',
          actual: 'success',
          description: scenario.description,
          error: 'Should have failed validation but succeeded'
        });
      }
      
    } catch (error) {
      if (!scenario.shouldPass) {
        console.log(`✅ ${scenario.name} - PASSED (Expected failure, got failure)`);
        passedTests++;
        results.push({
          test: scenario.name,
          status: 'PASSED',
          expected: 'failure',
          actual: 'failure',
          description: scenario.description,
          errorMessage: error.response?.data?.message || error.message
        });
      } else {
        console.log(`❌ ${scenario.name} - FAILED (Expected success, got failure: ${error.response?.data?.message || error.message})`);
        failedTests++;
        results.push({
          test: scenario.name,
          status: 'FAILED',
          expected: 'success',
          actual: 'failure',
          description: scenario.description,
          error: error.response?.data?.message || error.message
        });
      }
    }
  }

  // Generate detailed report
  console.log('\n\nFORM VALIDATION TEST REPORT');
  console.log('============================\n');

  console.log('SUMMARY:');
  console.log(`- Total Tests: ${totalTests}`);
  console.log(`- Passed: ${passedTests} (${((passedTests/totalTests)*100).toFixed(1)}%)`);
  console.log(`- Failed: ${failedTests}`);

  if (failedTests > 0) {
    console.log('\n❌ FAILED TESTS:');
    results.filter(r => r.status === 'FAILED').forEach((result, index) => {
      console.log(`${index + 1}. ${result.test}`);
      console.log(`   Description: ${result.description}`);
      console.log(`   Expected: ${result.expected}, Got: ${result.actual}`);
      console.log(`   Error: ${result.error || result.errorMessage || 'Unknown error'}`);
      console.log('');
    });
  }

  console.log('\n✅ VALIDATION COVERAGE:');
  console.log('- Required field validation');
  console.log('- Email format validation');
  console.log('- Numeric input validation');
  console.log('- Pet details conditional fields');
  console.log('- Self-employed tax returns');
  console.log('- Multiple property selection');
  console.log('- Large family scenarios');
  console.log('- Income validation (positive numbers)');

  if (passedTests === totalTests) {
    console.log('\n🎉 ALL FORM VALIDATION TESTS PASSED!');
  } else {
    console.log(`\n⚠️  ${failedTests} tests failed. Review above for details.`);
  }

  // Save detailed results
  fs.writeFileSync('testing/form-validation-report.json', JSON.stringify({
    summary: {
      total: totalTests,
      passed: passedTests,
      failed: failedTests,
      successRate: ((passedTests/totalTests)*100).toFixed(1) + '%'
    },
    results: results,
    timestamp: new Date().toISOString()
  }, null, 2));

  console.log('\n📊 Detailed results saved to testing/form-validation-report.json');
}

// Run the tests
testFormValidation().catch(console.error);