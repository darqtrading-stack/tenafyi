import { Express, Request, Response, NextFunction } from 'express';
import session from 'express-session';
import bcrypt from 'bcrypt';

// User accounts for testing
const USERS = [
  {
    id: 1,
    email: 'admin@tenafyi.com',
    password: '$2b$10$qWakj/zLoiese6kftTMasOzpLj1wX38/ZeZu3N045d.a7.S/XXjAG', // password: "admin123"
    firstName: 'Admin',
    lastName: 'User',
    role: 'admin'
  },
  {
    id: 2,
    email: 'test@tenafyi.com', 
    password: '$2b$10$4X5Y0XW2k8a7g/pX9qcZwOuGQE.5NYGj56z25LDxJ2aJXbXWS5SrG', // password: "test123"
    firstName: 'Test',
    lastName: 'Admin',
    role: 'admin'
  },
  {
    id: 3,
    email: 'developer@tenafyi.com',
    password: '$2b$10$VHNxJ6pTZZ.3o.FvKOJA7OzB2XB1nCNFmF.yXIhJi.FhQT1WJkXEm', // password: "dev123"
    firstName: 'Developer',
    lastName: 'User',
    role: 'developer'
  }
];

declare global {
  namespace Express {
    interface User {
      id: number;
      email: string;
      firstName: string;
      lastName: string;
      role: string;
    }
  }
}

export function setupSimpleAuth(app: Express) {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key-here',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  }));

  // Login endpoint
  app.post('/api/login', async (req: Request, res: Response) => {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password required' });
    }

    try {
      // Find user
      const user = USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Check password
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Set session
      (req.session as any).userId = user.id;
      (req.session as any).user = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      };

      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      });

    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Logout endpoint
  app.post('/api/logout', (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ message: 'Could not log out' });
      }
      res.clearCookie('connect.sid');
      res.json({ message: 'Logged out successfully' });
    });
  });

  // Get current user endpoint
  app.get('/api/auth/user', (req: Request, res: Response) => {
    const sessionUser = (req.session as any)?.user;
    if (!sessionUser) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    res.json(sessionUser);
  });

  // Auth middleware for protected routes
  app.use('/api/admin', (req: Request, res: Response, next: NextFunction) => {
    const sessionUser = (req.session as any)?.user;
    if (!sessionUser) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    req.user = sessionUser;
    next();
  });

  // Developer routes middleware
  app.use('/api/developer', (req: Request, res: Response, next: NextFunction) => {
    const sessionUser = (req.session as any)?.user;
    if (!sessionUser || sessionUser.role !== 'developer') {
      return res.status(401).json({ message: 'Unauthorized - Developer access required' });
    }
    req.user = sessionUser;
    next();
  });

  console.log('Simple email/password authentication configured');
  console.log('Test accounts:');
  console.log('- admin@tenafyi.com / admin123');
  console.log('- test@tenafyi.com / test123');
  console.log('- developer@tenafyi.com / dev123');
}