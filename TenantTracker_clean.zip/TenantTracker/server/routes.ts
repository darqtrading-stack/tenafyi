import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { emailService } from "./services/emailService";
import { aiQueryService } from "./services/aiQueryService";
import { ChatGPTSystemAgent } from "./services/chatGPTAgent";
import { loopService } from "./services/loopService";
import { insertApplicationSchema, updateApplicationStatusSchema, insertNoteSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Note: Auth is now handled by simpleAuth.ts

  // In-memory fallback storage for applications when database is down
  const pendingApplications: Array<InsertApplication & { id: number; createdAt: Date }> = [];
  let applicationIdCounter = 1000;

  // Public application submission
  app.post('/api/applications', async (req, res) => {
    try {
      const validatedData = insertApplicationSchema.parse(req.body);
      
      let application;
      try {
        // Try to save to database
        application = await storage.createApplication(validatedData);
        console.log(`✅ Application saved to database: ${application.id}`);
      } catch (dbError) {
        // Database is down - use in-memory fallback
        console.error("Database unavailable, using in-memory storage for application:", dbError);
        application = {
          ...validatedData,
          id: applicationIdCounter++,
          createdAt: new Date(),
          updatedAt: new Date()
        };
        pendingApplications.push(application);
        console.log(`💾 Application cached in memory: ${application.id} (${pendingApplications.length} pending)`);
      }
      
      // Send confirmation email
      try {
        await emailService.sendApplicationConfirmation(application);
      } catch (emailError) {
        console.error('Failed to send confirmation email:', emailError);
        // Continue even if email fails
      }
      
      res.status(201).json({ 
        message: "Application submitted successfully", 
        id: application.id,
        cached: pendingApplications.some(app => app.id === application.id)
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid application data", errors: error.errors });
      } else {
        console.error("Error creating application:", error);
        res.status(500).json({ message: "Failed to submit application" });
      }
    }
  });

  // Protected admin routes (auth handled by middleware in simpleAuth.ts)
  app.get('/api/admin/applications', async (req: any, res) => {
    try {
      const { search, status, page = '1', limit = '10' } = req.query;
      const offset = (parseInt(page) - 1) * parseInt(limit);
      
      const result = await storage.getApplications({
        search: search as string,
        status: status as string,
        limit: parseInt(limit),
        offset,
      });
      
      res.json({
        applications: result.applications,
        total: result.total,
        page: parseInt(page),
        totalPages: Math.ceil(result.total / parseInt(limit)),
      });
    } catch (error) {
      console.error("Error fetching applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.get('/api/admin/applications/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const application = await storage.getApplication(id);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      res.json(application);
    } catch (error) {
      console.error("Error fetching application:", error);
      res.status(500).json({ message: "Failed to fetch application" });
    }
  });

  app.patch('/api/admin/applications/:id/status', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = updateApplicationStatusSchema.parse(req.body);
      
      const updatedApplication = await storage.updateApplicationStatus(id, validatedData);
      
      if (!updatedApplication) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      res.json(updatedApplication);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid status data", errors: error.errors });
      } else {
        console.error("Error updating application status:", error);
        res.status(500).json({ message: "Failed to update application status" });
      }
    }
  });

  app.post('/api/admin/applications/:id/notes', async (req: any, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const validatedData = insertNoteSchema.parse({
        ...req.body,
        applicationId,
      });
      
      const note = await storage.addNote({
        ...validatedData,
        userId,
      });
      
      res.status(201).json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid note data", errors: error.errors });
      } else {
        console.error("Error adding note:", error);
        res.status(500).json({ message: "Failed to add note" });
      }
    }
  });

  app.get('/api/admin/stats', async (req, res) => {
    try {
      const stats = await storage.getApplicationStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // AI Query endpoint
  app.post('/api/admin/ai-query', async (req: any, res) => {
    try {
      const { query } = req.body;
      const userId = req.user.id;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Query is required" });
      }
      
      const result = await aiQueryService.processQuery(query, userId);
      res.json(result);
    } catch (error) {
      console.error("Error processing AI query:", error);
      res.status(500).json({ message: "Failed to process AI query" });
    }
  });

  // Get suggested AI queries
  app.get('/api/admin/ai-suggestions', async (req, res) => {
    try {
      const { applications } = await storage.getApplications({ limit: 1000 });
      const suggestions = await aiQueryService.generateSuggestedQueries(applications);
      res.json({ suggestions });
    } catch (error) {
      console.error("Error generating suggestions:", error);
      res.status(500).json({ message: "Failed to generate suggestions" });
    }
  });

  // Export applications data
  app.get('/api/admin/applications/export', async (req: any, res) => {
    try {
      const { applications } = await storage.getApplications({ limit: 1000 });
      
      // Convert to CSV format
      const csvHeaders = [
        'ID', 'Name', 'Email', 'Phone', 'Move Date', 'Adults', 'Children', 
        'Rental Period', 'Pets', 'Smoking', 'Occupation', 'Annual Income',
        'CCJ/IVA', 'Guarantor', 'Contact Time', 'Status', 'Applied Date'
      ].join(',');
      
      const csvRows = applications.map(app => [
        app.id,
        `"${app.fullName}"`,
        app.email,
        app.phone,
        app.moveDate,
        app.adults,
        app.children || 0,
        app.rentalPeriod,
        app.hasPets ? 'Yes' : 'No',
        app.smokes ? 'Yes' : 'No',
        app.occupation,
        app.annualIncome,
        app.hasCCJIVA ? 'Yes' : 'No',
        app.hasGuarantor ? 'Yes' : 'No',
        app.contactTime,
        app.status,
        app.createdAt?.toISOString().split('T')[0] || ''
      ].join(','));
      
      const csvContent = [csvHeaders, ...csvRows].join('\n');
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=tenant-applications.csv');
      res.send(csvContent);
    } catch (error) {
      console.error("Error exporting applications:", error);
      res.status(500).json({ message: "Failed to export applications" });
    }
  });

  // Advanced Smart Search Query endpoint
  app.post("/api/admin/search-query", async (req: any, res) => {
    try {
      const { query } = req.body;
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Query text is required" });
      }

      const userId = req.user.id;
      console.log(`🔍 Advanced search from user ${userId}: "${query}"`);
      
      // Use advanced search engine for complex queries with fuzzy matching
      const { advancedSearchEngine } = await import("./services/advancedSearchEngine");
      const result = await advancedSearchEngine.processQuery(query);
      
      console.log(`✅ Advanced search completed: found ${result.totalFound} applications in ${result.executionTime}ms`);
      
      // Return the complete result object with explicit data structure
      const responseData = {
        query: result.query,
        summary: result.summary,
        totalFound: result.totalFound,
        data: result.applications, // Keep 'data' field for frontend compatibility
        applications: result.applications,
        filters: result.filters,
        timestamp: result.timestamp,
        executionTime: result.executionTime,
        queryType: 'advanced',
        debugInfo: result.debugInfo
      };
      
      console.log(`📤 Sending advanced response: ${responseData.totalFound} applications, data array length: ${responseData.data?.length}`);
      res.json(responseData);
      
    } catch (error) {
      console.error("❌ Advanced search query failed:", error);
      res.status(500).json({ 
        message: "Failed to process search query", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Advanced Search Suggestions endpoint
  app.get("/api/admin/search-suggestions", async (req: any, res) => {
    try {
      // Mix of simple and complex example queries
      const suggestions = [
        "Show all new applications",
        "High income applicants (£40k+)",
        "Applicants with pets but no guarantor",
        "Self-employed without tax returns", 
        "Families with children moving ASAP",
        "Top 5 earners under age 35",
        "Anyone earning 40-50k with no kids",
        "Students or unemployed with guarantor",
        "Non-smokers with no CCJ",
        "Single applicants over £50k"
      ];
      res.json({ suggestions });
    } catch (error) {
      console.error("Error generating search suggestions:", error);
      res.status(500).json({ message: "Failed to generate suggestions" });
    }
  });

  // Property listings API with fallback to memory cache
  app.get('/api/properties', async (req, res) => {
    try {
      const { PropertyScrapingService } = await import("./services/propertyScrapingService");
      const propertyService = PropertyScrapingService.getInstance();
      const properties = await propertyService.getPropertiesWithFallback();
      res.json(properties);
    } catch (error) {
      console.error("Error fetching properties:", error);
      // Even if everything fails, try returning empty array to prevent API errors
      res.json([]);
    }
  });

  // Manual property refresh (admin only) - Always clears old data first
  app.post('/api/admin/refresh-properties', async (req, res) => {
    try {
      const { PropertyScrapingService } = await import("./services/propertyScrapingService");
      const propertyService = PropertyScrapingService.getInstance();
      
      console.log('🔄 Manual property refresh initiated by admin (clears old data)');
      const scrapedProperties = await propertyService.scrapeProperties(); // Automatically clears old data
      
      res.json({ 
        message: `Property refresh completed - cleared old data and updated with ${scrapedProperties.length} fresh properties`,
        properties: scrapedProperties.length,
        freshData: true,
        timestamp: new Date().toISOString()
      });
      
      console.log(`✅ Manual refresh completed: ${scrapedProperties.length} fresh properties`);
    } catch (error) {
      console.error('❌ Manual property refresh failed:', error);
      res.status(500).json({ 
        message: 'Failed to refresh properties',
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Test Loop API connection endpoint
  app.get('/api/admin/loop/test', async (req, res) => {
    try {
      const connectionResult = await loopService.testConnection();
      
      if (connectionResult.success) {
        res.json(connectionResult);
      } else {
        res.status(400).json(connectionResult);
      }
    } catch (error) {
      console.error("Error testing Loop connection:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to test Loop connection",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Legacy refresh endpoint for compatibility
  app.post('/api/properties/refresh', async (req, res) => {
    try {
      const { PropertyScrapingService } = await import("./services/propertyScrapingService");
      const propertyService = PropertyScrapingService.getInstance();
      
      console.log('🔄 Legacy refresh endpoint - using fresh data approach');
      const scrapedProperties = await propertyService.scrapeProperties();
      
      res.json({ 
        message: `Properties refreshed with ${scrapedProperties.length} fresh properties (old data cleared)`,
        count: scrapedProperties.length,
        freshData: true,
        source: scrapedProperties.length > 0 && scrapedProperties[0].title.includes('Loop') ? 'loop' : 'webscraping'
      });
    } catch (error) {
      console.error("Error refreshing properties:", error);
      res.status(500).json({ message: "Failed to refresh properties" });
    }
  });

  // System Health Check endpoints
  app.get('/api/admin/health-check/settings', async (req, res) => {
    try {
      const { SystemHealthChecker } = await import('./services/systemHealthChecker');
      const healthChecker = SystemHealthChecker.getInstance();
      const settings = healthChecker.getSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching health check settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.post('/api/admin/health-check/settings', async (req, res) => {
    try {
      const { alertEmail, enabled } = req.body;
      const { SystemHealthChecker } = await import('./services/systemHealthChecker');
      const healthChecker = SystemHealthChecker.getInstance();
      
      await healthChecker.updateSettings({ alertEmail, enabled });
      
      res.json({ 
        message: "Health check settings updated successfully",
        settings: { alertEmail, enabled }
      });
      
      console.log(`✅ Health check settings updated: email=${alertEmail}, enabled=${enabled}`);
    } catch (error) {
      console.error("Error updating health check settings:", error);
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  app.post('/api/admin/health-check/run', async (req, res) => {
    try {
      const { SystemHealthChecker } = await import('./services/systemHealthChecker');
      const healthChecker = SystemHealthChecker.getInstance();
      
      console.log('🔄 Manual health check initiated by admin');
      const result = await healthChecker.runDailyHealthCheck();
      
      res.json({
        message: "Health check completed",
        result: result
      });
      
      console.log(`✅ Manual health check completed: ${result.status}`);
    } catch (error) {
      console.error('❌ Manual health check failed:', error);
      res.status(500).json({ 
        message: 'Failed to run health check',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Developer ChatGPT Agent endpoints
  const chatGPTAgent = ChatGPTSystemAgent.getInstance();

  // System analysis endpoint
  app.post('/api/developer/analyze-system', async (req: any, res) => {
    try {
      // Gather system metrics
      const stats = await storage.getApplicationStats();
      const properties = await storage.getProperties();
      
      const metrics = {
        applications: stats.total,
        properties: properties.length,
        pendingApplications: stats.pending,
        systemHealth: 'operational',
        errors: [], // TODO: Implement error collection
        performance: {
          responseTime: 150, // TODO: Implement actual performance metrics
          uptime: 99.9
        }
      };

      const analysis = await chatGPTAgent.analyzeSystem(metrics);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing system:", error);
      res.status(500).json({ message: "Failed to analyze system" });
    }
  });

  // Improvement suggestions endpoint
  app.post('/api/developer/suggest-improvements', async (req: any, res) => {
    try {
      const { context, specificArea } = req.body;
      
      if (!context) {
        return res.status(400).json({ message: "Context is required" });
      }

      const suggestions = await chatGPTAgent.suggestImprovements(context, specificArea);
      res.json(suggestions);
    } catch (error) {
      console.error("Error getting improvement suggestions:", error);
      res.status(500).json({ message: "Failed to get improvement suggestions" });
    }
  });

  // Code review endpoint
  app.post('/api/developer/review-code', async (req: any, res) => {
    try {
      const { codeSnippet, context } = req.body;
      
      if (!codeSnippet || !context) {
        return res.status(400).json({ message: "Code snippet and context are required" });
      }

      const review = await chatGPTAgent.reviewCode(codeSnippet, context);
      res.json(review);
    } catch (error) {
      console.error("Error reviewing code:", error);
      res.status(500).json({ message: "Failed to review code" });
    }
  });

  // Chat with agent endpoint
  app.post('/api/developer/chat', async (req: any, res) => {
    try {
      const { message, conversationHistory = [] } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await chatGPTAgent.chatWithAgent(message, conversationHistory);
      res.json({ response });
    } catch (error) {
      console.error("Error chatting with agent:", error);
      res.status(500).json({ message: "Failed to chat with agent" });
    }
  });

  // System report endpoint
  app.get('/api/developer/system-report', async (req: any, res) => {
    try {
      const report = await chatGPTAgent.generateSystemReport();
      res.json(report);
    } catch (error) {
      console.error("Error generating system report:", error);
      res.status(500).json({ message: "Failed to generate system report" });
    }
  });

  // === AI TENANT ASSISTANT & SETTINGS ROUTES ===
  
  // Import AI services
  const { settingsService } = await import('./services/settingsService');
  const { aiTenantService } = await import('./services/aiTenantService');
  const { rulesEngine } = await import('./services/rulesEngine');

  // Get public feature toggles (no auth required - for landing page)
  app.get('/api/settings/public', async (req, res) => {
    try {
      const settings = await settingsService.getAllSettings();
      // Only expose feature toggles, not sensitive configuration
      const publicSettings = {
        ai_chatbot_enabled: settings.ai_chatbot_enabled || { enabled: false },
        conversational_bot_enabled: settings.conversational_bot_enabled || { enabled: true },
        traditional_form_enabled: settings.traditional_form_enabled || { enabled: true },
      };
      res.json(publicSettings);
    } catch (error) {
      console.error("Error fetching public settings:", error);
      res.status(500).json({ message: "Failed to fetch public settings" });
    }
  });

  // Get all system settings (admin only)
  app.get('/api/admin/settings', async (req: any, res) => {
    try {
      const settings = await settingsService.getAllSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // Update system setting (admin only)
  app.patch('/api/admin/settings/:key', async (req: any, res) => {
    try {
      const { key } = req.params;
      const { value } = req.body;
      
      if (value === undefined) {
        return res.status(400).json({ message: "Value is required" });
      }

      await settingsService.updateSetting(key, value, req.user?.id);
      console.log(`✅ Setting updated successfully: ${key} =`, value);
      res.json({ message: "Setting updated successfully", key, value });
    } catch (error) {
      console.error("❌ Error updating setting:", error);
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // Get all letting rules (admin only)
  app.get('/api/admin/letting-rules', async (req: any, res) => {
    try {
      const rules = await settingsService.getAllLettingRules();
      res.json(rules);
    } catch (error) {
      console.error("Error fetching letting rules:", error);
      res.status(500).json({ message: "Failed to fetch letting rules" });
    }
  });

  // Update letting rule (admin only)
  app.patch('/api/admin/letting-rules/:name', async (req: any, res) => {
    try {
      const { name } = req.params;
      const { config } = req.body;
      
      if (!config) {
        return res.status(400).json({ message: "Config is required" });
      }

      await settingsService.updateLettingRule(name, config, req.user?.id);
      res.json({ message: "Letting rule updated successfully", name, config });
    } catch (error) {
      console.error("Error updating letting rule:", error);
      res.status(500).json({ message: "Failed to update letting rule" });
    }
  });

  // Create new letting rule (admin only)
  app.post('/api/admin/letting-rules', async (req: any, res) => {
    try {
      const { name, ruleType, config, description } = req.body;
      
      if (!name || !ruleType || !config) {
        return res.status(400).json({ message: "Name, ruleType, and config are required" });
      }

      await settingsService.createLettingRule(name, ruleType, config, description, req.user?.id);
      res.status(201).json({ message: "Letting rule created successfully", name });
    } catch (error) {
      console.error("Error creating letting rule:", error);
      res.status(500).json({ message: "Failed to create letting rule" });
    }
  });

  // Start AI conversation (public)
  app.post('/api/ai-chat/start', async (req, res) => {
    try {
      const { sessionId } = req.body;
      
      if (!sessionId) {
        return res.status(400).json({ message: "Session ID is required" });
      }

      // Check if AI chatbot is enabled
      const isEnabled = await settingsService.isAIChatbotEnabled();
      if (!isEnabled) {
        return res.status(403).json({ message: "AI chatbot is currently disabled" });
      }

      // Get properties
      const { propertyScrapingService } = await import('./services/propertyScrapingService');
      const properties = await propertyScrapingService.getPropertiesWithFallback();

      const welcomeMessage = await aiTenantService.startConversation(sessionId, properties);
      res.json({ message: welcomeMessage });
    } catch (error) {
      console.error("Error starting AI conversation:", error);
      res.status(500).json({ message: "Failed to start conversation" });
    }
  });

  // Send message to AI (public)
  app.post('/api/ai-chat/message', async (req, res) => {
    try {
      const { sessionId, message } = req.body;
      
      if (!sessionId || !message) {
        return res.status(400).json({ message: "Session ID and message are required" });
      }

      const response = await aiTenantService.chat(sessionId, message);
      res.json({ message: response });
    } catch (error: any) {
      console.error("Error processing AI message:", error);
      res.status(500).json({ message: error.message || "Failed to process message" });
    }
  });

  // Get conversation history (admin only)
  app.get('/api/admin/conversations/:sessionId', async (req: any, res) => {
    try {
      const { sessionId } = req.params;
      const conversation = aiTenantService.getConversation(sessionId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  // Calculate income requirement (public - for frontend preview)
  app.post('/api/calculate-income', async (req, res) => {
    try {
      const { monthlyRent, incomeSources } = req.body;
      
      if (!monthlyRent) {
        return res.status(400).json({ message: "Monthly rent is required" });
      }

      const requiredIncome = await rulesEngine.calculateRequiredIncome(monthlyRent);
      
      let qualification = null;
      if (incomeSources && Array.isArray(incomeSources)) {
        qualification = await rulesEngine.checkQualification(monthlyRent, incomeSources);
      }

      res.json({ requiredIncome, qualification });
    } catch (error) {
      console.error("Error calculating income:", error);
      res.status(500).json({ message: "Failed to calculate income requirement" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
