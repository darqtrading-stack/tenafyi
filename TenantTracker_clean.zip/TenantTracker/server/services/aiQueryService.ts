import OpenAI from "openai";
import { storage } from "../storage";
import { fallbackAIService } from "./fallbackAIService";
import type { ApplicationWithNotes } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface AIQueryResult {
  query: string;
  summary: string;
  data: any[];
  queryType: 'list' | 'count' | 'summary' | 'analysis';
  timestamp: Date;
}

export interface QueryLog {
  id?: number;
  query: string;
  result: string;
  userId: string;
  timestamp: Date;
}

export class AIQueryService {
  // Pre-defined smart queries
  static readonly SMART_QUERIES = [
    "Show me all new applications that need review",
    "List applicants with annual income over £40,000",
    "Who has pets and wants to move ASAP?",
    "Show self-employed applicants without tax returns",
    "Which applicants have CCJ/IVA issues?",
    "List all approved applications this week",
    "Show applicants who can provide a guarantor",
    "Find non-smokers with children"
  ];

  async processQuery(query: string, userId: string): Promise<AIQueryResult> {
    try {
      // Get all applications for analysis
      const { applications } = await storage.getApplications({ limit: 1000 });
      
      // Try OpenAI first, fallback to pattern matching
      try {
        // Generate AI response
        const aiResponse = await this.generateAIResponse(query, applications);
        
        // Filter and process data based on AI analysis
        const result = this.processAIResponse(query, aiResponse, applications);
        
        // Log the query (in production, you'd store this in database)
        console.log(`AI Query from ${userId}: ${query}`);
        
        return result;
      } catch (openAIError) {
        console.log('OpenAI API unavailable, using fallback AI service');
        
        // Use fallback pattern matching service
        const result = await fallbackAIService.processQuery(query, applications);
        
        // Log the query
        console.log(`Fallback AI Query from ${userId}: ${query}`);
        
        return result;
      }
    } catch (error) {
      console.error('AI Query Error:', error);
      throw new Error('Failed to process AI query');
    }
  }

  private async generateAIResponse(query: string, applications: ApplicationWithNotes[]): Promise<any> {
    const systemPrompt = `You are an AI assistant for a property rental CRM system. Your job is to analyze tenant application data and respond to natural language queries.

Database Schema:
- fullName: applicant's full name
- email: contact email
- phone: contact phone
- moveDate: 'asap' or 'few-days'
- adults: number of adults over 18
- children: number of children under 18
- rentalPeriod: '6-months', '1-year', or '2-years'
- hasPets: boolean
- smokes: boolean
- occupation: 'employed', 'self-employed', 'unemployed', 'student', 'retired'
- hasTaxReturns: boolean (only for self-employed)
- annualIncome: annual income in GBP
- hasCCJIVA: boolean (County Court Judgments/Individual Voluntary Arrangements)
- hasGuarantor: boolean
- contactTime: 'morning', 'afternoon', 'evening', 'anytime'
- status: 'new', 'contacted', 'viewing-arranged', 'approved', 'rejected'
- createdAt: application date

Available applications: ${applications.length}

Instructions:
1. Analyze the user query and determine what data they need
2. Provide filtering criteria in JSON format
3. Include a human-readable summary
4. Suggest the best way to display results

Respond with JSON in this exact format:
{
  "filters": {
    "field": "value or condition"
  },
  "summary": "Human readable explanation",
  "displayType": "table|list|count|chart",
  "sortBy": "field_name",
  "sortOrder": "asc|desc"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: query }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    return JSON.parse(response.choices[0].message.content);
  }

  private processAIResponse(query: string, aiResponse: any, applications: ApplicationWithNotes[]): AIQueryResult {
    let filteredData = [...applications];
    
    // Apply AI-generated filters
    if (aiResponse.filters) {
      filteredData = this.applyFilters(filteredData, aiResponse.filters);
    }

    // Sort data if specified
    if (aiResponse.sortBy) {
      filteredData = this.sortData(filteredData, aiResponse.sortBy, aiResponse.sortOrder || 'desc');
    }

    // Determine query type
    let queryType: 'list' | 'count' | 'summary' | 'analysis' = 'list';
    if (query.toLowerCase().includes('how many') || query.toLowerCase().includes('count')) {
      queryType = 'count';
    } else if (query.toLowerCase().includes('summary') || query.toLowerCase().includes('analyze')) {
      queryType = 'analysis';
    }

    return {
      query,
      summary: aiResponse.summary || `Found ${filteredData.length} matching applications`,
      data: filteredData,
      queryType,
      timestamp: new Date()
    };
  }

  private applyFilters(data: ApplicationWithNotes[], filters: any): ApplicationWithNotes[] {
    return data.filter(app => {
      for (const [field, condition] of Object.entries(filters)) {
        if (!this.matchesCondition(app, field, condition)) {
          return false;
        }
      }
      return true;
    });
  }

  private matchesCondition(app: ApplicationWithNotes, field: string, condition: any): boolean {
    const value = (app as any)[field];
    
    if (typeof condition === 'object' && condition !== null) {
      // Handle complex conditions like { ">": 40000 }
      if (condition['>']) return Number(value) > Number(condition['>']);
      if (condition['<']) return Number(value) < Number(condition['<']);
      if (condition['>=']) return Number(value) >= Number(condition['>=']);
      if (condition['<=']) return Number(value) <= Number(condition['<=']);
      if (condition['contains']) return String(value).toLowerCase().includes(String(condition['contains']).toLowerCase());
      if (condition['in']) return condition['in'].includes(value);
    }
    
    // Direct equality
    return value === condition;
  }

  private sortData(data: ApplicationWithNotes[], sortBy: string, sortOrder: string): ApplicationWithNotes[] {
    return data.sort((a, b) => {
      const aVal = (a as any)[sortBy];
      const bVal = (b as any)[sortBy];
      
      let comparison = 0;
      if (aVal > bVal) comparison = 1;
      if (aVal < bVal) comparison = -1;
      
      return sortOrder === 'desc' ? -comparison : comparison;
    });
  }

  // Generate suggested queries based on current data
  async generateSuggestedQueries(applications: ApplicationWithNotes[]): Promise<string[]> {
    try {
      // Try to use OpenAI suggestions, fallback to pattern-based
      const stats = {
        total: applications.length,
        newApps: applications.filter(app => app.status === 'new').length,
        highIncome: applications.filter(app => Number(app.annualIncome) > 40000).length,
        withPets: applications.filter(app => app.hasPets).length,
        selfEmployed: applications.filter(app => app.occupation === 'self-employed').length,
      };

      const suggestions = [...AIQueryService.SMART_QUERIES];
      
      // Add dynamic suggestions based on data
      if (stats.newApps > 0) {
        suggestions.unshift(`Show ${stats.newApps} new applications awaiting review`);
      }
      if (stats.highIncome > 0) {
        suggestions.push(`Analyze ${stats.highIncome} high-income applicants (£40k+)`);
      }
      if (stats.withPets > 0) {
        suggestions.push(`List ${stats.withPets} applicants with pets`);
      }

      return suggestions.slice(0, 8); // Return top 8 suggestions
    } catch (error) {
      // Fallback to basic suggestions
      return await fallbackAIService.generateSuggestedQueries(applications);
    }
  }
}

export const aiQueryService = new AIQueryService();