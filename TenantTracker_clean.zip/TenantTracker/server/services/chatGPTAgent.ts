import OpenAI from "openai";

// Integration with OpenAI blueprint - referenced for proper implementation
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface SystemMetrics {
  applications: number;
  properties: number;
  pendingApplications: number;
  systemHealth: string;
  errors: string[];
  performance: {
    responseTime: number;
    uptime: number;
  };
}

interface AgentResponse {
  analysis: string;
  recommendations: string[];
  priority: 'low' | 'medium' | 'high' | 'critical';
  actions: string[];
}

export class ChatGPTSystemAgent {
  private static instance: ChatGPTSystemAgent;

  public static getInstance(): ChatGPTSystemAgent {
    if (!ChatGPTSystemAgent.instance) {
      ChatGPTSystemAgent.instance = new ChatGPTSystemAgent();
    }
    return ChatGPTSystemAgent.instance;
  }

  async analyzeSystem(metrics: SystemMetrics): Promise<AgentResponse> {
    const systemAnalysisPrompt = `
You are a senior software engineer and system administrator analyzing the Tenafyi property management system.

Current System Metrics:
- Applications: ${metrics.applications}
- Properties: ${metrics.properties}  
- Pending Applications: ${metrics.pendingApplications}
- System Health: ${metrics.systemHealth}
- Errors: ${metrics.errors.join(', ') || 'None'}
- Response Time: ${metrics.performance.responseTime}ms
- Uptime: ${metrics.performance.uptime}%

Analyze the system performance, identify potential issues, and provide actionable recommendations for improvement.
Focus on:
1. System reliability and performance
2. User experience optimization
3. Data quality and integrity
4. Security considerations
5. Scalability concerns

Respond in JSON format with:
{
  "analysis": "detailed analysis of current system state",
  "recommendations": ["specific actionable recommendations"],
  "priority": "low|medium|high|critical",
  "actions": ["immediate actions to take"]
}
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an expert system administrator and software architect. Analyze system metrics and provide actionable insights."
          },
          {
            role: "user",
            content: systemAnalysisPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        analysis: result.analysis || 'No analysis available',
        recommendations: result.recommendations || [],
        priority: result.priority || 'low',
        actions: result.actions || []
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('ChatGPT Agent analysis error:', error);
      throw new Error(`System analysis failed: ${errorMessage}`);
    }
  }

  async suggestImprovements(context: string, specificArea?: string): Promise<{
    suggestions: string[];
    implementation: string[];
    impact: string;
  }> {
    const improvementPrompt = `
You are a senior software engineer reviewing the Tenafyi property management system.

Context: ${context}
${specificArea ? `Focus Area: ${specificArea}` : ''}

Based on modern web development best practices, suggest specific improvements for:
- Code quality and architecture
- User experience and interface
- Performance optimization
- Security enhancements
- Feature additions
- Database optimization

Provide practical, implementable suggestions with clear implementation steps.

Respond in JSON format:
{
  "suggestions": ["specific improvement suggestions"],
  "implementation": ["step-by-step implementation guidance"],
  "impact": "expected impact of these improvements"
}
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system", 
            content: "You are a senior software engineer specializing in modern web applications, React, Node.js, and system architecture."
          },
          {
            role: "user",
            content: improvementPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        suggestions: result.suggestions || [],
        implementation: result.implementation || [],
        impact: result.impact || 'Impact analysis unavailable'
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('ChatGPT Agent improvement suggestions error:', error);
      throw new Error(`Improvement suggestions failed: ${errorMessage}`);
    }
  }

  async reviewCode(codeSnippet: string, context: string): Promise<{
    review: string;
    issues: string[];
    improvements: string[];
    rating: number;
  }> {
    const codeReviewPrompt = `
Review the following code from the Tenafyi property management system:

Context: ${context}

Code:
\`\`\`
${codeSnippet}
\`\`\`

Provide a thorough code review focusing on:
- Code quality and best practices
- Security vulnerabilities
- Performance considerations
- Maintainability and readability
- TypeScript/JavaScript specific issues
- React/Node.js best practices

Rate the code quality from 1-10 and provide specific improvement suggestions.

Respond in JSON format:
{
  "review": "comprehensive code review",
  "issues": ["specific issues found"],
  "improvements": ["specific improvement suggestions"],
  "rating": numerical_rating_1_to_10
}
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a senior software engineer and code reviewer with expertise in TypeScript, React, Node.js, and modern web development."
          },
          {
            role: "user", 
            content: codeReviewPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        review: result.review || 'No review available',
        issues: result.issues || [],
        improvements: result.improvements || [],
        rating: Math.max(1, Math.min(10, result.rating || 5))
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('ChatGPT Agent code review error:', error);
      throw new Error(`Code review failed: ${errorMessage}`);
    }
  }

  async chatWithAgent(message: string, conversationHistory: Array<{role: string, content: string}>): Promise<string> {
    const systemContext = `
You are a senior software engineer and DevOps specialist working on the Tenafyi property management system.

The system includes:
- Tenant application forms with conversational interface
- Admin dashboard for managing applications
- Property scraping and management
- Real-time search and AI-powered queries
- PostgreSQL database with Drizzle ORM
- React frontend with TypeScript
- Node.js/Express backend

You can help with:
- System architecture and design decisions
- Code review and improvement suggestions
- Performance optimization
- Security best practices
- Feature development guidance
- Debugging and troubleshooting
- Database optimization
- Deployment and DevOps

Provide practical, actionable advice based on modern web development best practices.
`;

    try {
      const messages = [
        { role: "system" as const, content: systemContext },
        ...conversationHistory.map(msg => ({ 
          role: msg.role as "system" | "user" | "assistant", 
          content: msg.content 
        })),
        { role: "user" as const, content: message }
      ];

      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: messages,
        temperature: 0.7,
        max_tokens: 1000
      });

      return response.choices[0].message.content || 'No response generated';
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('ChatGPT Agent chat error:', error);
      throw new Error(`Agent chat failed: ${errorMessage}`);
    }
  }

  async generateSystemReport(): Promise<{
    summary: string;
    healthScore: number;
    criticalIssues: string[];
    quickWins: string[];
    longTermGoals: string[];
  }> {
    const reportPrompt = `
Generate a comprehensive system health report for the Tenafyi property management system.

Consider the system's current architecture:
- React frontend with TypeScript
- Node.js/Express backend  
- PostgreSQL database with Drizzle ORM
- Property scraping service
- Admin dashboard
- Tenant application system
- Authentication system

Provide:
1. Overall system health summary
2. Health score (1-100)
3. Critical issues requiring immediate attention
4. Quick wins for immediate improvement
5. Long-term strategic goals

Focus on practical, actionable insights.

Respond in JSON format:
{
  "summary": "executive summary of system health",
  "healthScore": numerical_score_1_to_100,
  "criticalIssues": ["urgent issues to address"],
  "quickWins": ["easy improvements with high impact"],
  "longTermGoals": ["strategic improvements for the future"]
}
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a CTO and senior architect conducting a comprehensive system health assessment."
          },
          {
            role: "user",
            content: reportPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        summary: result.summary || 'System assessment unavailable',
        healthScore: Math.max(1, Math.min(100, result.healthScore || 75)),
        criticalIssues: result.criticalIssues || [],
        quickWins: result.quickWins || [],
        longTermGoals: result.longTermGoals || []
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('ChatGPT Agent system report error:', error);
      throw new Error(`System report generation failed: ${errorMessage}`);
    }
  }
}