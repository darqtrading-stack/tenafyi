import { db } from "../db";
import { applications, propertyListings } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import nodemailer from 'nodemailer';

interface HealthCheckResult {
  timestamp: Date;
  status: 'healthy' | 'warning' | 'critical';
  tests: TestResult[];
  summary: string;
  errors: string[];
  warnings: string[];
}

interface TestResult {
  name: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
  duration: number;
  details?: any;
}

interface SystemSettings {
  alertEmail?: string;
  enabled: boolean;
}

export class SystemHealthChecker {
  private static instance: SystemHealthChecker;
  private settings: SystemSettings = { enabled: true };
  private isRunning = false;

  public static getInstance(): SystemHealthChecker {
    if (!SystemHealthChecker.instance) {
      SystemHealthChecker.instance = new SystemHealthChecker();
    }
    return SystemHealthChecker.instance;
  }

  public async updateSettings(settings: Partial<SystemSettings>): Promise<void> {
    this.settings = { ...this.settings, ...settings };
    console.log(`🔧 System health checker settings updated:`, this.settings);
  }

  public async runDailyHealthCheck(): Promise<HealthCheckResult> {
    if (this.isRunning) {
      console.log("Health check already running, skipping...");
      throw new Error("Health check already in progress");
    }

    this.isRunning = true;
    const startTime = Date.now();
    console.log(`🏥 Starting daily system health check at ${new Date().toLocaleString()}`);

    const tests: TestResult[] = [];
    const errors: string[] = [];
    const warnings: string[] = [];

    try {
      // Test 1: Database connectivity
      await this.testDatabaseConnectivity(tests, errors);

      // Test 2: Property scraping service
      await this.testPropertyScrapingService(tests, errors, warnings);

      // Test 2.1: Property data quality validation
      await this.testPropertyDataQuality(tests, errors, warnings);

      // Test 3: Application submission flow
      await this.testApplicationSubmissionFlow(tests, errors, warnings);

      // Test 4: Search functionality
      await this.testSearchFunctionality(tests, errors, warnings);

      // Test 5: Email service
      await this.testEmailService(tests, errors, warnings);

      // Test 6: API endpoints
      await this.testAPIEndpoints(tests, errors, warnings);

      const totalDuration = Date.now() - startTime;
      const failedTests = tests.filter(t => t.status === 'fail').length;
      const warningTests = tests.filter(t => t.status === 'warning').length;

      let status: 'healthy' | 'warning' | 'critical';
      let summary: string;

      if (failedTests > 0) {
        status = 'critical';
        summary = `System health check FAILED: ${failedTests} critical issues found`;
      } else if (warningTests > 0) {
        status = 'warning';
        summary = `System health check completed with ${warningTests} warnings`;
      } else {
        status = 'healthy';
        summary = `System health check PASSED: All systems operational`;
      }

      const result: HealthCheckResult = {
        timestamp: new Date(),
        status,
        tests,
        summary,
        errors,
        warnings
      };

      console.log(`✅ Health check completed in ${totalDuration}ms: ${summary}`);

      // Send email report if configured
      if (this.settings.alertEmail && (status === 'critical' || status === 'warning')) {
        await this.sendHealthReport(result);
      }

      return result;

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error("❌ Health check failed with error:", error);
      
      const result: HealthCheckResult = {
        timestamp: new Date(),
        status: 'critical',
        tests,
        summary: `Health check failed: ${errorMessage}`,
        errors: [errorMessage, ...errors],
        warnings
      };

      if (this.settings.alertEmail) {
        await this.sendHealthReport(result);
      }

      return result;
    } finally {
      this.isRunning = false;
    }
  }

  private async testDatabaseConnectivity(tests: TestResult[], errors: string[]): Promise<void> {
    const testStart = Date.now();
    
    try {
      // Test basic connectivity
      const applicationCount = await db.select().from(applications).limit(1);
      const propertyCount = await db.select().from(propertyListings).limit(1);

      tests.push({
        name: "Database Connectivity",
        status: 'pass',
        message: "Database connection successful",
        duration: Date.now() - testStart,
        details: {
          applicationsTable: 'accessible',
          propertiesTable: 'accessible'
        }
      });

    } catch (error) {
      const errorMsg = `Database connectivity failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "Database Connectivity",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async testPropertyScrapingService(tests: TestResult[], errors: string[], warnings: string[]): Promise<void> {
    const testStart = Date.now();

    try {
      const { PropertyScrapingService } = await import('./propertyScrapingService');
      const scrapingService = PropertyScrapingService.getInstance();
      
      // Test property fetching
      const properties = await db.select().from(propertyListings).limit(10);
      
      if (properties.length === 0) {
        const warningMsg = "No properties found in database - may need refresh";
        warnings.push(warningMsg);
        tests.push({
          name: "Property Scraping Service",
          status: 'warning',
          message: warningMsg,
          duration: Date.now() - testStart,
          details: { propertyCount: 0 }
        });
      } else {
        tests.push({
          name: "Property Scraping Service",
          status: 'pass',
          message: `Property service operational with ${properties.length} properties`,
          duration: Date.now() - testStart,
          details: { propertyCount: properties.length }
        });
      }

    } catch (error) {
      const errorMsg = `Property scraping service failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "Property Scraping Service",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async testPropertyDataQuality(tests: TestResult[], errors: string[], warnings: string[]): Promise<void> {
    const testStart = Date.now();

    try {
      // Get all properties for quality analysis
      const properties = await db.select().from(propertyListings);
      
      if (properties.length === 0) {
        tests.push({
          name: "Property Data Quality",
          status: 'warning',
          message: "No properties available for quality analysis",
          duration: Date.now() - testStart
        });
        return;
      }

      const qualityIssues: string[] = [];
      const autoFixApplied: string[] = [];
      let needsRefresh = false;

      // Check for duplicate titles with different data
      const titleGroups = properties.reduce((acc, prop) => {
        if (!acc[prop.title]) acc[prop.title] = [];
        acc[prop.title].push(prop);
        return acc;
      }, {} as Record<string, typeof properties>);

      const duplicateTitles = Object.entries(titleGroups).filter(([title, props]) => props.length > 1);
      
      if (duplicateTitles.length > 0) {
        qualityIssues.push(`Found ${duplicateTitles.length} duplicate property titles`);
        needsRefresh = true;
      }

      // Check for mismatched title-price combinations
      const titlePriceMismatches = duplicateTitles.filter(([title, props]) => {
        const prices = Array.from(new Set(props.map(p => p.price)));
        return prices.length > 1;
      });

      if (titlePriceMismatches.length > 0) {
        qualityIssues.push(`Found ${titlePriceMismatches.length} properties with same title but different prices`);
        needsRefresh = true;
      }

      // Check for invalid URLs
      const invalidUrls = properties.filter(p => !p.url.includes('jtpropertyconsultants.co.uk/property/'));
      if (invalidUrls.length > 0) {
        qualityIssues.push(`Found ${invalidUrls.length} properties with invalid URLs`);
        needsRefresh = true;
      }

      // Check for suspicious bed info (all properties having same bed count)
      const bedCounts = Array.from(new Set(properties.map(p => p.beds)));
      if (bedCounts.length === 1 && properties.length > 3) {
        qualityIssues.push(`All properties have identical bed info: ${bedCounts[0]} - likely parsing error`);
        needsRefresh = true;
      }

      // Check for price formatting issues
      const priceFormatIssues = properties.filter(p => 
        !p.price.match(/^£[\d,]+\s*per\s*month$/i) || p.price.includes(',,') || p.price.includes('  ')
      );
      if (priceFormatIssues.length > 0) {
        qualityIssues.push(`Found ${priceFormatIssues.length} properties with malformed prices`);
        needsRefresh = true;
      }

      // Auto-fix: Trigger property refresh if major issues detected
      if (needsRefresh && qualityIssues.length >= 2) {
        console.log(`🚨 Property data quality issues detected, triggering auto-refresh...`);
        try {
          const { PropertyScrapingService } = await import('./propertyScrapingService');
          const scrapingService = PropertyScrapingService.getInstance();
          await scrapingService.scrapeProperties();
          autoFixApplied.push("Property refresh completed to fix data quality issues");
        } catch (refreshError) {
          qualityIssues.push(`Auto-refresh failed: ${refreshError instanceof Error ? refreshError.message : String(refreshError)}`);
        }
      }

      // Check freshness - properties older than 12 hours
      const twelveHoursAgo = new Date(Date.now() - 12 * 60 * 60 * 1000);
      const staleProperties = properties.filter(p => p.scrapedAt && p.scrapedAt < twelveHoursAgo);
      if (staleProperties.length > 0) {
        warnings.push(`${staleProperties.length} properties are more than 12 hours old`);
      }

      // Determine test result
      if (qualityIssues.length === 0) {
        tests.push({
          name: "Property Data Quality",
          status: 'pass',
          message: `Property data quality excellent - ${properties.length} properties validated`,
          duration: Date.now() - testStart,
          details: {
            totalProperties: properties.length,
            uniqueTitles: Object.keys(titleGroups).length,
            qualityScore: 'A+'
          }
        });
      } else if (autoFixApplied.length > 0) {
        tests.push({
          name: "Property Data Quality",
          status: 'warning',
          message: `Property data issues detected and auto-fixed: ${qualityIssues.join(', ')}`,
          duration: Date.now() - testStart,
          details: {
            issuesFound: qualityIssues,
            autoFixesApplied: autoFixApplied,
            totalProperties: properties.length
          }
        });
        warnings.push(...qualityIssues);
      } else {
        tests.push({
          name: "Property Data Quality",
          status: 'fail',
          message: `Property data quality issues detected: ${qualityIssues.join(', ')}`,
          duration: Date.now() - testStart,
          details: {
            issuesFound: qualityIssues,
            totalProperties: properties.length,
            recommendedAction: 'Manual property refresh required'
          }
        });
        errors.push(...qualityIssues);
      }

    } catch (error) {
      const errorMsg = `Property data quality check failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "Property Data Quality",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async testApplicationSubmissionFlow(tests: TestResult[], errors: string[], warnings: string[]): Promise<void> {
    const testStart = Date.now();

    try {
      // Create a test application
      const testApplication = {
        fullName: `Health Check Test - ${new Date().toISOString()}`,
        email: `healthcheck-${Date.now()}@test.com`,
        phone: "+447700123456",
        moveDate: "ASAP",
        adults: 1,
        children: 0,
        rentalPeriod: "12+ months",
        hasPets: false,
        petDetails: null,
        smokes: false,
        occupation: "Software Engineer",
        annualIncome: "45000",
        hasCCJIVA: false,
        hasGuarantor: true,
        contactTime: "Any time",
        property: ["Test Property"],
        status: "pending" as const
      };

      // Insert test application
      const insertedApplication = await db.insert(applications).values([testApplication]).returning();

      if (insertedApplication.length > 0) {
        tests.push({
          name: "Application Submission Flow",
          status: 'pass',
          message: "Application submission working correctly",
          duration: Date.now() - testStart,
          details: {
            testApplicationId: insertedApplication[0].id,
            submissionSuccessful: true
          }
        });

        // Clean up test application after 1 minute
        setTimeout(async () => {
          try {
            await db.delete(applications).where(eq(applications.id, insertedApplication[0].id));
            console.log(`🧹 Cleaned up test application ${insertedApplication[0].id}`);
          } catch (cleanupError) {
            console.error("Failed to cleanup test application:", cleanupError);
          }
        }, 60000);

      } else {
        const errorMsg = "Application submission failed - no record created";
        errors.push(errorMsg);
        tests.push({
          name: "Application Submission Flow",
          status: 'fail',
          message: errorMsg,
          duration: Date.now() - testStart
        });
      }

    } catch (error) {
      const errorMsg = `Application submission flow failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "Application Submission Flow",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async testSearchFunctionality(tests: TestResult[], errors: string[], warnings: string[]): Promise<void> {
    const testStart = Date.now();

    try {
      // Test basic application search
      const recentApplications = await db.select()
        .from(applications)
        .orderBy(desc(applications.createdAt))
        .limit(5);

      tests.push({
        name: "Search Functionality",
        status: 'pass',
        message: "Search functionality operational",
        duration: Date.now() - testStart,
        details: {
          recentApplicationsFound: recentApplications.length
        }
      });

    } catch (error) {
      const errorMsg = `Search functionality failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "Search Functionality",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async testEmailService(tests: TestResult[], errors: string[], warnings: string[]): Promise<void> {
    const testStart = Date.now();

    try {
      // Test email configuration (don't actually send)  
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      // Just verify the connection without sending
      if (process.env.SMTP_USER) {
        await transporter.verify();
        tests.push({
          name: "Email Service",
          status: 'pass',
          message: "Email service configuration valid",
          duration: Date.now() - testStart
        });
      } else {
        const warningMsg = "Email service not configured - SMTP credentials missing";
        warnings.push(warningMsg);
        tests.push({
          name: "Email Service",
          status: 'warning',
          message: warningMsg,
          duration: Date.now() - testStart
        });
      }

    } catch (error) {
      const errorMsg = `Email service test failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "Email Service",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async testAPIEndpoints(tests: TestResult[], errors: string[], warnings: string[]): Promise<void> {
    const testStart = Date.now();

    try {
      // Test key API endpoints
      const endpoints = [
        '/api/properties',
        '/api/applications'
      ];

      let successCount = 0;

      for (const endpoint of endpoints) {
        try {
          const response = await fetch(`http://localhost:5000${endpoint}`);
          if (response.ok) {
            successCount++;
          }
        } catch (endpointError) {
          const errorMsg = endpointError instanceof Error ? endpointError.message : String(endpointError);
          warnings.push(`API endpoint ${endpoint} test failed: ${errorMsg}`);
        }
      }

      if (successCount === endpoints.length) {
        tests.push({
          name: "API Endpoints",
          status: 'pass',
          message: `All ${endpoints.length} API endpoints responding`,
          duration: Date.now() - testStart,
          details: {
            testedEndpoints: endpoints,
            successfulEndpoints: successCount
          }
        });
      } else {
        const warningMsg = `${successCount}/${endpoints.length} API endpoints responding`;
        warnings.push(warningMsg);
        tests.push({
          name: "API Endpoints",
          status: 'warning',
          message: warningMsg,
          duration: Date.now() - testStart
        });
      }

    } catch (error) {
      const errorMsg = `API endpoints test failed: ${error instanceof Error ? error.message : String(error)}`;
      errors.push(errorMsg);
      tests.push({
        name: "API Endpoints",
        status: 'fail',
        message: errorMsg,
        duration: Date.now() - testStart
      });
    }
  }

  private async sendHealthReport(result: HealthCheckResult): Promise<void> {
    if (!this.settings.alertEmail) {
      console.log("No alert email configured, skipping report");
      return;
    }

    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      const subject = `Tenafyi System Health Report - ${result.status.toUpperCase()}`;
      const htmlContent = this.generateHealthReportHTML(result);

      await transporter.sendMail({
        from: process.env.SMTP_USER,
        to: this.settings.alertEmail,
        subject,
        html: htmlContent
      });

      console.log(`✅ Health report sent to ${this.settings.alertEmail}`);

    } catch (error) {
      console.error("❌ Failed to send health report:", error instanceof Error ? error.message : String(error));
    }
  }

  private generateHealthReportHTML(result: HealthCheckResult): string {
    const statusColor = result.status === 'healthy' ? '#22c55e' : 
                       result.status === 'warning' ? '#f59e0b' : '#ef4444';

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Tenafyi System Health Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
          .container { max-width: 800px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .header { background-color: ${statusColor}; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; }
          .test-result { margin: 15px 0; padding: 15px; border-radius: 6px; border-left: 4px solid #e5e5e5; }
          .test-pass { border-left-color: #22c55e; background-color: #f0fdf4; }
          .test-warning { border-left-color: #f59e0b; background-color: #fffbeb; }
          .test-fail { border-left-color: #ef4444; background-color: #fef2f2; }
          .summary { background-color: #f8fafc; padding: 15px; border-radius: 6px; margin: 20px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Tenafyi System Health Report</h1>
            <p>${result.summary}</p>
            <p><small>Generated on ${result.timestamp.toLocaleString()}</small></p>
          </div>
          
          <div class="content">
            <div class="summary">
              <h3>Summary</h3>
              <p><strong>Status:</strong> ${result.status.toUpperCase()}</p>
              <p><strong>Tests Run:</strong> ${result.tests.length}</p>
              <p><strong>Passed:</strong> ${result.tests.filter(t => t.status === 'pass').length}</p>
              <p><strong>Warnings:</strong> ${result.tests.filter(t => t.status === 'warning').length}</p>
              <p><strong>Failed:</strong> ${result.tests.filter(t => t.status === 'fail').length}</p>
            </div>

            <h3>Test Results</h3>
            ${result.tests.map(test => `
              <div class="test-result test-${test.status}">
                <h4>${test.name} - ${test.status.toUpperCase()}</h4>
                <p>${test.message}</p>
                <p><small>Duration: ${test.duration}ms</small></p>
              </div>
            `).join('')}

            ${result.errors.length > 0 ? `
              <h3>Critical Errors</h3>
              <ul>
                ${result.errors.map(error => `<li style="color: #ef4444;">${error}</li>`).join('')}
              </ul>
            ` : ''}

            ${result.warnings.length > 0 ? `
              <h3>Warnings</h3>
              <ul>
                ${result.warnings.map(warning => `<li style="color: #f59e0b;">${warning}</li>`).join('')}
              </ul>
            ` : ''}
          </div>

          <div class="footer">
            <p>This report was automatically generated by the Tenafyi System Health Checker.</p>
            <p>If you have concerns about these results, please check the system logs or contact your administrator.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  public startScheduledHealthChecks(): void {
    console.log("🏥 Starting scheduled health check service...");
    
    const scheduleNextCheck = () => {
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0); // 12:00 AM

      const msUntilNext = tomorrow.getTime() - now.getTime();
      
      console.log(`Next health check scheduled for: ${tomorrow.toLocaleString()}`);
      
      setTimeout(async () => {
        if (this.settings.enabled) {
          console.log("🕐 Executing scheduled system health check...");
          try {
            await this.runDailyHealthCheck();
          } catch (error) {
            console.error("❌ Scheduled health check failed:", error instanceof Error ? error.message : String(error));
          }
        }
        scheduleNextCheck(); // Schedule the next one
      }, msUntilNext);
    };

    scheduleNextCheck();
  }

  public getSettings(): SystemSettings {
    return this.settings;
  }
}