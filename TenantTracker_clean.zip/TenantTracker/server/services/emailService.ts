import nodemailer from 'nodemailer';
import type { Application } from '@shared/schema';

// Email service for sending notifications
export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    // Configure email transporter (using environment variables)
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER || process.env.EMAIL_USER || 'noreply@propertycrm.com',
        pass: process.env.SMTP_PASS || process.env.EMAIL_PASS || 'defaultpass',
      },
    });
  }

  // Send application confirmation email
  async sendApplicationConfirmation(application: Application): Promise<void> {
    const emailContent = this.generateConfirmationEmail(application);
    
    try {
      await this.transporter.sendMail({
        from: process.env.FROM_EMAIL || 'noreply@propertycrm.com',
        to: application.email,
        subject: 'Tenant Application Received - PropertyCRM',
        html: emailContent,
      });
    } catch (error) {
      console.error('Failed to send confirmation email:', error);
      throw new Error('Failed to send confirmation email');
    }
  }

  // Send viewing reminder email
  async sendViewingReminder(application: Application, viewingDate: Date): Promise<void> {
    const emailContent = this.generateViewingReminderEmail(application, viewingDate);
    
    try {
      await this.transporter.sendMail({
        from: process.env.FROM_EMAIL || 'noreply@propertycrm.com',
        to: application.email,
        subject: 'Property Viewing Reminder - PropertyCRM',
        html: emailContent,
      });
    } catch (error) {
      console.error('Failed to send viewing reminder:', error);
      throw new Error('Failed to send viewing reminder');
    }
  }

  // Generate confirmation email HTML
  private generateConfirmationEmail(application: Application): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Application Confirmation</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .details { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
          .footer { text-align: center; padding: 20px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Application Received</h1>
          </div>
          <div class="content">
            <p>Dear ${application.fullName},</p>
            <p>Thank you for submitting your tenant application. We have received your application and will review it shortly.</p>
            
            <div class="details">
              <h3>Application Summary:</h3>
              <p><strong>Name:</strong> ${application.fullName}</p>
              <p><strong>Email:</strong> ${application.email}</p>
              <p><strong>Phone:</strong> ${application.phone}</p>
              <p><strong>Preferred Move Date:</strong> ${application.moveDate === 'asap' ? 'ASAP' : 'In the next few days'}</p>
              <p><strong>Household Size:</strong> ${application.adults} adult(s), ${application.children || 0} child(ren)</p>
              <p><strong>Annual Income:</strong> £${application.annualIncome}</p>
            </div>
            
            <p>We will contact you within 24-48 hours to discuss the next steps. If you have any questions, please don't hesitate to reach out.</p>
            
            <p>Best regards,<br>PropertyCRM Team</p>
          </div>
          <div class="footer">
            <p>&copy; 2025 PropertyCRM. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  // Generate viewing reminder email HTML
  private generateViewingReminderEmail(application: Application, viewingDate: Date): string {
    const formattedDate = viewingDate.toLocaleDateString('en-GB', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Property Viewing Reminder</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #059669; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .viewing-details { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #059669; }
          .footer { text-align: center; padding: 20px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Property Viewing Reminder</h1>
          </div>
          <div class="content">
            <p>Dear ${application.fullName},</p>
            <p>This is a reminder about your upcoming property viewing.</p>
            
            <div class="viewing-details">
              <h3>Viewing Details:</h3>
              <p><strong>Date & Time:</strong> ${formattedDate}</p>
              <p><strong>Contact:</strong> ${application.phone}</p>
            </div>
            
            <p>Please arrive on time and bring a form of ID. If you need to reschedule or have any questions, please contact us as soon as possible.</p>
            
            <p>We look forward to seeing you!</p>
            
            <p>Best regards,<br>PropertyCRM Team</p>
          </div>
          <div class="footer">
            <p>&copy; 2025 PropertyCRM. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }
}

export const emailService = new EmailService();
