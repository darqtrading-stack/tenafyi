import { SystemSetting, LettingRule, InsertSystemSetting, InsertLettingRule } from "@shared/schema";

// Default settings and rules
const DEFAULT_SETTINGS: Record<string, any> = {
  ai_chatbot_enabled: { enabled: false },
  traditional_form_enabled: { enabled: true },
  conversational_bot_enabled: { enabled: true },
};

const DEFAULT_LETTING_RULES: Record<string, any> = {
  income_multiplier: {
    type: 'calculation',
    multiplier: 30, // Rent × 30 = required annual income
    description: 'Calculate required annual income based on monthly rent',
  },
  self_employed_tax_returns: {
    type: 'requirement',
    yearsRequired: 2,
    useProfitNotTurnover: true,
    description: 'Self-employed applicants must provide profit from tax returns',
  },
  benefits_acceptance: {
    type: 'policy',
    acceptBenefits: true,
    benefitsCountAsIncome: true,
    description: 'Benefits are accepted and count towards income requirements',
  },
  guarantor_threshold: {
    type: 'calculation',
    multiplier: 36, // Guarantor needs to earn rent × 36 annually
    description: 'Required annual income for guarantor based on monthly rent',
  },
};

export class SettingsService {
  private static instance: SettingsService;
  private settings: Map<string, any> = new Map();
  private lettingRules: Map<string, any> = new Map();

  private constructor() {
    // Initialize with defaults
    Object.entries(DEFAULT_SETTINGS).forEach(([key, value]) => {
      this.settings.set(key, value);
    });
    Object.entries(DEFAULT_LETTING_RULES).forEach(([key, value]) => {
      this.lettingRules.set(key, value);
    });
  }

  public static getInstance(): SettingsService {
    if (!SettingsService.instance) {
      SettingsService.instance = new SettingsService();
    }
    return SettingsService.instance;
  }

  // System Settings Methods
  async getSetting(key: string): Promise<any | null> {
    return this.settings.get(key) || null;
  }

  async getAllSettings(): Promise<Record<string, any>> {
    return Object.fromEntries(this.settings);
  }

  async updateSetting(key: string, value: any, userId?: string): Promise<void> {
    this.settings.set(key, value);
    console.log(`⚙️  Setting updated: ${key}`, value);
  }

  // Letting Rules Methods
  async getLettingRule(name: string): Promise<any | null> {
    return this.lettingRules.get(name) || null;
  }

  async getAllLettingRules(): Promise<Record<string, any>> {
    return Object.fromEntries(this.lettingRules);
  }

  async updateLettingRule(name: string, config: any, userId?: string): Promise<void> {
    const existing = this.lettingRules.get(name) || {};
    this.lettingRules.set(name, { ...existing, ...config });
    console.log(`📏 Letting rule updated: ${name}`, config);
  }

  async createLettingRule(name: string, ruleType: string, config: any, description?: string, userId?: string): Promise<void> {
    this.lettingRules.set(name, {
      type: ruleType,
      ...config,
      description: description || '',
    });
    console.log(`📏 Letting rule created: ${name}`, config);
  }

  async deleteLettingRule(name: string): Promise<void> {
    this.lettingRules.delete(name);
    console.log(`🗑️  Letting rule deleted: ${name}`);
  }

  // Helper method to check if AI chatbot is enabled
  async isAIChatbotEnabled(): Promise<boolean> {
    const setting = await this.getSetting('ai_chatbot_enabled');
    return setting?.enabled || false;
  }

  // Helper method to check if traditional form is enabled
  async isTraditionalFormEnabled(): Promise<boolean> {
    const setting = await this.getSetting('traditional_form_enabled');
    return setting?.enabled !== false; // Default to true
  }

  // Helper method to get income multiplier
  async getIncomeMultiplier(): Promise<number> {
    const rule = await this.getLettingRule('income_multiplier');
    return rule?.multiplier || 30;
  }
}

export const settingsService = SettingsService.getInstance();
