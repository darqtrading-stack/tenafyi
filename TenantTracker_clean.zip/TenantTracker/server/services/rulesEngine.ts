import { settingsService } from './settingsService';

export interface IncomeSource {
  type: 'employment' | 'self-employed' | 'benefits' | 'other';
  amount: number; // Annual amount
  description?: string;
  taxReturnProfit?: number; // For self-employed
  hasTaxReturns?: boolean; // For self-employed
}

export interface QualificationResult {
  qualifies: boolean;
  requiredIncome: number;
  totalIncome: number;
  shortfall: number;
  needsGuarantor: boolean;
  messages: string[];
  warnings: string[];
}

export class RulesEngine {
  private static instance: RulesEngine;

  private constructor() {}

  public static getInstance(): RulesEngine {
    if (!RulesEngine.instance) {
      RulesEngine.instance = new RulesEngine();
    }
    return RulesEngine.instance;
  }

  /**
   * Calculate required annual income based on monthly rent
   */
  async calculateRequiredIncome(monthlyRent: number): Promise<number> {
    const multiplier = await settingsService.getIncomeMultiplier();
    return monthlyRent * multiplier;
  }

  /**
   * Calculate required annual income for guarantor based on monthly rent
   */
  async calculateGuarantorRequiredIncome(monthlyRent: number): Promise<number> {
    const guarantorRule = await settingsService.getLettingRule('guarantor_threshold');
    const multiplier = guarantorRule?.multiplier || 36;
    return monthlyRent * multiplier;
  }

  /**
   * Validate and calculate total income from multiple sources
   */
  async calculateTotalIncome(incomeSources: IncomeSource[]): Promise<{
    total: number;
    breakdown: Record<string, number>;
    warnings: string[];
  }> {
    const warnings: string[] = [];
    const breakdown: Record<string, number> = {
      employment: 0,
      selfEmployed: 0,
      benefits: 0,
      other: 0,
    };

    for (const source of incomeSources) {
      if (source.type === 'self-employed') {
        // Get self-employed rules
        const selfEmployedRule = await settingsService.getLettingRule('self_employed_tax_returns');
        
        if (selfEmployedRule?.useProfitNotTurnover && source.taxReturnProfit !== undefined) {
          // Use profit, not turnover
          breakdown.selfEmployed += source.taxReturnProfit;
          
          if (!source.hasTaxReturns) {
            warnings.push(
              `Self-employed income of £${source.taxReturnProfit.toLocaleString()} requires ${selfEmployedRule.yearsRequired || 2} years of tax returns for verification.`
            );
          }
        } else {
          breakdown.selfEmployed += source.amount;
        }
      } else if (source.type === 'benefits') {
        // Check if benefits are accepted
        const benefitsRule = await settingsService.getLettingRule('benefits_acceptance');
        
        if (benefitsRule?.acceptBenefits && benefitsRule?.benefitsCountAsIncome) {
          breakdown.benefits += source.amount;
        } else {
          warnings.push('Benefits income may not be accepted for this property.');
        }
      } else if (source.type === 'employment') {
        breakdown.employment += source.amount;
      } else {
        breakdown.other += source.amount;
      }
    }

    const total = Object.values(breakdown).reduce((sum, val) => sum + val, 0);

    return { total, breakdown, warnings };
  }

  /**
   * Check if applicant qualifies for the property
   */
  async checkQualification(
    monthlyRent: number,
    incomeSources: IncomeSource[]
  ): Promise<QualificationResult> {
    const requiredIncome = await this.calculateRequiredIncome(monthlyRent);
    const { total: totalIncome, breakdown, warnings } = await this.calculateTotalIncome(incomeSources);
    
    const shortfall = requiredIncome - totalIncome;
    const qualifies = shortfall <= 0;

    // Check if guarantor is needed (if income is less than required)
    const needsGuarantor = shortfall > 0;

    const messages: string[] = [];

    if (qualifies) {
      messages.push(
        `✅ Great news! Your total annual income of £${totalIncome.toLocaleString()} meets the requirement of £${requiredIncome.toLocaleString()}.`
      );
    } else if (needsGuarantor) {
      const guarantorRequiredIncome = await this.calculateGuarantorRequiredIncome(monthlyRent);
      messages.push(
        `Your total annual income is £${totalIncome.toLocaleString()}, which is £${Math.abs(shortfall).toLocaleString()} short of the required £${requiredIncome.toLocaleString()}.`
      );
      messages.push(
        `You may need a UK-based guarantor to proceed. Your guarantor would need an annual income of £${guarantorRequiredIncome.toLocaleString()}.`
      );
    } else {
      messages.push(
        `Your total annual income is £${totalIncome.toLocaleString()}, which is significantly below the required £${requiredIncome.toLocaleString()}.`
      );
      messages.push(
        `You're welcome to continue the application, but please be aware that approval may be difficult without additional income sources or a guarantor.`
      );
    }

    return {
      qualifies,
      requiredIncome,
      totalIncome,
      shortfall,
      needsGuarantor,
      messages,
      warnings,
    };
  }

  /**
   * Extract monthly rent from property price string
   */
  parseMonthlyRent(priceString: string): number {
    // Extract numbers from strings like "£1,500 pcm" or "£2500 per month"
    const cleanPrice = priceString.replace(/[£,]/g, '').trim();
    const match = cleanPrice.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  }
}

export const rulesEngine = RulesEngine.getInstance();
