import axios from 'axios';

export interface LoopProperty {
  id: number;
  address: string;
  price: string;
  bedrooms: number;
  bathrooms: number;
  propertyType: string;
  description: string;
  images: string[];
  url: string;
  status: string;
}

export class LoopService {
  private apiKey: string;
  private baseUrl = 'https://api.loop.software';

  constructor() {
    this.apiKey = process.env.LOOP_API_KEY || '';
    if (!this.apiKey) {
      console.warn('⚠️ LOOP_API_KEY not found - Loop integration disabled');
    }
  }

  private async makeRequest(endpoint: string, params: Record<string, any> = {}) {
    if (!this.apiKey) {
      throw new Error('Loop API key not configured');
    }

    try {
      const response = await axios.get(`${this.baseUrl}${endpoint}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        params,
        timeout: 10000
      });

      return response.data;
    } catch (error: any) {
      console.error(`Loop API error for ${endpoint}:`, error.message);
      throw new Error(`Loop API request failed: ${error.message}`);
    }
  }

  /**
   * Fetch lettings properties using Loop API
   * Uses the recommended endpoint for website property portfolios
   */
  async getLettingsProperties(channel: string = 'website'): Promise<LoopProperty[]> {
    try {
      console.log('🏢 Fetching lettings properties from Loop API...');
      
      // Use the recommended endpoint for website property portfolios
      const response = await this.makeRequest(`/property/residential/lettings/listed/${channel}`);
      
      if (!response.success || !response.data) {
        console.warn('Loop API returned no lettings data');
        return [];
      }

      const properties = response.data.map((property: any) => this.formatLoopProperty(property));
      console.log(`✅ Fetched ${properties.length} lettings properties from Loop`);
      return properties;

    } catch (error: any) {
      console.error('Failed to fetch lettings from Loop:', error.message);
      return [];
    }
  }

  /**
   * Fetch sales properties using Loop API
   * Uses the recommended endpoint for website property portfolios
   */
  async getSalesProperties(channel: string = 'website'): Promise<LoopProperty[]> {
    try {
      console.log('🏠 Fetching sales properties from Loop API...');
      
      const response = await this.makeRequest(`/property/residential/sales/listed/${channel}`);
      
      if (!response.success || !response.data) {
        console.warn('Loop API returned no sales data');
        return [];
      }

      const properties = response.data.map((property: any) => this.formatLoopProperty(property));
      console.log(`✅ Fetched ${properties.length} sales properties from Loop`);
      return properties;

    } catch (error: any) {
      console.error('Failed to fetch sales from Loop:', error.message);
      return [];
    }
  }

  /**
   * Get all properties (lettings + sales)
   */
  async getAllProperties(channel: string = 'website'): Promise<LoopProperty[]> {
    try {
      const [lettings, sales] = await Promise.all([
        this.getLettingsProperties(channel),
        this.getSalesProperties(channel)
      ]);

      const allProperties = [...lettings, ...sales];
      console.log(`📊 Total properties from Loop: ${allProperties.length} (${lettings.length} lettings, ${sales.length} sales)`);
      
      return allProperties;
    } catch (error: any) {
      console.error('Failed to fetch all properties from Loop:', error.message);
      return [];
    }
  }

  /**
   * Format Loop API property data to match our interface
   */
  private formatLoopProperty(property: any): LoopProperty {
    // Extract address information
    const address = this.formatAddress(property);
    
    // Format price
    let price = 'Price on application';
    if (property.price) {
      price = typeof property.price === 'number' 
        ? `£${property.price.toLocaleString()}`
        : property.price.toString();
      
      // Add frequency for lettings
      if (property.rentFrequency || property.type === 'lettings') {
        price += property.rentFrequency === 'Weekly' ? ' per week' : ' per month';
      }
    }

    // Extract images
    const images = this.extractImages(property);
    
    // Create property URL (if available)
    const url = property.url || property.propertyUrl || '';

    return {
      id: property.id || 0,
      address,
      price,
      bedrooms: property.bedrooms || 0,
      bathrooms: property.bathrooms || 0,
      propertyType: property.propertyType || 'Property',
      description: property.description || `${property.propertyType || 'Property'} available`,
      images,
      url,
      status: property.status || 'Available'
    };
  }

  /**
   * Format address from Loop property data
   */
  private formatAddress(property: any): string {
    const parts = [];
    
    if (property.address) {
      if (typeof property.address === 'string') {
        return property.address;
      }
      
      // Handle structured address object
      if (property.address.line1) parts.push(property.address.line1);
      if (property.address.line2) parts.push(property.address.line2);
      if (property.address.town) parts.push(property.address.town);
      if (property.address.county) parts.push(property.address.county);
      if (property.address.postcode) parts.push(property.address.postcode);
    }
    
    // Fallback to other address fields
    if (parts.length === 0) {
      if (property.displayAddress) parts.push(property.displayAddress);
      if (property.town) parts.push(property.town);
      if (property.postcode) parts.push(property.postcode);
    }
    
    return parts.length > 0 ? parts.join(', ') : 'Address available on request';
  }

  /**
   * Extract and format images from Loop property data
   */
  private extractImages(property: any): string[] {
    const images: string[] = [];
    
    // Check various image fields
    if (property.images && Array.isArray(property.images)) {
      property.images.forEach((img: any) => {
        if (typeof img === 'string') {
          images.push(img);
        } else if (img.url) {
          images.push(img.url);
        } else if (img.src) {
          images.push(img.src);
        }
      });
    }
    
    // Check for main image
    if (property.mainImage) {
      images.unshift(property.mainImage);
    }
    
    // Check for featured image
    if (property.featuredImage && !images.includes(property.featuredImage)) {
      images.unshift(property.featuredImage);
    }
    
    return [...new Set(images)]; // Remove duplicates
  }

  /**
   * Test the Loop API connection and get basic info
   */
  async testConnection(): Promise<{ success: boolean; message: string; details?: any }> {
    if (!this.apiKey) {
      return {
        success: false,
        message: 'Loop API key not configured'
      };
    }

    try {
      // Test with team endpoint as it's simple and always available
      const teamData = await this.makeRequest('/team');
      console.log('✅ Loop API connection successful');
      
      return {
        success: true,
        message: 'Loop API connection successful',
        details: {
          teamId: teamData.data?.id,
          teamName: teamData.data?.name,
          apiVersion: 'v2'
        }
      };
    } catch (error: any) {
      console.error('❌ Loop API connection failed:', error);
      return {
        success: false,
        message: `Loop API connection failed: ${error.message}`,
        details: {
          errorType: error.response?.status ? `HTTP ${error.response.status}` : 'Network Error',
          endpoint: '/team'
        }
      };
    }
  }

  /**
   * Get available channels/listings from Loop
   */
  async getAvailableChannels(): Promise<string[]> {
    // For now, return common channel names
    // In practice, this would query the Loop API for available channels
    return ['website', 'rightmove', 'zoopla', 'onthemarket'];
  }
}

export const loopService = new LoopService();