import { storage } from "../storage";
import type { ApplicationWithNotes } from "@shared/schema";

export interface AdvancedSearchResult {
  query: string;
  summary: string;
  totalFound: number;
  applications: ApplicationWithNotes[];
  filters: ParsedFilters;
  timestamp: Date;
  executionTime: number;
  debugInfo?: {
    originalQuery: string;
    normalizedQuery: string;
    extractedConditions: string[];
    appliedFilters: any;
  };
}

export interface ParsedFilters {
  // Income filtering with ranges
  minIncome?: number;
  maxIncome?: number;
  incomeRange?: { min: number; max: number };
  
  // Occupation and employment
  occupation?: string[];
  excludeOccupation?: string[];
  hasTaxReturns?: boolean;
  
  // Financial and guarantor
  hasGuarantor?: boolean;
  hasCCJ?: boolean;
  
  // Lifestyle and preferences
  hasPets?: boolean;
  smokes?: boolean;
  
  // Household composition
  hasChildren?: boolean;
  isSingle?: boolean;
  adults?: { min?: number; max?: number; exact?: number };
  children?: { min?: number; max?: number; exact?: number };
  
  // Move preferences
  moveDate?: string[];
  moveUrgency?: string;
  
  // Age filtering
  ageRange?: { min?: number; max?: number };
  
  // Property specific
  propertyAddress?: string;
  
  // Sorting and limits
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  
  // Complex logic
  logicOperator?: 'AND' | 'OR';
  negativeConditions?: string[];
}

export class AdvancedSearchEngine {
  
  // Fuzzy matching dictionaries for common misspellings and synonyms
  private static readonly OCCUPATION_SYNONYMS = {
    'self-employed': ['self emploied', 'self employed', 'freelance', 'contractor', 'self-emp'],
    'employed': ['employee', 'worker', 'working', 'job holder'],
    'unemployed': ['jobless', 'not working', 'out of work', 'no job'],
    'student': ['studying', 'in school', 'uni', 'university', 'college'],
    'retired': ['pension', 'pensioner', 'old age']
  };
  
  private static readonly FIELD_SYNONYMS = {
    'guarantor': ['garnter', 'guaranter', 'guaranteer', 'garuntor', 'sponsor'],
    'pets': ['dog', 'cat', 'animal', 'pet'],
    'children': ['kids', 'child', 'baby', 'babies', 'son', 'daughter'],
    'smoking': ['smokes', 'smkers', 'smoker', 'smoking', 'cigarettes'],
    'income': ['earning', 'salary', 'wage', 'pay', 'money', 'makin'],
    'ccj': ['ivaa', 'iva', 'bad credit', 'debt'],
    'asap': ['urgent', 'immediately', 'now', 'quick', 'fast'],
    'move': ['relocate', 'moving', 'wana move', 'wants 2 move']
  };
  
  private static readonly INFORMAL_PATTERNS = {
    'any1': 'anyone',
    'r': 'are',
    'u': 'you',
    'w/': 'with',
    'n': 'and',
    'nxt': 'next',
    'wk': 'week',
    'yr': 'year',
    '2': 'to',
    'got': 'has',
    'aint': 'is not',
    "ain't": 'is not',
    'wana': 'want to',
    'gonna': 'going to'
  };

  async processQuery(queryText: string): Promise<AdvancedSearchResult> {
    const startTime = Date.now();
    const originalQuery = queryText;
    
    console.log(`🔍 Advanced search processing: "${queryText}"`);
    
    // Step 1: Normalize the query (fix spelling, expand informal language)
    const normalizedQuery = this.normalizeQuery(queryText);
    console.log(`📝 Normalized query: "${normalizedQuery}"`);
    
    // Step 2: Extract conditions and logic
    const conditions = this.extractConditions(normalizedQuery);
    console.log(`🔧 Extracted conditions:`, conditions);
    
    // Step 3: Parse into structured filters
    const filters = this.parseAdvancedQuery(normalizedQuery, conditions);
    console.log(`📋 Parsed filters:`, JSON.stringify(filters, null, 2));
    
    // Step 4: Get applications from database
    const { applications: allApps } = await storage.getApplications({ limit: 1000 });
    console.log(`📊 Total applications in database: ${allApps.length}`);
    
    // Step 5: Apply complex filtering
    const filteredApps = this.applyAdvancedFilters(allApps, filters, conditions);
    console.log(`🎯 Filtered to: ${filteredApps.length} applications`);
    
    // Step 6: Apply sorting and limits
    const finalResults = this.applySortingAndLimits(filteredApps, filters);
    
    // Step 7: Generate summary
    const summary = this.generateAdvancedSummary(originalQuery, finalResults, filters, conditions);
    
    const executionTime = Date.now() - startTime;
    
    const result: AdvancedSearchResult = {
      query: originalQuery,
      summary,
      totalFound: finalResults.length,
      applications: finalResults,
      filters,
      timestamp: new Date(),
      executionTime,
      debugInfo: {
        originalQuery,
        normalizedQuery,
        extractedConditions: conditions,
        appliedFilters: filters
      }
    };
    
    console.log(`✅ Advanced search completed in ${executionTime}ms, returning ${result.totalFound} results`);
    return result;
  }

  private normalizeQuery(query: string): string {
    let normalized = query.toLowerCase().trim();
    
    // Fix informal language patterns
    Object.entries(AdvancedSearchEngine.INFORMAL_PATTERNS).forEach(([informal, formal]) => {
      const regex = new RegExp(`\\b${informal}\\b`, 'gi');
      normalized = normalized.replace(regex, formal);
    });
    
    // Fix common field misspellings
    Object.entries(AdvancedSearchEngine.FIELD_SYNONYMS).forEach(([correct, synonyms]) => {
      synonyms.forEach(synonym => {
        const regex = new RegExp(`\\b${synonym}\\b`, 'gi');
        normalized = normalized.replace(regex, correct);
      });
    });
    
    // Fix occupation misspellings
    Object.entries(AdvancedSearchEngine.OCCUPATION_SYNONYMS).forEach(([correct, synonyms]) => {
      synonyms.forEach(synonym => {
        const regex = new RegExp(`\\b${synonym}\\b`, 'gi');
        normalized = normalized.replace(regex, correct);
      });
    });
    
    return normalized;
  }

  private extractConditions(query: string): string[] {
    const conditions: string[] = [];
    
    // Split on common conjunctions while preserving them
    const parts = query.split(/\b(and|or|but|also|who|with|without|not|no)\b/i);
    
    let currentCondition = '';
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i].trim();
      if (part && !['and', 'or', 'but', 'also', 'who'].includes(part.toLowerCase())) {
        if (currentCondition) {
          currentCondition += ' ' + part;
        } else {
          currentCondition = part;
        }
      } else if (currentCondition) {
        conditions.push(currentCondition.trim());
        currentCondition = '';
      }
    }
    
    if (currentCondition) {
      conditions.push(currentCondition.trim());
    }
    
    return conditions.filter(c => c.length > 2);
  }

  private parseAdvancedQuery(query: string, conditions: string[]): ParsedFilters {
    const filters: ParsedFilters = {};
    const lowerQuery = query.toLowerCase();

    // Income parsing - enhanced for ranges and complex patterns
    const incomePatterns = [
      /(?:earning|income|making|salary).*?(?:over|above|more than|greater than)\s*[£$]?(\d+)k?/,
      /(?:over|above|more than|greater than)\s*[£$]?(\d+)k?.*?(?:earning|income|making)/,
      /(\d+)k?\+/,
      /[£$](\d+)k?\+/,
      /making.*?(\d+)k/
    ];
    
    const belowIncomePatterns = [
      /(?:earning|income|making|salary).*?(?:under|below|less than|beneath)\s*[£$]?(\d+)k?/,
      /(?:under|below|less than|beneath)\s*[£$]?(\d+)k?.*?(?:earning|income|making)/
    ];
    
    // Range patterns like "40-50k" or "between 30k and 50k"
    const rangeMatch = lowerQuery.match(/(\d+)k?\s*[-–]\s*(\d+)k?|\bbetween\s+(\d+)k?\s+and\s+(\d+)k?/);
    if (rangeMatch) {
      const min = parseInt(rangeMatch[1] || rangeMatch[3]);
      const max = parseInt(rangeMatch[2] || rangeMatch[4]);
      filters.incomeRange = { 
        min: min > 1000 ? min : min * 1000,
        max: max > 1000 ? max : max * 1000
      };
    } else {
      // Single income thresholds
      for (const pattern of incomePatterns) {
        const match = lowerQuery.match(pattern);
        if (match) {
          const amount = parseInt(match[1]);
          filters.minIncome = amount > 1000 ? amount : amount * 1000;
          break;
        }
      }
      
      for (const pattern of belowIncomePatterns) {
        const match = lowerQuery.match(pattern);
        if (match) {
          const amount = parseInt(match[1]);
          filters.maxIncome = amount > 1000 ? amount : amount * 1000;
          break;
        }
      }
    }

    // Occupation parsing with negation support
    const occupations = ['self-employed', 'employed', 'unemployed', 'student', 'retired'];
    const excludeOccupations: string[] = [];
    
    occupations.forEach(occ => {
      if (lowerQuery.includes(`not ${occ}`) || lowerQuery.includes(`isn't ${occ}`) || lowerQuery.includes(`not a ${occ}`)) {
        excludeOccupations.push(occ);
      } else if (lowerQuery.includes(occ)) {
        if (!filters.occupation) filters.occupation = [];
        filters.occupation.push(occ);
      }
    });
    
    if (excludeOccupations.length > 0) {
      filters.excludeOccupation = excludeOccupations;
    }

    // Complex boolean parsing for pets
    if (lowerQuery.includes('no pets') || lowerQuery.includes('without pets') || lowerQuery.includes('no dog') || lowerQuery.includes('without a dog')) {
      filters.hasPets = false;
    } else if (lowerQuery.includes('pets') || lowerQuery.includes('dog') || lowerQuery.includes('cat') || lowerQuery.includes('animal')) {
      filters.hasPets = true;
    }

    // Smoking with negation
    if (lowerQuery.includes('not smoker') || lowerQuery.includes('non-smoker') || lowerQuery.includes('not smoking')) {
      filters.smokes = false;
    } else if (lowerQuery.includes('smokes') || lowerQuery.includes('smoker') || lowerQuery.includes('smoking')) {
      filters.smokes = true;
    }

    // Guarantor parsing
    if (lowerQuery.includes('no guarantor') || lowerQuery.includes('without guarantor')) {
      filters.hasGuarantor = false;
    } else if (lowerQuery.includes('guarantor') || lowerQuery.includes('sponsor')) {
      filters.hasGuarantor = true;
    }

    // CCJ/IVA parsing
    if (lowerQuery.includes('no ccj') || lowerQuery.includes('no iva') || lowerQuery.includes('no bad credit')) {
      filters.hasCCJ = false;
    } else if (lowerQuery.includes('ccj') || lowerQuery.includes('iva') || lowerQuery.includes('bad credit')) {
      filters.hasCCJ = true;
    }

    // Children parsing
    if (lowerQuery.includes('no children') || lowerQuery.includes('no kids') || lowerQuery.includes('childless')) {
      filters.hasChildren = false;
    } else if (lowerQuery.includes('children') || lowerQuery.includes('kids') || lowerQuery.includes('family')) {
      filters.hasChildren = true;
    }

    // Single status
    if (lowerQuery.includes('single') || lowerQuery.includes('alone') || lowerQuery.includes('individual')) {
      filters.isSingle = true;
    }

    // Move date parsing
    if (lowerQuery.includes('asap') || lowerQuery.includes('urgent') || lowerQuery.includes('immediately')) {
      filters.moveDate = ['asap'];
    } else if (lowerQuery.includes('next week') || lowerQuery.includes('next few days')) {
      filters.moveDate = ['few-days'];
    } else if (lowerQuery.includes('next month') || lowerQuery.includes('few months')) {
      filters.moveDate = ['few-months'];
    }

    // Age parsing
    const ageMatch = lowerQuery.match(/(?:under|below)\s+age\s+(\d+)|(?:aged?|age)\s*(?:under|below)\s*(\d+)/);
    if (ageMatch) {
      filters.ageRange = { max: parseInt(ageMatch[1] || ageMatch[2]) };
    }

    // Top/limit parsing
    const topMatch = lowerQuery.match(/top\s+(\d+)/);
    if (topMatch) {
      filters.limit = parseInt(topMatch[1]);
      filters.sortBy = 'income';
      filters.sortOrder = 'desc';
    }

    // Property address parsing
    const addressMatch = lowerQuery.match(/(?:for|at|on|applied for)\s+(\d+\s+[a-z\s]+(?:street|road|avenue|lane|close|way|drive))/i);
    if (addressMatch) {
      filters.propertyAddress = addressMatch[1];
    }

    return filters;
  }

  private applyAdvancedFilters(applications: ApplicationWithNotes[], filters: ParsedFilters, conditions: string[]): ApplicationWithNotes[] {
    return applications.filter(app => {
      // Income filtering with ranges
      if (filters.incomeRange) {
        const income = Number(app.annualIncome);
        if (income < filters.incomeRange.min || income > filters.incomeRange.max) {
          return false;
        }
      } else {
        if (filters.minIncome && Number(app.annualIncome) < filters.minIncome) {
          return false;
        }
        if (filters.maxIncome && Number(app.annualIncome) > filters.maxIncome) {
          return false;
        }
      }

      // Occupation filtering with exclusions
      if (filters.occupation && !filters.occupation.includes(app.occupation)) {
        return false;
      }
      if (filters.excludeOccupation && filters.excludeOccupation.includes(app.occupation)) {
        return false;
      }

      // Tax returns (for self-employed)
      if (filters.hasTaxReturns !== undefined && app.occupation === 'self-employed') {
        if (app.hasTaxReturns !== filters.hasTaxReturns) {
          return false;
        }
      }

      // Boolean filters
      if (filters.hasGuarantor !== undefined && app.hasGuarantor !== filters.hasGuarantor) {
        return false;
      }
      if (filters.hasCCJ !== undefined && app.hasCCJIVA !== filters.hasCCJ) {
        return false;
      }
      if (filters.hasPets !== undefined && app.hasPets !== filters.hasPets) {
        return false;
      }
      if (filters.smokes !== undefined && app.smokes !== filters.smokes) {
        return false;
      }

      // Household composition
      if (filters.hasChildren !== undefined) {
        const hasKids = (app.children || 0) > 0;
        if (hasKids !== filters.hasChildren) {
          return false;
        }
      }
      if (filters.isSingle && (app.adults !== 1 || (app.children || 0) > 0)) {
        return false;
      }

      // Move date filtering
      if (filters.moveDate && !filters.moveDate.includes(app.moveDate)) {
        return false;
      }

      return true;
    });
  }

  private applySortingAndLimits(applications: ApplicationWithNotes[], filters: ParsedFilters): ApplicationWithNotes[] {
    let result = [...applications];

    // Apply sorting
    if (filters.sortBy === 'income') {
      result.sort((a, b) => {
        const diff = Number(b.annualIncome) - Number(a.annualIncome);
        return filters.sortOrder === 'asc' ? -diff : diff;
      });
    } else if (filters.sortBy === 'name') {
      result.sort((a, b) => a.fullName.localeCompare(b.fullName));
    } else {
      // Default sort by creation date (newest first)
      result.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    }

    // Apply limit
    if (filters.limit && filters.limit > 0) {
      result = result.slice(0, filters.limit);
    }

    return result;
  }

  private generateAdvancedSummary(originalQuery: string, applications: ApplicationWithNotes[], filters: ParsedFilters, conditions: string[]): string {
    const count = applications.length;
    
    if (count === 0) {
      const conditionsStr = this.describeFilters(filters);
      return `No applicants found matching: ${conditionsStr}. Try relaxing one condition or checking for spelling.`;
    }

    let summary = `Found ${count} application${count !== 1 ? 's' : ''}`;

    // Add filter descriptions
    const descriptions = this.describeFilters(filters);
    if (descriptions) {
      summary += ` matching: ${descriptions}`;
    }

    // Add income statistics for successful searches
    if (count > 0) {
      const incomes = applications.map(app => Number(app.annualIncome));
      const avgIncome = incomes.reduce((a, b) => a + b, 0) / incomes.length;
      const maxIncome = Math.max(...incomes);
      const minIncome = Math.min(...incomes);
      
      summary += `. Average income: £${Math.round(avgIncome).toLocaleString()}`;
      if (count > 1) {
        summary += ` (range: £${minIncome.toLocaleString()} - £${maxIncome.toLocaleString()})`;
      }
    }

    return summary;
  }

  private describeFilters(filters: ParsedFilters): string {
    const descriptions: string[] = [];
    
    if (filters.incomeRange) {
      descriptions.push(`income £${filters.incomeRange.min.toLocaleString()}-£${filters.incomeRange.max.toLocaleString()}`);
    } else {
      if (filters.minIncome) {
        descriptions.push(`income £${filters.minIncome.toLocaleString()}+`);
      }
      if (filters.maxIncome) {
        descriptions.push(`income under £${filters.maxIncome.toLocaleString()}`);
      }
    }
    
    if (filters.occupation) {
      descriptions.push(`${filters.occupation.join(', ')} workers`);
    }
    if (filters.excludeOccupation) {
      descriptions.push(`not ${filters.excludeOccupation.join(', ')}`);
    }
    if (filters.hasPets === true) {
      descriptions.push('with pets');
    }
    if (filters.hasPets === false) {
      descriptions.push('no pets');
    }
    if (filters.hasGuarantor === true) {
      descriptions.push('with guarantors');
    }
    if (filters.hasGuarantor === false) {
      descriptions.push('no guarantors');
    }
    if (filters.hasChildren === true) {
      descriptions.push('with children');
    }
    if (filters.hasChildren === false) {
      descriptions.push('no children');
    }
    if (filters.isSingle) {
      descriptions.push('single applicants');
    }
    if (filters.moveDate?.includes('asap')) {
      descriptions.push('moving ASAP');
    }
    if (filters.smokes === false) {
      descriptions.push('non-smokers');
    }
    if (filters.smokes === true) {
      descriptions.push('smokers');
    }
    if (filters.hasCCJ === false) {
      descriptions.push('no CCJ/IVA');
    }

    return descriptions.join(', ');
  }
}

export const advancedSearchEngine = new AdvancedSearchEngine();