import type { ApplicationWithNotes } from "@shared/schema";

export interface AIQueryResult {
  query: string;
  summary: string;
  data: any[];
  queryType: 'list' | 'count' | 'summary' | 'analysis';
  timestamp: Date;
}

export class FallbackAIService {
  // Pre-defined smart queries
  static readonly SMART_QUERIES = [
    "Show me all new applications that need review",
    "List applicants with annual income over £40,000",
    "Who has pets and wants to move ASAP?",
    "Show self-employed applicants without tax returns",
    "Which applicants have CCJ/IVA issues?",
    "List all approved applications this week",
    "Show applicants who can provide a guarantor",
    "Find non-smokers with children"
  ];

  async processQuery(query: string, applications: ApplicationWithNotes[]): Promise<AIQueryResult> {
    const lowerQuery = query.toLowerCase();
    let filteredData = [...applications];
    let summary = "";
    let queryType: 'list' | 'count' | 'summary' | 'analysis' = 'list';

    // Pattern matching for different query types
    if (this.matchesPattern(lowerQuery, ['how many', 'count', 'number of'])) {
      queryType = 'count';
    } else if (this.matchesPattern(lowerQuery, ['summary', 'analyze', 'analysis', 'overview'])) {
      queryType = 'analysis';
    }

    // Income-based queries
    if (this.matchesPattern(lowerQuery, ['income', 'salary', 'earning'])) {
      if (this.matchesPattern(lowerQuery, ['high', 'over', 'above', '40000', '30000', 'over £40', 'over £30'])) {
        const threshold = this.extractNumber(lowerQuery) || 40000;
        filteredData = filteredData.filter(app => Number(app.annualIncome) >= threshold);
        summary = `Found ${filteredData.length} applicants with annual income of £${threshold.toLocaleString()} or higher`;
      } else if (this.matchesPattern(lowerQuery, ['low', 'under', 'below', 'less than'])) {
        const threshold = this.extractNumber(lowerQuery) || 30000;
        filteredData = filteredData.filter(app => Number(app.annualIncome) < threshold);
        summary = `Found ${filteredData.length} applicants with annual income below £${threshold.toLocaleString()}`;
      }
    }

    // Pet-related queries
    if (this.matchesPattern(lowerQuery, ['pet', 'pets', 'dog', 'cat', 'animal'])) {
      if (this.matchesPattern(lowerQuery, ['has', 'have', 'with', 'own'])) {
        filteredData = filteredData.filter(app => app.hasPets);
        summary = `Found ${filteredData.length} applicants who have pets`;
      } else if (this.matchesPattern(lowerQuery, ['no', 'without', 'dont', "don't"])) {
        filteredData = filteredData.filter(app => !app.hasPets);
        summary = `Found ${filteredData.length} applicants without pets`;
      }
    }

    // Move date queries
    if (this.matchesPattern(lowerQuery, ['asap', 'immediately', 'urgent', 'soon'])) {
      filteredData = filteredData.filter(app => app.moveDate === 'asap');
      summary = `Found ${filteredData.length} applicants who want to move ASAP`;
    }

    // Status queries
    if (this.matchesPattern(lowerQuery, ['new', 'pending', 'review', 'unreviewed'])) {
      filteredData = filteredData.filter(app => app.status === 'new');
      summary = `Found ${filteredData.length} new applications awaiting review`;
    }

    if (this.matchesPattern(lowerQuery, ['approved', 'accepted'])) {
      filteredData = filteredData.filter(app => app.status === 'approved');
      summary = `Found ${filteredData.length} approved applications`;
    }

    if (this.matchesPattern(lowerQuery, ['rejected', 'declined'])) {
      filteredData = filteredData.filter(app => app.status === 'rejected');
      summary = `Found ${filteredData.length} rejected applications`;
    }

    // Occupation queries
    if (this.matchesPattern(lowerQuery, ['self-employed', 'self employed', 'freelance'])) {
      filteredData = filteredData.filter(app => app.occupation === 'self-employed');
      if (this.matchesPattern(lowerQuery, ['tax returns', 'tax return', 'without tax'])) {
        filteredData = filteredData.filter(app => !app.hasTaxReturns);
        summary = `Found ${filteredData.length} self-employed applicants without tax returns`;
      } else {
        summary = `Found ${filteredData.length} self-employed applicants`;
      }
    }

    if (this.matchesPattern(lowerQuery, ['employed', 'job', 'working'])) {
      filteredData = filteredData.filter(app => app.occupation === 'employed');
      summary = `Found ${filteredData.length} employed applicants`;
    }

    if (this.matchesPattern(lowerQuery, ['unemployed', 'jobless', 'no job'])) {
      filteredData = filteredData.filter(app => app.occupation === 'unemployed');
      summary = `Found ${filteredData.length} unemployed applicants`;
    }

    // Financial queries
    if (this.matchesPattern(lowerQuery, ['ccj', 'iva', 'credit', 'debt'])) {
      if (this.matchesPattern(lowerQuery, ['has', 'have', 'with'])) {
        filteredData = filteredData.filter(app => app.hasCCJIVA);
        summary = `Found ${filteredData.length} applicants with CCJ/IVA issues`;
      } else if (this.matchesPattern(lowerQuery, ['no', 'without', 'clean'])) {
        filteredData = filteredData.filter(app => !app.hasCCJIVA);
        summary = `Found ${filteredData.length} applicants without CCJ/IVA issues`;
      }
    }

    if (this.matchesPattern(lowerQuery, ['guarantor'])) {
      if (this.matchesPattern(lowerQuery, ['has', 'have', 'with', 'can provide'])) {
        filteredData = filteredData.filter(app => app.hasGuarantor);
        summary = `Found ${filteredData.length} applicants who can provide a guarantor`;
      } else if (this.matchesPattern(lowerQuery, ['no', 'without', 'cannot'])) {
        filteredData = filteredData.filter(app => !app.hasGuarantor);
        summary = `Found ${filteredData.length} applicants without a guarantor`;
      }
    }

    // Smoking queries
    if (this.matchesPattern(lowerQuery, ['smoke', 'smoking', 'smoker'])) {
      if (this.matchesPattern(lowerQuery, ['non', 'no', 'dont', "don't", 'not'])) {
        filteredData = filteredData.filter(app => !app.smokes);
        summary = `Found ${filteredData.length} non-smoking applicants`;
      } else {
        filteredData = filteredData.filter(app => app.smokes);
        summary = `Found ${filteredData.length} smoking applicants`;
      }
    }

    // Children queries
    if (this.matchesPattern(lowerQuery, ['children', 'kids', 'child', 'family'])) {
      if (this.matchesPattern(lowerQuery, ['with', 'has', 'have'])) {
        filteredData = filteredData.filter(app => (app.children || 0) > 0);
        summary = `Found ${filteredData.length} applicants with children`;
      } else if (this.matchesPattern(lowerQuery, ['no', 'without'])) {
        filteredData = filteredData.filter(app => (app.children || 0) === 0);
        summary = `Found ${filteredData.length} applicants without children`;
      }
    }

    // Combine multiple filters
    if (this.matchesPattern(lowerQuery, ['pets']) && this.matchesPattern(lowerQuery, ['asap'])) {
      filteredData = applications.filter(app => app.hasPets && app.moveDate === 'asap');
      summary = `Found ${filteredData.length} applicants with pets who want to move ASAP`;
    }

    if (this.matchesPattern(lowerQuery, ['high income']) && this.matchesPattern(lowerQuery, ['guarantor'])) {
      filteredData = applications.filter(app => Number(app.annualIncome) > 40000 && app.hasGuarantor);
      summary = `Found ${filteredData.length} high-income applicants with guarantors`;
    }

    // Default fallback
    if (summary === "") {
      summary = `Showing ${filteredData.length} applications matching your query`;
    }

    // Sort by most relevant criteria
    filteredData = this.sortResults(filteredData, lowerQuery);

    return {
      query,
      summary,
      data: filteredData,
      queryType,
      timestamp: new Date()
    };
  }

  private matchesPattern(query: string, keywords: string[]): boolean {
    return keywords.some(keyword => query.includes(keyword));
  }

  private extractNumber(query: string): number | null {
    const matches = query.match(/\d+/g);
    if (matches) {
      return parseInt(matches[0]);
    }
    return null;
  }

  private sortResults(data: ApplicationWithNotes[], query: string): ApplicationWithNotes[] {
    // Sort by income if income-related query
    if (this.matchesPattern(query, ['income', 'salary', 'high', 'earning'])) {
      return data.sort((a, b) => Number(b.annualIncome) - Number(a.annualIncome));
    }
    
    // Sort by creation date for most queries
    return data.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async generateSuggestedQueries(applications: ApplicationWithNotes[]): Promise<string[]> {
    const stats = {
      total: applications.length,
      newApps: applications.filter(app => app.status === 'new').length,
      highIncome: applications.filter(app => Number(app.annualIncome) > 40000).length,
      withPets: applications.filter(app => app.hasPets).length,
      selfEmployed: applications.filter(app => app.occupation === 'self-employed').length,
    };

    const suggestions = [...FallbackAIService.SMART_QUERIES];
    
    // Add dynamic suggestions based on data
    if (stats.newApps > 0) {
      suggestions.unshift(`Show ${stats.newApps} new applications awaiting review`);
    }
    if (stats.highIncome > 0) {
      suggestions.push(`Analyze ${stats.highIncome} high-income applicants (£40k+)`);
    }
    if (stats.withPets > 0) {
      suggestions.push(`List ${stats.withPets} applicants with pets`);
    }

    return suggestions.slice(0, 8);
  }
}

export const fallbackAIService = new FallbackAIService();