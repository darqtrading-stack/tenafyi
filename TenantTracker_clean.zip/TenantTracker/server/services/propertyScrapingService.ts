import { db } from "../db";
import { propertyListings } from "@shared/schema";
import { eq } from "drizzle-orm";
import { loopService, LoopProperty } from "./loopService";

interface ScrapedProperty {
  title: string;
  price: string;
  beds: string;
  thumbnail: string;
  url: string;
  description: string;
}

export class PropertyScrapingService {
  private static instance: PropertyScrapingService;
  private isRunning = false;
  private memoryCache: ScrapedProperty[] = [];
  private lastSuccessfulScrape: Date | null = null;
  private cacheExpiryHours = 24; // Cache expires after 24 hours

  public static getInstance(): PropertyScrapingService {
    if (!PropertyScrapingService.instance) {
      PropertyScrapingService.instance = new PropertyScrapingService();
    }
    return PropertyScrapingService.instance;
  }

  public async scrapeProperties(): Promise<ScrapedProperty[]> {
    if (this.isRunning) {
      console.log("Property scraping already in progress, skipping...");
      return [];
    }

    this.isRunning = true;

    try {
      // First try to get properties from Loop API
      console.log("🚀 Starting hybrid property fetching (Loop API + web scraping fallback)...");
      const loopProperties = await this.getPropertiesFromLoop();
      
      if (loopProperties.length > 0) {
        console.log(`✅ Successfully fetched ${loopProperties.length} properties from Loop API`);
        await this.updateDatabaseWithFallback(loopProperties);
        return loopProperties;
      }
      
      // Fallback to web scraping if Loop API fails or returns no data
      console.log("📡 Loop API returned no data, falling back to web scraping...");
      console.log("Starting property scraping from JT Property Consultants...");
      
      const response = await fetch('https://jtpropertyconsultants.co.uk/property-to-rent');
      const html = await response.text();
      
      const properties = this.parsePropertiesFromHtml(html);
      console.log(`Scraped ${properties.length} properties via web scraping`);
      
      // Only update database if we found properties to avoid data loss
      if (properties.length > 0) {
        console.log("Updating database with scraped properties...");
        await this.updateDatabaseWithFallback(properties);
      } else {
        console.log("⚠️ No properties found - keeping existing data intact");
      }
      
      return properties;
    } catch (error) {
      console.error("Error in hybrid property fetching:", error);
      return [];
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Fetch properties from Loop API and convert to ScrapedProperty format
   */
  private async getPropertiesFromLoop(): Promise<ScrapedProperty[]> {
    try {
      const loopProperties = await loopService.getAllProperties();
      
      // Convert Loop properties to our ScrapedProperty format
      return loopProperties.map(this.convertLoopPropertyToScraped);
    } catch (error) {
      console.error("Failed to fetch from Loop API:", error);
      return [];
    }
  }

  /**
   * Convert Loop property format to our existing ScrapedProperty format
   */
  private convertLoopPropertyToScraped(loopProperty: LoopProperty): ScrapedProperty {
    // Format beds and baths info
    let bedsInfo = '';
    if (loopProperty.bedrooms > 0 || loopProperty.bathrooms > 0) {
      const parts = [];
      if (loopProperty.bedrooms > 0) parts.push(`${loopProperty.bedrooms} bed`);
      if (loopProperty.bathrooms > 0) parts.push(`${loopProperty.bathrooms} bath`);
      bedsInfo = parts.join(', ');
    } else {
      bedsInfo = loopProperty.propertyType || 'Property';
    }

    return {
      title: loopProperty.address,
      price: loopProperty.price,
      beds: bedsInfo,
      thumbnail: loopProperty.images[0] || '', // Use first image as thumbnail
      url: loopProperty.url,
      description: loopProperty.description
    };
  }

  private findNearbyImage(html: string, anchorIndex: number): string | null {
    // Search ±800 characters around the anchor for image URLs
    const start = Math.max(0, anchorIndex - 800);
    const end = Math.min(html.length, anchorIndex + 1200);
    const nearbyHtml = html.slice(start, end);
    
    // Look for data-src or src with CDN URLs
    const imgMatch = nearbyHtml.match(/(?:data-src|src)="(https:\/\/cdn2-property\.estateapps\.co\.uk\/files\/property\/\d+\/image\/[^"\s]+\.(?:jpg|jpeg|png|gif|webp))"/i);
    
    if (imgMatch && imgMatch[1] && !imgMatch[1].includes('data:image/gif') && !imgMatch[1].includes('base64')) {
      return imgMatch[1];
    }
    
    return null;
  }

  private parsePropertiesFromHtml(html: string): ScrapedProperty[] {
    const properties: ScrapedProperty[] = [];
    
    console.log("🔍 Parsing live property data from JT Property Consultants...");
    
    // First, collect all available images for fallback assignment
    const imageMatches = html.matchAll(/data-src="(https:\/\/cdn2-property\.estateapps\.co\.uk\/files\/property\/\d+\/image\/[^"\s]+\.(?:jpg|jpeg|png|gif|webp))"/gi);
    const globalImages = Array.from(imageMatches)
      .map(match => match[1])
      .filter(url => !url.includes('data:image/gif') && !url.includes('base64'));
    
    console.log(`🖼️ Found ${globalImages.length} total images available: ${globalImages.slice(0, 3).join(', ')}${globalImages.length > 3 ? '...' : ''}`);
    
    // Parse properties as complete units using property card blocks
    const propertyCardPattern = /<div[^>]*class="[^"]*property-card[^"]*"[^>]*>[\s\S]*?<\/div>(?=[\s\S]*?(?:<div[^>]*class="[^"]*property-card|$))/gi;
    const propertyCards = html.match(propertyCardPattern) || [];
    
    console.log(`Found ${propertyCards.length} property card blocks`);
    
    if (propertyCards.length === 0) {
      // Fallback: try to parse using property link containers with image extraction
      const linkPattern = /<a[^>]*href="(\/property\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
      let match;
      let matchIndex = 0;
      
      while ((match = linkPattern.exec(html)) !== null) {
        const [fullMatch, url, content] = match;
        const anchorIndex = match.index || 0;
        
        // Extract title from the content
        const titleMatch = content.match(/class="property__title"[^>]*>([^<]+)</);
        // Extract price from the content
        const priceMatch = content.match(/class="price-value"[^>]*>£([^<]+)</);
        // Extract image from the content - prioritize data-src for lazy loaded images
        let imgMatch = content.match(/data-src="([^"]+\.(?:jpg|jpeg|png|gif|webp))"/) || 
                      content.match(/<img[^>]*src="([^"]+\.(?:jpg|jpeg|png|gif|webp))"[^>]*>/) ||
                      content.match(/background-image:\s*url\(['"]?([^'")]+\.(?:jpg|jpeg|png|gif|webp))['"]?\)/);
        
        if (titleMatch && priceMatch) {
          const cleanTitle = titleMatch[1].trim();
          const cleanPrice = priceMatch[1].replace(/[,\s]/g, '');
          
          // Extract actual thumbnail or find nearby image
          let thumbnail = `https://cdn2-property.estateapps.co.uk/files/property/443/image/default.jpg`;
          
          if (imgMatch && imgMatch[1] && !imgMatch[1].includes('data:image/gif') && !imgMatch[1].includes('base64')) {
            let imgUrl = imgMatch[1];
            // Make sure it's a full URL
            if (imgUrl.startsWith('/')) {
              imgUrl = `https://jtpropertyconsultants.co.uk${imgUrl}`;
            } else if (!imgUrl.startsWith('http')) {
              imgUrl = `https://jtpropertyconsultants.co.uk/${imgUrl}`;
            }
            thumbnail = imgUrl;
            console.log(`🖼️ Found thumbnail for "${cleanTitle}": ${thumbnail}`);
          } else {
            // Search nearby HTML for image
            const nearbyImage = this.findNearbyImage(html, anchorIndex);
            if (nearbyImage) {
              thumbnail = nearbyImage;
              console.log(`🖼️ Found nearby thumbnail for "${cleanTitle}": ${thumbnail}`);
            } else if (globalImages[matchIndex]) {
              thumbnail = globalImages[matchIndex];
              console.log(`🖼️ Assigned global thumbnail for "${cleanTitle}": ${thumbnail}`);
            }
          }
          
          properties.push({
            title: cleanTitle,
            price: `£${cleanPrice} per month`,
            beds: this.extractBedInfo(cleanTitle),
            thumbnail: thumbnail,
            url: `https://jtpropertyconsultants.co.uk${url}`,
            description: `Property available to rent in ${this.extractLocation(cleanTitle)}`
          });
          
          matchIndex++;
        }
      }
      
      console.log(`Extracted ${properties.length} properties using fallback parsing`);
    } else {
      // Parse each property card individually
      propertyCards.forEach((card, index) => {
        const urlMatch = card.match(/href="(\/property\/[^"]+)"/);
        const titleMatch = card.match(/class="property__title"[^>]*>([^<]+)</);
        const priceMatch = card.match(/class="price-value"[^>]*>£([^<]+)</);
        // Extract image from the card - prioritize data-src for lazy loaded images
        let imgMatch = card.match(/data-src="([^"]+\.(?:jpg|jpeg|png|gif|webp))"/) || 
                      card.match(/<img[^>]*src="([^"]+\.(?:jpg|jpeg|png|gif|webp))"[^>]*>/) ||
                      card.match(/background-image:\s*url\(['"]?([^'")]+\.(?:jpg|jpeg|png|gif|webp))['"]?\)/);
        
        if (urlMatch && titleMatch && priceMatch) {
          const url = urlMatch[1];
          const title = titleMatch[1].trim();
          const price = priceMatch[1].replace(/[,\s]/g, '');
          
          // Extract actual thumbnail or use global fallback
          let thumbnail = `https://cdn2-property.estateapps.co.uk/files/property/443/image/default.jpg`;
          
          if (imgMatch && imgMatch[1] && !imgMatch[1].includes('data:image/gif') && !imgMatch[1].includes('base64')) {
            let imgUrl = imgMatch[1];
            // Make sure it's a full URL
            if (imgUrl.startsWith('/')) {
              imgUrl = `https://jtpropertyconsultants.co.uk${imgUrl}`;
            } else if (!imgUrl.startsWith('http')) {
              imgUrl = `https://jtpropertyconsultants.co.uk/${imgUrl}`;
            }
            thumbnail = imgUrl;
            console.log(`🖼️ Found thumbnail for "${title}": ${thumbnail}`);
          } else if (globalImages[index]) {
            thumbnail = globalImages[index];
            console.log(`🖼️ Assigned global thumbnail for "${title}": ${thumbnail}`);
          }
          
          properties.push({
            title: title,
            price: `£${price} per month`,
            beds: this.extractBedInfo(title),
            thumbnail: thumbnail,
            url: `https://jtpropertyconsultants.co.uk${url}`,
            description: `Property available to rent in ${this.extractLocation(title)}`
          });
        }
      });
    }
    
    // If still no properties, try a simpler approach
    if (properties.length === 0) {
      console.log("Trying simpler parsing approach...");
      
      // Find all property URLs - improved pattern to catch all property types
      const urlPatterns = [
        /href="(\/property\/[^"]+to-rent-in[^"]+)"/g,  // Main pattern
        /href="(\/property\/[^"]+to-rent[^"]+)"/g,     // Alternative without "in"
        /href="(\/property\/[^"]*\/\d+)"/g             // Fallback with ID pattern
      ];
      
      const urls: string[] = [];
      urlPatterns.forEach(pattern => {
        let urlMatch: RegExpExecArray | null;
        while ((urlMatch = pattern.exec(html)) !== null) {
          const url = urlMatch[1];
          if (url && !urls.includes(url) && url.includes('/property/')) {
            urls.push(url);
          }
        }
      });
      
      // Find all property titles - expanded pattern to catch commercial and residential
      const titlePatterns = [
        /alt="([^"]*(?:bed|studio)[^"]*(?:to rent|rent)[^"]*)"/g,  // Residential properties
        /alt="([^"]*(?:house|flat|bungalow|apartment)[^"]*(?:to rent|rent)[^"]*)"/g,  // Property types
        /alt="([^"]*(?:shop|office|retail|commercial|unit|premises)[^"]*(?:to rent|let)[^"]*)"/g,  // Commercial properties
        /<h3[^>]*class="[^"]*property[^"]*title[^"]*"[^>]*>([^<]+)</g,  // H3 title elements
        /<a[^>]*href="\/property\/[^"]*"[^>]*title="([^"]+)"/g  // Title attributes on links
      ];
      
      const titles: string[] = [];
      titlePatterns.forEach(pattern => {
        let titleMatch: RegExpExecArray | null;
        while ((titleMatch = pattern.exec(html)) !== null) {
          const title = titleMatch[1].trim();
          if (title && !titles.includes(title)) {
            // Accept any property with rental keywords, remove restrictive filtering
            if (title.match(/(?:bed|studio|shop|office|retail|commercial|unit|premises|house|flat|bungalow|apartment).*(?:to rent|rent|to let|let)/i)) {
              titles.push(title);
            }
          }
        }
      });
      
      // Find all prices - expanded patterns for different formats
      const pricePatterns = [
        /class="price-value"[^>]*>£([^<]+)</g,  // Main pattern
        />£([\d,]+)\s*(?:per\s*(?:month|week|annum)|pcm|pw|pa)/gi,  // Flexible price with suffix
        /£([\d,]+)\s*(?:per\s*(?:month|week)|pcm|pw)/gi  // Alternative format
      ];
      
      const prices: string[] = [];
      pricePatterns.forEach(pattern => {
        let priceMatch: RegExpExecArray | null;
        while ((priceMatch = pattern.exec(html)) !== null) {
          const price = priceMatch[1].replace(/[,\s]/g, '');
          if (price && !prices.includes(price)) {
            prices.push(price);
          }
        }
      });
      
      console.log(`Found ${urls.length} URLs, ${titles.length} titles, ${prices.length} prices`);
      
      // Take the minimum count to avoid mismatched data
      const maxCount = Math.min(urls.length, titles.length, prices.length);
      
      for (let i = 0; i < maxCount; i++) {
        // Use global images for simple parsing approach
        let thumbnail = `https://cdn2-property.estateapps.co.uk/files/property/443/image/default.jpg`;
        if (globalImages[i]) {
          thumbnail = globalImages[i];
          console.log(`🖼️ Assigned global thumbnail for "${titles[i]}": ${thumbnail}`);
        }
        
        properties.push({
          title: titles[i].trim(),
          price: `£${prices[i]} per month`,
          beds: this.extractBedInfo(titles[i]),
          thumbnail: thumbnail,
          url: `https://jtpropertyconsultants.co.uk${urls[i]}`,
          description: `Property available to rent in ${this.extractLocation(titles[i])}`
        });
      }
    }
    
    console.log(`✅ Successfully parsed ${properties.length} live properties`);
    
    // Remove duplicates based on URL
    const uniqueProperties = properties.filter((property, index, self) => 
      index === self.findIndex(p => p.url === property.url)
    );
    
    console.log(`✅ Removed duplicates, final count: ${uniqueProperties.length} unique properties`);
    
    return uniqueProperties.slice(0, 20); // Limit to 20 most recent properties
  }
  
  private extractBedInfo(title: string): string {
    const bedMatch = title.match(/(\d+)\s*bed/i);
    if (bedMatch) {
      return `${bedMatch[1]} bed, 1 bath`; // Default to 1 bath if not specified
    }
    
    // Check if it's commercial property
    if (title.match(/(?:shop|office|retail|commercial|unit|premises)/i)) {
      return 'Commercial';
    }
    
    return 'Studio';
  }
  
  private extractLocation(title: string): string {
    const locationMatch = title.match(/in\s+([^,]+)/i);
    return locationMatch ? locationMatch[1].trim() : 'Kent area';
  }

  /**
   * Update database with fallback to memory cache if database fails
   */
  public async updateDatabaseWithFallback(properties: ScrapedProperty[]): Promise<void> {
    // Always update memory cache first
    this.updateMemoryCache(properties);
    
    // Try to update database with retry logic
    const maxRetries = 3;
    let attempt = 0;
    
    while (attempt < maxRetries) {
      try {
        await this.updateDatabase(properties);
        console.log(`✅ Database updated successfully on attempt ${attempt + 1}`);
        return; // Success - exit retry loop
      } catch (error) {
        attempt++;
        if (attempt >= maxRetries) {
          console.error(`❌ Database update failed after ${maxRetries} attempts, falling back to memory cache:`, error);
          console.log(`💾 Cached ${properties.length} properties in memory for immediate serving`);
          return; // Give up and continue with cache
        }
        
        // Exponential backoff: wait 2^attempt seconds
        const waitTime = Math.pow(2, attempt) * 1000;
        console.log(`⏳ Database attempt ${attempt} failed, retrying in ${waitTime/1000}s...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }
  }

  /**
   * Update memory cache with fresh properties
   */
  private updateMemoryCache(properties: ScrapedProperty[]): void {
    this.memoryCache = [...properties];
    this.lastSuccessfulScrape = new Date();
    console.log(`💾 Updated memory cache with ${properties.length} properties`);
  }

  /**
   * Get properties from memory cache if available and not expired
   */
  public getPropertiesFromCache(): ScrapedProperty[] {
    if (this.memoryCache.length === 0) {
      return [];
    }

    // Check if cache is expired
    if (this.lastSuccessfulScrape) {
      const hoursOld = (Date.now() - this.lastSuccessfulScrape.getTime()) / (1000 * 60 * 60);
      if (hoursOld > this.cacheExpiryHours) {
        console.log(`⏰ Memory cache expired (${hoursOld.toFixed(1)} hours old), clearing cache`);
        this.memoryCache = [];
        return [];
      }
    }

    return [...this.memoryCache];
  }

  /**
   * Get properties with fallback chain: Database → Memory Cache → Empty
   */
  public async getPropertiesWithFallback(): Promise<ScrapedProperty[]> {
    try {
      // First try database
      const dbProperties = await this.getActiveProperties();
      if (dbProperties.length > 0) {
        return dbProperties;
      }
    } catch (error) {
      console.error("Database query failed, trying memory cache:", error);
    }

    // Fallback to memory cache
    const cachedProperties = this.getPropertiesFromCache();
    if (cachedProperties.length > 0) {
      console.log(`📦 Serving ${cachedProperties.length} properties from memory cache`);
      return cachedProperties;
    }

    console.log("⚠️ No properties available from database or cache");
    return [];
  }

  private getFallbackProperties(): ScrapedProperty[] {
    // Use memory cache as fallback
    return this.getPropertiesFromCache();
  }

  public async updateDatabase(properties: ScrapedProperty[]): Promise<void> {
    try {
      console.log(`🗑️ Clearing old properties from database...`);
      // Always clear old properties first to ensure fresh data
      await db.delete(propertyListings);
      
      if (properties.length > 0) {
        // Run quality checks before inserting
        const qualityReport = this.runPropertyQualityChecks(properties);
        if (qualityReport.hasIssues) {
          console.log(`⚠️ Property quality issues detected: ${qualityReport.issues.join(', ')}`);
        }
        
        console.log(`📝 Inserting ${properties.length} fresh properties...`);
        await db.insert(propertyListings).values(properties.map(property => ({
          title: property.title,
          price: property.price,
          beds: property.beds,
          thumbnail: property.thumbnail,
          url: property.url,
          description: property.description,
          scrapedAt: new Date()
        })));
        console.log(`✅ Successfully updated database with ${properties.length} fresh properties`);
        
        if (qualityReport.hasIssues) {
          console.log(`📊 Data quality score: ${qualityReport.score}/10 - Issues found but data inserted`);
        }
      } else {
        console.log(`⚠️ No properties found - database cleared but no new properties added`);
      }
    } catch (error) {
      console.error("❌ Error updating database with properties:", error);
      throw error;
    }
  }

  private runPropertyQualityChecks(properties: ScrapedProperty[]): { hasIssues: boolean; issues: string[]; score: number } {
    const issues: string[] = [];
    let score = 10;

    // Check for duplicates
    const titles = properties.map(p => p.title);
    const uniqueTitles = new Set(titles);
    if (titles.length !== uniqueTitles.size) {
      issues.push("Duplicate property titles detected");
      score -= 3;
    }

    // Check for URL validity
    const invalidUrls = properties.filter(p => !p.url.includes('jtpropertyconsultants.co.uk/property/'));
    if (invalidUrls.length > 0) {
      issues.push(`${invalidUrls.length} properties have invalid URLs`);
      score -= 2;
    }

    // Check for uniform bed counts (likely parsing error)
    const bedCounts = Array.from(new Set(properties.map(p => p.beds)));
    if (bedCounts.length === 1 && properties.length > 3) {
      issues.push("All properties have identical bed info - possible parsing error");
      score -= 4;
    }

    // Check price formatting
    const priceIssues = properties.filter(p => 
      !p.price.match(/^£[\d,]+\s*per\s*month$/i) || p.price.includes(',,')
    );
    if (priceIssues.length > 0) {
      issues.push(`${priceIssues.length} properties have malformed prices`);
      score -= 1;
    }

    return {
      hasIssues: issues.length > 0,
      issues,
      score: Math.max(0, score)
    };
  }

  public async updateDatabaseProperties(): Promise<void> {
    const scrapedProperties = await this.scrapeProperties();
    
    if (scrapedProperties.length === 0) {
      console.log("No properties scraped, skipping database update");
      return;
    }

    console.log("Updating database with scraped properties...");

    try {
      // Mark all existing properties as inactive
      await db.update(propertyListings)
        .set({ isActive: false, updatedAt: new Date() })
        .where(eq(propertyListings.isActive, true));

      // Insert or update scraped properties
      for (const property of scrapedProperties) {
        try {
          // Try to find existing property by URL
          const existing = await db.select()
            .from(propertyListings)
            .where(eq(propertyListings.url, property.url))
            .limit(1);

          if (existing.length > 0) {
            // Update existing property
            await db.update(propertyListings)
              .set({
                title: property.title,
                price: property.price,
                beds: property.beds,
                thumbnail: property.thumbnail,
                description: property.description,
                isActive: true,
                scrapedAt: new Date(),
                updatedAt: new Date()
              })
              .where(eq(propertyListings.url, property.url));
          } else {
            // Insert new property
            await db.insert(propertyListings).values({
              title: property.title,
              price: property.price,
              beds: property.beds,
              thumbnail: property.thumbnail,
              url: property.url,
              description: property.description,
              isActive: true,
              scrapedAt: new Date()
            });
          }
        } catch (error) {
          console.error(`Error updating property ${property.title}:`, error);
        }
      }

      console.log(`Successfully updated ${scrapedProperties.length} properties in database`);
    } catch (error) {
      console.error("Error updating database properties:", error);
    }
  }

  public async getActiveProperties(): Promise<ScrapedProperty[]> {
    try {
      const properties = await db.select()
        .from(propertyListings)
        .where(eq(propertyListings.isActive, true))
        .orderBy(propertyListings.scrapedAt);

      return properties.map(p => ({
        title: p.title,
        price: p.price,
        beds: p.beds,
        thumbnail: p.thumbnail,
        url: p.url,
        description: p.description
      }));
    } catch (error) {
      console.error("Error fetching active properties:", error);
      return this.getFallbackProperties();
    }
  }

  public startScheduledScraping(): void {
    console.log("Starting scheduled property scraping service...");
    
    // Schedule for 5am, 12pm, and 6pm daily with fresh data clearing
    const scheduleNextScrape = () => {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      
      const schedules = [
        new Date(today.getTime() + 5 * 60 * 60 * 1000),  // 5:00 AM
        new Date(today.getTime() + 12 * 60 * 60 * 1000), // 12:00 PM  
        new Date(today.getTime() + 18 * 60 * 60 * 1000)  // 6:00 PM (changed from 8pm)
      ];
      
      // Find next scheduled time
      let nextScrape = schedules.find(time => time > now);
      
      // If no time today, schedule for 5am tomorrow
      if (!nextScrape) {
        nextScrape = new Date(today.getTime() + 24 * 60 * 60 * 1000 + 5 * 60 * 60 * 1000);
      }
      
      const msUntilNext = nextScrape.getTime() - now.getTime();
      
      console.log(`Next property scraping scheduled for: ${nextScrape.toLocaleString()}`);
      
      setTimeout(async () => {
        console.log("🕐 Executing scheduled property refresh (clears old data)...");
        try {
          await this.scrapeProperties(); // This now automatically clears old data first
          console.log("✅ Scheduled refresh completed with fresh data");
        } catch (error) {
          console.error("❌ Scheduled property refresh failed:", error);
        }
        scheduleNextScrape(); // Schedule the next one
      }, msUntilNext);
    };

    // Run initial scraping with fresh data
    this.scrapeProperties().then(() => {
      scheduleNextScrape();
    });
  }
}