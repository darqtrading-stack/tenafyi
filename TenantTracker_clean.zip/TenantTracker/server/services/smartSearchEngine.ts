import { storage } from "../storage";
import type { ApplicationWithNotes } from "@shared/schema";

export interface SearchQuery {
  text: string;
  filters: ParsedFilters;
  results: SearchResult;
}

export interface ParsedFilters {
  // Property and location
  propertyAddress?: string;
  
  // Applicant status
  status?: string[];
  contacted?: boolean;
  
  // Occupation and employment
  occupation?: string[];
  hasJobType?: string;
  hasTaxReturns?: boolean;
  
  // Income filtering
  minIncome?: number;
  maxIncome?: number;
  incomeRange?: { min: number; max: number };
  
  // Guarantor and financial
  hasGuarantor?: boolean;
  hasCCJ?: boolean;
  
  // Lifestyle preferences
  hasPets?: boolean;
  smokes?: boolean;
  
  // Household composition
  adults?: { min?: number; max?: number; exact?: number };
  children?: { min?: number; max?: number; exact?: number };
  isSingle?: boolean;
  hasChildren?: boolean;
  
  // Rental preferences
  rentalPeriod?: string[];
  moveDate?: string[];
  moveUrgency?: string;
  
  // Age and demographics
  ageRange?: { min?: number; max?: number };
  
  // Text search
  searchText?: string;
  
  // Sorting and limits
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
}

export interface SearchResult {
  query: string;
  summary: string;
  totalFound: number;
  applications: ApplicationWithNotes[];
  filters: ParsedFilters;
  timestamp: Date;
  executionTime: number;
}

export class SmartSearchEngine {
  
  // Quick access queries for common searches
  static readonly QUICK_QUERIES = [
    "Show all new applications",
    "High income applicants (£40k+)",
    "Applicants with pets",
    "Families with children", 
    "Self-employed applicants",
    "Moving ASAP",
    "With guarantors",
    "Non-smokers only",
    "Recent applications (last 7 days)",
    "Pending contact"
  ];

  async processQuery(queryText: string): Promise<SearchResult> {
    const startTime = Date.now();
    
    console.log(`🔍 Processing query: "${queryText}"`);
    
    // Parse the natural language query
    const filters = this.parseNaturalLanguage(queryText);
    console.log('📋 Parsed filters:', JSON.stringify(filters, null, 2));
    
    // Get applications from database
    const { applications: allApps } = await storage.getApplications({ limit: 1000 });
    console.log(`📊 Total applications in database: ${allApps.length}`);
    
    // Apply filters
    const filteredApps = this.applyFilters(allApps, filters);
    console.log(`🎯 Filtered to: ${filteredApps.length} applications`);
    
    // Apply sorting and limits
    const finalResults = this.applySortingAndLimits(filteredApps, filters);
    
    // Generate summary
    const summary = this.generateSummary(queryText, finalResults, filters);
    
    const executionTime = Date.now() - startTime;
    
    const result: SearchResult = {
      query: queryText,
      summary,
      totalFound: finalResults.length,
      applications: finalResults,
      filters,
      timestamp: new Date(),
      executionTime
    };
    
    console.log(`✅ Search completed in ${executionTime}ms, returning ${result.totalFound} results`);
    return result;
  }

  private parseNaturalLanguage(query: string): ParsedFilters {
    const lowerQuery = query.toLowerCase();
    const filters: ParsedFilters = {};

    // Property address parsing
    const addressMatch = lowerQuery.match(/(?:for|at|on)\s+(\d+\s+[a-z\s]+(?:street|road|avenue|lane|close|way|drive))/i);
    if (addressMatch) {
      filters.propertyAddress = addressMatch[1];
    }

    // Status parsing
    if (lowerQuery.includes('new application') || lowerQuery.includes('new applicant') || lowerQuery.includes('show all new')) {
      filters.status = ['new'];
    }
    if (lowerQuery.includes('approved')) {
      filters.status = ['approved'];
    }
    if (lowerQuery.includes('viewing')) {
      filters.status = ['viewing-scheduled'];
    }
    if (lowerQuery.includes('contacted') || lowerQuery.includes('reached out')) {
      filters.contacted = !lowerQuery.includes("hasn't") && !lowerQuery.includes("not");
    }

    // Occupation parsing
    if (lowerQuery.includes('self-employed') || lowerQuery.includes('self employed')) {
      filters.occupation = ['self-employed'];
    }
    if (lowerQuery.includes('employed') && !lowerQuery.includes('self') && !lowerQuery.includes('unemployed')) {
      filters.occupation = ['employed'];
    }
    if (lowerQuery.includes('unemployed')) {
      filters.occupation = ['unemployed'];
    }
    if (lowerQuery.includes('student')) {
      filters.occupation = ['student'];
    }
    if (lowerQuery.includes('retired')) {
      filters.occupation = ['retired'];
    }

    // Tax returns for self-employed
    if (lowerQuery.includes('tax return')) {
      if (lowerQuery.includes('without') || lowerQuery.includes('no tax')) {
        filters.hasTaxReturns = false;
      } else {
        filters.hasTaxReturns = true;
      }
    }

    // Income parsing - enhanced patterns
    const incomePatterns = [
      /(?:earn|income|salary).*?(?:over|above|more than|greater than)\s*[£$]?(\d+)k?/,
      /(?:over|above|more than|greater than)\s*[£$]?(\d+)k?.*?(?:earn|income|salary)/,
      /(\d+)k?\+/,
      /[£$](\d+)k?\+/
    ];
    
    for (const pattern of incomePatterns) {
      const match = lowerQuery.match(pattern);
      if (match) {
        const amount = parseInt(match[1]);
        filters.minIncome = amount > 1000 ? amount : amount * 1000;
        break;
      }
    }

    const belowIncomePatterns = [
      /(?:earn|income|salary).*?(?:under|below|less than)\s*[£$]?(\d+)k?/,
      /(?:under|below|less than)\s*[£$]?(\d+)k?.*?(?:earn|income|salary)/
    ];
    
    for (const pattern of belowIncomePatterns) {
      const match = lowerQuery.match(pattern);
      if (match) {
        const amount = parseInt(match[1]);
        filters.maxIncome = amount > 1000 ? amount : amount * 1000;
        break;
      }
    }

    // High/low income shortcuts
    if (lowerQuery.includes('high income') || lowerQuery.includes('high earn')) {
      filters.minIncome = 40000;
    }
    if (lowerQuery.includes('low income') || lowerQuery.includes('low earn')) {
      filters.maxIncome = 25000;
    }

    // Top earners
    const topMatch = lowerQuery.match(/top\s+(\d+)/);
    if (topMatch) {
      filters.limit = parseInt(topMatch[1]);
      filters.sortBy = 'income';
      filters.sortOrder = 'desc';
    }

    // Guarantor parsing
    if (lowerQuery.includes('guarantor')) {
      if (lowerQuery.includes('no guarantor') || lowerQuery.includes('without guarantor')) {
        filters.hasGuarantor = false;
      } else {
        filters.hasGuarantor = true;
      }
    }

    // CCJ parsing
    if (lowerQuery.includes('ccj') || lowerQuery.includes('bad credit')) {
      if (lowerQuery.includes('no ccj') || lowerQuery.includes('without ccj')) {
        filters.hasCCJ = false;
      } else {
        filters.hasCCJ = true;
      }
    }

    // Pets parsing - be more specific to avoid false positives
    if (lowerQuery.includes('has pets') || lowerQuery.includes('with pets') || lowerQuery.includes('pet owner')) {
      filters.hasPets = true;
    } else if (lowerQuery.includes('no pets') || lowerQuery.includes('without pets') || lowerQuery.includes('pet-free')) {
      filters.hasPets = false;
    }

    // Smoking parsing
    if (lowerQuery.includes('smok')) {
      if (lowerQuery.includes('non-smok') || lowerQuery.includes('no smok')) {
        filters.smokes = false;
      } else {
        filters.smokes = true;
      }
    }

    // Household composition
    if (lowerQuery.includes('single') || lowerQuery.includes('individual')) {
      filters.isSingle = true;
      filters.adults = { exact: 1 };
      filters.children = { max: 0 };
    }

    if (lowerQuery.includes('families') || lowerQuery.includes('with children') || lowerQuery.includes('kids')) {
      filters.hasChildren = true;
      filters.children = { min: 1 };
    }

    // Move date parsing
    if (lowerQuery.includes('asap') || lowerQuery.includes('urgent') || lowerQuery.includes('immediate')) {
      filters.moveDate = ['asap'];
    }
    if (lowerQuery.includes('few days')) {
      filters.moveDate = ['few-days'];
    }

    // Age parsing
    const ageMatch = lowerQuery.match(/(?:aged?|age)\s*(?:under|below)\s*(\d+)/);
    if (ageMatch) {
      filters.ageRange = { max: parseInt(ageMatch[1]) };
    }

    // Recent applications
    if (lowerQuery.includes('recent') || lowerQuery.includes('last week') || lowerQuery.includes('last 7 days')) {
      // This would need a date filter in the actual implementation
    }

    // Count queries
    if (lowerQuery.includes('how many') || lowerQuery.includes('count')) {
      filters.sortBy = 'count';
    }

    return filters;
  }

  private applyFilters(applications: ApplicationWithNotes[], filters: ParsedFilters): ApplicationWithNotes[] {
    return applications.filter(app => {
      // Property address filtering
      if (filters.propertyAddress && !app.fullName.toLowerCase().includes(filters.propertyAddress.toLowerCase())) {
        // In real implementation, this would check against a property field
      }

      // Status filtering
      if (filters.status && !filters.status.includes(app.status)) {
        return false;
      }

      // Occupation filtering
      if (filters.occupation && !filters.occupation.includes(app.occupation)) {
        return false;
      }

      // Tax returns (for self-employed)
      if (filters.hasTaxReturns !== undefined && app.occupation === 'self-employed') {
        if (app.hasTaxReturns !== filters.hasTaxReturns) {
          return false;
        }
      }

      // Income filtering
      if (filters.minIncome && Number(app.annualIncome) < filters.minIncome) {
        return false;
      }
      if (filters.maxIncome && Number(app.annualIncome) > filters.maxIncome) {
        return false;
      }

      // Guarantor filtering
      if (filters.hasGuarantor !== undefined && app.hasGuarantor !== filters.hasGuarantor) {
        return false;
      }

      // CCJ filtering (fix field name)
      if (filters.hasCCJ !== undefined && app.hasCCJIVA !== filters.hasCCJ) {
        return false;
      }

      // Pets filtering
      if (filters.hasPets !== undefined && app.hasPets !== filters.hasPets) {
        return false;
      }

      // Smoking filtering
      if (filters.smokes !== undefined && app.smokes !== filters.smokes) {
        return false;
      }

      // Household composition
      if (filters.isSingle && (app.adults !== 1 || (app.children || 0) > 0)) {
        return false;
      }

      if (filters.hasChildren && (app.children || 0) < 1) {
        return false;
      }

      if (filters.adults?.exact && app.adults !== filters.adults.exact) {
        return false;
      }

      if (filters.children?.min && (app.children || 0) < filters.children.min) {
        return false;
      }

      if (filters.children?.max && (app.children || 0) > filters.children.max) {
        return false;
      }

      // Move date filtering
      if (filters.moveDate && !filters.moveDate.includes(app.moveDate)) {
        return false;
      }

      return true;
    });
  }

  private applySortingAndLimits(applications: ApplicationWithNotes[], filters: ParsedFilters): ApplicationWithNotes[] {
    let result = [...applications];

    // Apply sorting
    if (filters.sortBy === 'income') {
      result.sort((a, b) => {
        const diff = Number(b.annualIncome) - Number(a.annualIncome);
        return filters.sortOrder === 'asc' ? -diff : diff;
      });
    } else if (filters.sortBy === 'name') {
      result.sort((a, b) => a.fullName.localeCompare(b.fullName));
    } else {
      // Default sort by creation date (newest first)
      result.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    }

    // Apply limit
    if (filters.limit && filters.limit > 0) {
      result = result.slice(0, filters.limit);
    }

    return result;
  }

  private generateSummary(query: string, applications: ApplicationWithNotes[], filters: ParsedFilters): string {
    const count = applications.length;
    
    if (count === 0) {
      return "No applications found matching your search criteria.";
    }

    let summary = `Found ${count} application${count !== 1 ? 's' : ''}`;

    // Add filter descriptions
    const descriptions: string[] = [];
    
    if (filters.minIncome) {
      descriptions.push(`income £${filters.minIncome.toLocaleString()}+`);
    }
    if (filters.maxIncome) {
      descriptions.push(`income under £${filters.maxIncome.toLocaleString()}`);
    }
    if (filters.occupation) {
      descriptions.push(`${filters.occupation.join(', ')} workers`);
    }
    if (filters.hasPets === true) {
      descriptions.push('with pets');
    }
    if (filters.hasPets === false) {
      descriptions.push('without pets');
    }
    if (filters.hasGuarantor === true) {
      descriptions.push('with guarantors');
    }
    if (filters.hasGuarantor === false) {
      descriptions.push('without guarantors');
    }
    if (filters.hasChildren) {
      descriptions.push('with children');
    }
    if (filters.isSingle) {
      descriptions.push('single applicants');
    }
    if (filters.moveDate?.includes('asap')) {
      descriptions.push('moving ASAP');
    }
    if (filters.smokes === false) {
      descriptions.push('non-smokers');
    }
    if (filters.hasCCJ === false) {
      descriptions.push('no CCJ/IVA');
    }

    if (descriptions.length > 0) {
      summary += ` matching: ${descriptions.join(', ')}`;
    }

    // Add income statistics
    if (count > 0) {
      const incomes = applications.map(app => Number(app.annualIncome));
      const avgIncome = incomes.reduce((a, b) => a + b, 0) / incomes.length;
      const maxIncome = Math.max(...incomes);
      const minIncome = Math.min(...incomes);
      
      summary += `. Average income: £${Math.round(avgIncome).toLocaleString()}`;
      if (count > 1) {
        summary += ` (range: £${minIncome.toLocaleString()} - £${maxIncome.toLocaleString()})`;
      }
    }

    return summary;
  }

  async generateQuickQueries(): Promise<string[]> {
    const { applications } = await storage.getApplications({ limit: 1000 });
    const suggestions: string[] = [...SmartSearchEngine.QUICK_QUERIES];
    
    // Add dynamic suggestions based on data
    const stats = this.generateDataStats(applications);
    
    if (stats.highIncomeCount > 0) {
      suggestions.push(`${stats.highIncomeCount} high earners (£40k+)`);
    }
    if (stats.petOwners > 0) {
      suggestions.push(`${stats.petOwners} applicants with pets`);
    }
    if (stats.families > 0) {
      suggestions.push(`${stats.families} families with children`);
    }
    
    return suggestions.slice(0, 10);
  }

  private generateDataStats(applications: ApplicationWithNotes[]) {
    return {
      total: applications.length,
      highIncomeCount: applications.filter(app => Number(app.annualIncome) > 40000).length,
      petOwners: applications.filter(app => app.hasPets).length,
      families: applications.filter(app => (app.children || 0) > 0).length,
      selfEmployed: applications.filter(app => app.occupation === 'self-employed').length,
      urgent: applications.filter(app => app.moveDate === 'asap').length
    };
  }
}

export const smartSearchEngine = new SmartSearchEngine();