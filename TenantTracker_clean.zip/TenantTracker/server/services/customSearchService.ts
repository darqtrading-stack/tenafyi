import { storage } from "../storage";
import type { ApplicationWithNotes } from "@shared/schema";

export interface SearchResult {
  query: string;
  summary: string;
  data: ApplicationWithNotes[];
  queryType: 'filter' | 'count' | 'summary' | 'analysis';
  timestamp: Date;
  filters: SearchFilters;
}

export interface SearchFilters {
  minIncome?: number;
  maxIncome?: number;
  occupation?: string[];
  hasPets?: boolean;
  hasGuarantor?: boolean;
  moveDate?: string[];
  status?: string[];
  adults?: { min?: number; max?: number };
  children?: { min?: number; max?: number };
  smokes?: boolean;
  hasCCJ?: boolean;
  searchText?: string;
}

export class CustomSearchService {
  
  // Pre-defined smart queries for quick access
  static readonly SMART_QUERIES = [
    "Show high income applicants (£40k+)",
    "Find families with children",
    "List applicants with pets", 
    "Show self-employed applicants",
    "Find urgent movers (ASAP)",
    "List applicants with guarantors",
    "Show non-smokers only",
    "Find approved applications",
    "List pending applications",
    "Show recent applications (last 7 days)"
  ];

  async processQuery(query: string, userId: string): Promise<SearchResult> {
    console.log(`Custom Search Query from ${userId}: ${query}`);
    
    const filters = this.parseQuery(query);
    console.log('Parsed filters:', filters);
    
    const applications = await this.searchApplications(filters);
    console.log(`Found ${applications.length} applications`);
    
    const result: SearchResult = {
      query,
      summary: this.generateSummary(query, applications, filters),
      data: applications,
      queryType: this.determineQueryType(query),
      timestamp: new Date(),
      filters
    };

    console.log('Returning result:', { query: result.query, dataCount: result.data.length, summary: result.summary });
    return result;
  }

  private parseQuery(query: string): SearchFilters {
    const lowerQuery = query.toLowerCase();
    const filters: SearchFilters = {};

    // Income patterns
    const incomeMatch = lowerQuery.match(/(\d+)k?\+?|\bover\s+[£$]?(\d+)k?|\babove\s+[£$]?(\d+)k?/);
    if (incomeMatch) {
      const amount = parseInt(incomeMatch[1] || incomeMatch[2] || incomeMatch[3]);
      filters.minIncome = amount > 1000 ? amount : amount * 1000;
    }

    const maxIncomeMatch = lowerQuery.match(/under\s+[£$]?(\d+)k?|\bbelow\s+[£$]?(\d+)k?|\bless\s+than\s+[£$]?(\d+)k?/);
    if (maxIncomeMatch) {
      const amount = parseInt(maxIncomeMatch[1]);
      filters.maxIncome = amount > 1000 ? amount : amount * 1000;
    }

    // High income patterns
    if (lowerQuery.includes('high income') || lowerQuery.includes('high earning')) {
      filters.minIncome = 40000;
    }
    if (lowerQuery.includes('low income')) {
      filters.maxIncome = 25000;
    }

    // Occupation patterns
    if (lowerQuery.includes('self-employed') || lowerQuery.includes('self employed')) {
      filters.occupation = ['self-employed'];
    }
    if (lowerQuery.includes('employed') && !lowerQuery.includes('self')) {
      filters.occupation = ['employed'];
    }
    if (lowerQuery.includes('student')) {
      filters.occupation = ['student'];
    }
    if (lowerQuery.includes('retired')) {
      filters.occupation = ['retired'];
    }

    // Pets and lifestyle
    if (lowerQuery.includes('pet') || lowerQuery.includes('dog') || lowerQuery.includes('cat')) {
      filters.hasPets = true;
    }
    if (lowerQuery.includes('no pets') || lowerQuery.includes('pet-free')) {
      filters.hasPets = false;
    }

    // Smoking
    if (lowerQuery.includes('non-smoker') || lowerQuery.includes('no smoking')) {
      filters.smokes = false;
    }
    if (lowerQuery.includes('smoker') && !lowerQuery.includes('non')) {
      filters.smokes = true;
    }

    // Guarantor
    if (lowerQuery.includes('guarantor')) {
      filters.hasGuarantor = true;
    }
    if (lowerQuery.includes('no guarantor')) {
      filters.hasGuarantor = false;
    }

    // Move date patterns
    if (lowerQuery.includes('asap') || lowerQuery.includes('urgent') || lowerQuery.includes('immediate')) {
      filters.moveDate = ['asap'];
    }
    if (lowerQuery.includes('few days')) {
      filters.moveDate = ['few-days'];
    }

    // Family patterns
    if (lowerQuery.includes('family') || lowerQuery.includes('families') || lowerQuery.includes('children') || lowerQuery.includes('kids')) {
      filters.children = { min: 1 };
    }
    if (lowerQuery.includes('single') || lowerQuery.includes('individual')) {
      filters.adults = { max: 1 };
      filters.children = { max: 0 };
    }

    // Status patterns
    if (lowerQuery.includes('approved')) {
      filters.status = ['approved'];
    }
    if (lowerQuery.includes('pending') || lowerQuery.includes('new')) {
      filters.status = ['new'];
    }
    if (lowerQuery.includes('viewing')) {
      filters.status = ['viewing-scheduled'];
    }

    // CCJ patterns
    if (lowerQuery.includes('ccj') || lowerQuery.includes('bad credit')) {
      filters.hasCCJ = true;
    }

    // General text search for names, emails, etc.
    const textMatch = lowerQuery.match(/find\s+"([^"]+)"|search\s+"([^"]+)"|name\s+"([^"]+)"/);
    if (textMatch) {
      filters.searchText = textMatch[1] || textMatch[2] || textMatch[3];
    }

    return filters;
  }

  private async searchApplications(filters: SearchFilters): Promise<ApplicationWithNotes[]> {
    // Get all applications first
    const { applications } = await storage.getApplications({ limit: 1000 });
    console.log(`Total applications in database: ${applications.length}`);
    
    // If no filters are applied, return all applications
    if (Object.keys(filters).length === 0) {
      console.log('No filters applied, returning all applications');
      return applications;
    }
    
    const filtered = applications.filter(app => {
      // Income filtering
      if (filters.minIncome && Number(app.annualIncome) < filters.minIncome) return false;
      if (filters.maxIncome && Number(app.annualIncome) > filters.maxIncome) return false;

      // Occupation filtering
      if (filters.occupation && !filters.occupation.includes(app.occupation)) return false;

      // Lifestyle filtering
      if (filters.hasPets !== undefined && app.hasPets !== filters.hasPets) return false;
      if (filters.smokes !== undefined && app.smokes !== filters.smokes) return false;
      if (filters.hasGuarantor !== undefined && app.hasGuarantor !== filters.hasGuarantor) return false;
      if (filters.hasCCJ !== undefined && app.hasCCJIVA !== filters.hasCCJ) return false;

      // Move date filtering
      if (filters.moveDate && !filters.moveDate.includes(app.moveDate)) return false;

      // Status filtering
      if (filters.status && !filters.status.includes(app.status)) return false;

      // Household size filtering
      if (filters.adults?.min && app.adults < filters.adults.min) return false;
      if (filters.adults?.max && app.adults > filters.adults.max) return false;
      if (filters.children?.min && (app.children || 0) < filters.children.min) return false;
      if (filters.children?.max && (app.children || 0) > filters.children.max) return false;

      // Text search in names and emails
      if (filters.searchText) {
        const searchLower = filters.searchText.toLowerCase();
        const matchesText = 
          app.fullName.toLowerCase().includes(searchLower) ||
          app.email.toLowerCase().includes(searchLower) ||
          app.phone.includes(searchLower);
        if (!matchesText) return false;
      }

      return true;
    });
    
    console.log(`Filtered to ${filtered.length} applications`);
    return filtered;
  }

  private determineQueryType(query: string): 'filter' | 'count' | 'summary' | 'analysis' {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('how many') || lowerQuery.includes('count') || lowerQuery.includes('number of')) {
      return 'count';
    }
    if (lowerQuery.includes('analyze') || lowerQuery.includes('analysis') || lowerQuery.includes('breakdown')) {
      return 'analysis';
    }
    if (lowerQuery.includes('summary') || lowerQuery.includes('summarize') || lowerQuery.includes('overview')) {
      return 'summary';
    }
    
    return 'filter';
  }

  private generateSummary(query: string, applications: ApplicationWithNotes[], filters: SearchFilters): string {
    const count = applications.length;
    
    if (count === 0) {
      return `No applications found matching your search criteria.`;
    }

    let summary = `Found ${count} application${count !== 1 ? 's' : ''}`;

    // Add specific details based on filters
    const details: string[] = [];
    
    if (filters.minIncome) {
      details.push(`income £${filters.minIncome.toLocaleString()}+`);
    }
    if (filters.occupation) {
      details.push(`${filters.occupation.join(', ')} workers`);
    }
    if (filters.hasPets === true) {
      details.push('with pets');
    }
    if (filters.hasPets === false) {
      details.push('without pets');
    }
    if (filters.hasGuarantor === true) {
      details.push('with guarantors');
    }
    if (filters.children?.min) {
      details.push('with children');
    }
    if (filters.moveDate?.includes('asap')) {
      details.push('moving ASAP');
    }
    if (filters.status) {
      details.push(`status: ${filters.status.join(', ')}`);
    }

    if (details.length > 0) {
      summary += ` ${details.join(', ')}`;
    }

    // Add income statistics
    if (count > 0) {
      const incomes = applications.map(app => Number(app.annualIncome));
      const avgIncome = incomes.reduce((a, b) => a + b, 0) / incomes.length;
      const maxIncome = Math.max(...incomes);
      const minIncome = Math.min(...incomes);
      
      summary += `. Average income: £${Math.round(avgIncome).toLocaleString()}`;
      if (count > 1) {
        summary += ` (range: £${minIncome.toLocaleString()} - £${maxIncome.toLocaleString()})`;
      }
    }

    return summary;
  }

  async generateSuggestedQueries(applications: ApplicationWithNotes[]): Promise<string[]> {
    const suggestions: string[] = [];
    const total = applications.length;
    
    if (total === 0) return CustomSearchService.SMART_QUERIES;

    // Dynamic suggestions based on current data
    const highIncomeCount = applications.filter(app => Number(app.annualIncome) > 40000).length;
    const petsCount = applications.filter(app => app.hasPets).length;
    const familiesCount = applications.filter(app => (app.children || 0) > 0).length;
    const urgentCount = applications.filter(app => app.moveDate === 'asap').length;
    const selfEmployedCount = applications.filter(app => app.occupation === 'self-employed').length;

    if (highIncomeCount > 0) {
      suggestions.push(`Show ${highIncomeCount} high income applicants (£40k+)`);
    }
    if (petsCount > 0) {
      suggestions.push(`Find ${petsCount} applicants with pets`);
    }
    if (familiesCount > 0) {
      suggestions.push(`List ${familiesCount} families with children`);
    }
    if (urgentCount > 0) {
      suggestions.push(`Show ${urgentCount} urgent movers (ASAP)`);
    }
    if (selfEmployedCount > 0) {
      suggestions.push(`Find ${selfEmployedCount} self-employed applicants`);
    }

    // Add some general queries
    suggestions.push("Show non-smokers only");
    suggestions.push("Find applicants with guarantors");
    suggestions.push("List pending applications");

    return suggestions.slice(0, 8); // Limit to 8 suggestions
  }
}

export const customSearchService = new CustomSearchService();