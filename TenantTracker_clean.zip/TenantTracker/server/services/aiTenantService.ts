import OpenAI from 'openai';
import { rulesEngine, type IncomeSource } from './rulesEngine';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

interface ConversationContext {
  sessionId: string;
  messages: ChatMessage[];
  applicationData: Record<string, any>;
  propertyData?: any;
  incomeData: IncomeSource[];
}

export class AITenantService {
  private static instance: AITenantService;
  private activeConversations: Map<string, ConversationContext> = new Map();
  private readonly MAX_MESSAGES_PER_SESSION = 50;
  private readonly SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes

  private constructor() {}

  public static getInstance(): AITenantService {
    if (!AITenantService.instance) {
      AITenantService.instance = new AITenantService();
    }
    return AITenantService.instance;
  }

  /**
   * Initialize a new conversation session
   */
  async startConversation(sessionId: string, properties: any[]): Promise<ChatMessage> {
    const systemPrompt = this.buildSystemPrompt(properties);
    
    const context: ConversationContext = {
      sessionId,
      messages: [
        {
          role: 'system',
          content: systemPrompt,
          timestamp: new Date().toISOString(),
        },
      ],
      applicationData: {},
      incomeData: [],
    };

    this.activeConversations.set(sessionId, context);

    // Set session timeout
    setTimeout(() => {
      this.activeConversations.delete(sessionId);
      console.log(`🕐 Session ${sessionId} timed out and cleaned up`);
    }, this.SESSION_TIMEOUT_MS);

    const welcomeMessage: ChatMessage = {
      role: 'assistant',
      content: `Hello! I'm here to help you with your tenancy application. I'll guide you through the process and answer any questions you have about our available properties. Let's start by finding the right property for you. Which property are you interested in?`,
      timestamp: new Date().toISOString(),
    };

    context.messages.push(welcomeMessage);

    return welcomeMessage;
  }

  /**
   * Process a user message and get AI response
   */
  async chat(sessionId: string, userMessage: string): Promise<ChatMessage> {
    const context = this.activeConversations.get(sessionId);
    
    if (!context) {
      throw new Error('Session not found or expired. Please start a new conversation.');
    }

    if (context.messages.length >= this.MAX_MESSAGES_PER_SESSION) {
      throw new Error('Message limit reached for this session. Please complete your application or start a new one.');
    }

    // Add user message to context
    context.messages.push({
      role: 'user',
      content: userMessage,
      timestamp: new Date().toISOString(),
    });

    try {
      // Call OpenAI API
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: context.messages.map(msg => ({
          role: msg.role,
          content: msg.content,
        })),
        temperature: 0.7,
        max_tokens: 500,
      });

      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: completion.choices[0]?.message?.content || 'I apologize, I encountered an error. Please try again.',
        timestamp: new Date().toISOString(),
      };

      context.messages.push(assistantMessage);

      return assistantMessage;
    } catch (error: any) {
      console.error('OpenAI API error:', error);
      throw new Error(`AI service error: ${error.message}`);
    }
  }

  /**
   * Build system prompt with property data and rules
   */
  private buildSystemPrompt(properties: any[]): string {
    const propertyList = properties.map((p, idx) => 
      `${idx + 1}. ${p.title} - ${p.price} (${p.beds})`
    ).join('\n');

    return `You are a helpful and professional property letting assistant for a UK letting agency. Your role is to:

1. **Guide applicants through the tenancy application process** in a conversational, friendly manner
2. **Collect required information** step by step (name, property interest, household size, income, etc.)
3. **Calculate income requirements** using the rule: monthly rent × 30 = required annual income
4. **Handle multiple adults**: Ask for each adult's income separately and sum them up
5. **Understand employment types**:
   - Employed: Use annual salary
   - Self-employed: Ask for PROFIT from tax returns, not turnover
   - Benefits: Accept as valid income source
   - Students/Retired: May need guarantor
6. **Income assessment**:
   - If total income meets requirement: Congratulate them
   - If income is 0-20% short: Politely suggest they may need a UK guarantor
   - If income is >20% short: Politely explain they're welcome to continue but approval may be difficult
7. **Answer property questions** ONLY from this data - never make up facts:
${propertyList}

8. **Never assume or invent** property details (EPC ratings, amenities, etc.) not provided
9. **Be professional but warm** - use everyday language, avoid jargon
10. **Keep responses concise** - 2-3 sentences max unless explaining income calculations

Available properties:
${propertyList}

Remember: Be helpful, never judgmental. Everyone is welcome to apply regardless of their financial situation.`;
  }

  /**
   * Update conversation context with collected data
   */
  updateApplicationData(sessionId: string, key: string, value: any): void {
    const context = this.activeConversations.get(sessionId);
    if (context) {
      context.applicationData[key] = value;
    }
  }

  /**
   * Add income source to conversation context
   */
  addIncomeSource(sessionId: string, incomeSource: IncomeSource): void {
    const context = this.activeConversations.get(sessionId);
    if (context) {
      context.incomeData.push(incomeSource);
    }
  }

  /**
   * Get conversation history
   */
  getConversation(sessionId: string): ConversationContext | null {
    return this.activeConversations.get(sessionId) || null;
  }

  /**
   * Save conversation transcript (will be linked to application when submitted)
   */
  async saveTranscript(sessionId: string, applicationId?: number): Promise<void> {
    const context = this.activeConversations.get(sessionId);
    if (!context) return;

    // TODO: Save to database when available
    console.log(`💾 Conversation transcript saved for session ${sessionId}`, {
      messageCount: context.messages.length,
      applicationId,
    });
  }

  /**
   * Clean up expired sessions
   */
  cleanup(): void {
    // Timeout handles this automatically
  }
}

export const aiTenantService = AITenantService.getInstance();
