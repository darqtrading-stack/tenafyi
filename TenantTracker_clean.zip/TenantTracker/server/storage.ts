import {
  users,
  applications,
  notes,
  type User,
  type UpsertUser,
  type Application,
  type InsertApplication,
  type ApplicationWithNotes,
  type Note,
  type InsertNote,
  type UpdateApplicationStatus,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, ilike, and, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Application operations
  createApplication(application: InsertApplication): Promise<Application>;
  getApplications(filters?: {
    search?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ applications: ApplicationWithNotes[]; total: number }>;
  getApplication(id: number): Promise<ApplicationWithNotes | undefined>;
  updateApplicationStatus(id: number, status: UpdateApplicationStatus): Promise<Application | undefined>;
  
  // Notes operations
  addNote(note: InsertNote & { userId: string }): Promise<Note>;
  getApplicationNotes(applicationId: number): Promise<(Note & { user: User })[]>;
  
  // Statistics
  getApplicationStats(): Promise<{
    total: number;
    pending: number;
    viewingsScheduled: number;
    approved: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Application operations
  async createApplication(application: InsertApplication): Promise<Application> {
    const [newApplication] = await db
      .insert(applications)
      .values(application)
      .returning();
    return newApplication;
  }

  async getApplications(filters: {
    search?: string;
    status?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<{ applications: ApplicationWithNotes[]; total: number }> {
    const { search, status, limit = 10, offset = 0 } = filters;
    
    let whereClause = undefined;
    
    if (search || status) {
      const conditions = [];
      if (search) {
        conditions.push(
          ilike(applications.fullName, `%${search}%`),
          ilike(applications.email, `%${search}%`)
        );
      }
      if (status) {
        conditions.push(eq(applications.status, status));
      }
      whereClause = search && status 
        ? and(eq(applications.status, status), ilike(applications.fullName, `%${search}%`))
        : conditions[0];
    }

    // Get total count
    const [{ count: total }] = await db
      .select({ count: count() })
      .from(applications)
      .where(whereClause);

    // Get applications with notes
    const applicationsData = await db.query.applications.findMany({
      where: whereClause,
      with: {
        notes: {
          with: {
            user: true,
          },
          orderBy: [desc(notes.createdAt)],
        },
      },
      orderBy: [desc(applications.createdAt)],
      limit,
      offset,
    });

    return {
      applications: applicationsData,
      total,
    };
  }

  async getApplication(id: number): Promise<ApplicationWithNotes | undefined> {
    const application = await db.query.applications.findFirst({
      where: eq(applications.id, id),
      with: {
        notes: {
          with: {
            user: true,
          },
          orderBy: [desc(notes.createdAt)],
        },
      },
    });

    return application;
  }

  async updateApplicationStatus(id: number, statusUpdate: UpdateApplicationStatus): Promise<Application | undefined> {
    const [updatedApplication] = await db
      .update(applications)
      .set({ 
        status: statusUpdate.status,
        updatedAt: new Date(),
      })
      .where(eq(applications.id, id))
      .returning();
    return updatedApplication;
  }

  // Notes operations
  async addNote(noteData: InsertNote & { userId: string }): Promise<Note> {
    const [note] = await db
      .insert(notes)
      .values(noteData)
      .returning();
    return note;
  }

  async getApplicationNotes(applicationId: number): Promise<(Note & { user: User })[]> {
    const applicationNotes = await db.query.notes.findMany({
      where: eq(notes.applicationId, applicationId),
      with: {
        user: true,
      },
      orderBy: [desc(notes.createdAt)],
    });

    return applicationNotes;
  }

  // Statistics
  async getApplicationStats(): Promise<{
    total: number;
    pending: number;
    viewingsScheduled: number;
    approved: number;
  }> {
    const [totalResult] = await db
      .select({ count: count() })
      .from(applications);

    const [pendingResult] = await db
      .select({ count: count() })
      .from(applications)
      .where(eq(applications.status, 'new'));

    const [viewingsResult] = await db
      .select({ count: count() })
      .from(applications)
      .where(eq(applications.status, 'viewing-arranged'));

    const [approvedResult] = await db
      .select({ count: count() })
      .from(applications)
      .where(eq(applications.status, 'approved'));

    return {
      total: totalResult.count,
      pending: pendingResult.count,
      viewingsScheduled: viewingsResult.count,
      approved: approvedResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
