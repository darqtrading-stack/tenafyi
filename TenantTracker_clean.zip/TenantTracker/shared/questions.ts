// Unified question structure for both bot and form
export interface Question {
  id: string;
  text: string;
  type: 'text' | 'email' | 'tel' | 'number' | 'select' | 'radio' | 'textarea';
  required: boolean;
  options?: string[];
  placeholder?: string;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    message?: string;
  };
  subQuestions?: Question[];
  showSubQuestionIf?: (answer: any) => boolean;
  step: number;
  botStep?: number;
  formField: string;
}

export const unifiedQuestions: Question[] = [
  // Step 1: Property & Basic Details
  {
    id: 'property',
    text: 'Which property are you interested in?',
    type: 'select',
    required: true,
    options: [
      '4 bed bungalow to rent in New Barn Road, Longfield, DA3 7JE',
      '4 bed detached house to rent in Broadacre View',
      '4 bed chalet to rent in Ufton Lane, Sittingbourne, Kent, ME10 1EU',
      'Shop to rent in Sidcup Road, London, SE9 3NS',
      '2 bed flat to rent in Russet Walk, Greenhithe, DA9 9WY',
      '2 bed ground floor flat to rent in Henshaaws Vale, Sittingbourne, Kent, ME10 3NY',
      '1 bed flat to rent in Park Road, Sittingbourne, ME10 1DY',
      '1 bed flat to rent in Portland Avenue, Sittingbourne, Kent, ME10 3QZ'
    ],
    placeholder: 'Select a property from JT Property Consultants',
    step: 1,
    botStep: 1,
    formField: 'property'
  },
  {
    id: 'fullName',
    text: 'What is your full name?',
    type: 'text',
    required: true,
    placeholder: 'e.g. John Smith',
    validation: {
      min: 2,
      message: 'Please enter your full name'
    },
    step: 1,
    botStep: 2,
    formField: 'fullName'
  },
  {
    id: 'adults',
    text: 'How many adults aged 18 or over will be living at the property?',
    type: 'number',
    required: true,
    placeholder: 'e.g. 2',
    validation: {
      min: 1,
      max: 10,
      message: 'Please enter a valid number of adults (1-10)'
    },
    step: 1,
    botStep: 3,
    formField: 'adults'
  },
  {
    id: 'children',
    text: 'How many children under 18 will be living there?',
    type: 'number',
    required: false,
    placeholder: 'e.g. 1 (or 0 for none)',
    validation: {
      min: 0,
      max: 10,
      message: 'Please enter a valid number of children (0-10)'
    },
    step: 1,
    botStep: 4,
    formField: 'children'
  },
  {
    id: 'moveDate',
    text: 'When would you like to move in?',
    type: 'select',
    required: true,
    options: ['ASAP', 'Within 2 weeks', 'I need to give one months notice'],
    step: 1,
    botStep: 4.5,
    formField: 'moveDate'
  },
  {
    id: 'rentalPeriod',
    text: 'How long do you want to rent for?',
    type: 'select',
    required: true,
    options: ['6 months', '1 year', '2+ years'],
    step: 1,
    botStep: undefined, // Bot calculates this differently
    formField: 'rentalPeriod'
  },

  // Step 2: Lifestyle Questions
  {
    id: 'hasPets',
    text: 'Do you have any pets?',
    type: 'select',
    required: true,
    options: ['Yes', 'No'],
    step: 2,
    botStep: 9,
    formField: 'hasPets',
    subQuestions: [
      {
        id: 'petDetails',
        text: 'Please tell us about your pets (type, breed, age, etc.)',
        type: 'textarea',
        required: false,
        placeholder: 'e.g. 1 medium dog (Golden Retriever, 3 years old)',
        validation: {
          min: 3,
          message: 'Please provide details about your pets'
        },
        step: 2,
        botStep: 9.5,
        formField: 'petDetails'
      }
    ],
    showSubQuestionIf: (answer) => answer === 'Yes' || answer === true
  },
  {
    id: 'smokes',
    text: 'Do you smoke?',
    type: 'select',
    required: true,
    options: ['Yes', 'No'],
    step: 2,
    botStep: 10,
    formField: 'smokes'
  },
  {
    id: 'occupation',
    text: 'What is your employment status?',
    type: 'select',
    required: true,
    options: ['Employed', 'Self-Employed', 'Student', 'Unemployed', 'Retired'],
    step: 2,
    botStep: 7,
    formField: 'occupation',
    subQuestions: [
      {
        id: 'hasTaxReturns',
        text: 'Do you have at least 1 year of tax returns?',
        type: 'select',
        required: false,
        options: ['Yes', 'No'],
        step: 2,
        botStep: 8,
        formField: 'hasTaxReturns'
      }
    ],
    showSubQuestionIf: (answer) => answer === 'Self-Employed'
  },

  // Step 3: Financial Information
  {
    id: 'annualIncome',
    text: 'What is your total yearly income before tax?',
    type: 'number',
    required: true,
    placeholder: 'Enter amount in £',
    validation: {
      min: 0,
      message: 'Please enter a valid income amount'
    },
    step: 3,
    botStep: 12,
    formField: 'annualIncome'
  },
  {
    id: 'hasCCJIVA',
    text: 'Do you have any adverse credit history (CCJs, IVAs, defaults)?',
    type: 'select',
    required: true,
    options: ['Yes', 'No', "I don't know"],
    step: 3,
    botStep: 11,
    formField: 'hasCCJIVA'
  },
  {
    id: 'hasAdverseMedia',
    text: 'Do you have any adverse media?',
    type: 'select',
    required: false,
    options: ['Yes', 'No', "I don't know"],
    step: 3,
    botStep: 11.5,
    formField: 'hasAdverseMedia'
  },
  {
    id: 'hasGuarantor',
    text: 'Can you provide a UK-based guarantor if needed?',
    type: 'select',
    required: true,
    options: ['Yes', 'No', 'Not needed'],
    step: 3,
    botStep: 12,
    formField: 'hasGuarantor'
  },
  {
    id: 'noticePeriod',
    text: 'How many weeks notice do you need to give your current landlord or agent?',
    type: 'text',
    required: true,
    placeholder: 'e.g. 4, 8, 12, or write "none", "zero", or "0"',
    validation: {
      min: 0,
      max: 52,
      message: 'Please enter a valid notice period in weeks (0-52) or "none"'
    },
    step: 3,
    botStep: 13,
    formField: 'noticePeriod'
  },

  // Step 4: Contact Information
  {
    id: 'email',
    text: 'What is your email address?',
    type: 'email',
    required: true,
    placeholder: 'your.email@example.com',
    validation: {
      pattern: '^[^@]+@[^@]+\\.[^@]+$',
      message: 'Please enter a valid email address'
    },
    step: 4,
    botStep: 14,
    formField: 'email'
  },
  {
    id: 'phone',
    text: 'What is your mobile number?',
    type: 'tel',
    required: true,
    placeholder: 'e.g. 07123 456789',
    validation: {
      min: 10,
      message: 'Please enter a valid mobile number'
    },
    step: 4,
    botStep: 15,
    formField: 'phone'
  },
  {
    id: 'contactMethod',
    text: 'How would you prefer us to contact you?',
    type: 'select',
    required: true,
    options: ['Phone', 'Email', 'Either'],
    step: 4,
    botStep: 16,
    formField: 'contactMethod'
  },
  {
    id: 'additionalDetails',
    text: 'Please provide any additional information for your application',
    type: 'textarea',
    required: false,
    placeholder: 'e.g. viewing preferences, specific requirements, move-in date...',
    validation: {
      min: 3,
      message: 'Please provide some additional information (minimum 3 characters)'
    },
    step: 4,
    botStep: 17,
    formField: 'additionalDetails'
  },
  {
    id: 'consent',
    text: 'Do you consent to us processing your data for this rental application?',
    type: 'select',
    required: true,
    options: ['Yes, I consent', 'No'],
    step: 4,
    botStep: 18,
    formField: 'consent'
  }
];

export const getQuestionsByStep = (step: number): Question[] => {
  return unifiedQuestions.filter(q => q.step === step);
};

export const getQuestionByBotStep = (botStep: number): Question | undefined => {
  return unifiedQuestions.find(q => q.botStep === botStep);
};

export const getQuestionById = (id: string): Question | undefined => {
  return unifiedQuestions.find(q => q.id === id);
};

export const getSubQuestions = (parentQuestion: Question, parentAnswer: any): Question[] => {
  if (!parentQuestion.subQuestions || !parentQuestion.showSubQuestionIf) {
    return [];
  }
  
  return parentQuestion.showSubQuestionIf(parentAnswer) ? parentQuestion.subQuestions : [];
};

export const validateAnswer = (question: Question, answer: any): { isValid: boolean; message?: string } => {
  // For required fields, check if answer exists
  if (question.required) {
    // Handle boolean fields specially (false is a valid answer)
    if (question.formField === 'hasPets' || question.formField === 'smokes' || question.formField === 'hasTaxReturns') {
      if (answer === undefined || answer === null) {
        return { isValid: false, message: `${question.text} is required` };
      }
    } else {
      // For other fields, check for empty/missing values
      if (!answer || (typeof answer === 'string' && answer.trim() === '') || (typeof answer === 'number' && isNaN(answer))) {
        return { isValid: false, message: `${question.text} is required` };
      }
    }
  }

  if (question.validation) {
    const { min, max, pattern, message } = question.validation;
    
    if (typeof answer === 'string') {
      if (min && answer.length < min) {
        return { isValid: false, message: message || `Minimum ${min} characters required` };
      }
      
      if (pattern && !new RegExp(pattern).test(answer)) {
        return { isValid: false, message: message || 'Invalid format' };
      }
    }
    
    if (typeof answer === 'number') {
      if (min !== undefined && answer < min) {
        return { isValid: false, message: message || `Minimum value is ${min}` };
      }
      
      if (max !== undefined && answer > max) {
        return { isValid: false, message: message || `Maximum value is ${max}` };
      }
    }
  }

  return { isValid: true };
};