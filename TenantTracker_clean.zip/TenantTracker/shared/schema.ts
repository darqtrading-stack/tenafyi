import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  decimal,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tenant applications table
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  // Personal details
  fullName: varchar("full_name").notNull(),
  email: varchar("email").notNull(),
  phone: varchar("phone").notNull(),
  
  // Household information
  moveDate: varchar("move_date").notNull(), // 'asap' or 'few-days'
  adults: integer("adults").notNull(),
  children: integer("children").default(0),
  rentalPeriod: varchar("rental_period").notNull(), // '6-months', '1-year', '2-years'
  
  // Lifestyle
  hasPets: boolean("has_pets").notNull(),
  petDetails: varchar("pet_details"),
  smokes: boolean("smokes").notNull(),
  
  // Employment
  occupation: varchar("occupation").notNull(), // 'employed', 'self-employed', 'unemployed', 'student', 'retired'
  hasTaxReturns: boolean("has_tax_returns"), // Only for self-employed
  
  // Financial
  annualIncome: decimal("annual_income", { precision: 10, scale: 2 }).notNull(),
  hasCCJIVA: boolean("has_ccj_iva").notNull(),
  hasAdverseMedia: boolean("has_adverse_media"),
  hasGuarantor: boolean("has_guarantor").notNull(),
  
  // Contact preferences
  contactTime: varchar("contact_time"),
  contactMethod: varchar("contact_method"),
  additionalNotes: text("additional_notes"),
  
  // Property selection (multiple properties supported)
  property: text("property").array().notNull(),
  
  // Status management
  status: varchar("status").default("new").notNull(), // 'new', 'contacted', 'viewing-arranged', 'approved', 'rejected'
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Property listings table
export const propertyListings = pgTable("property_listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  price: varchar("price").notNull(),
  beds: varchar("beds").notNull(),
  thumbnail: text("thumbnail").notNull(),
  url: text("url").notNull().unique(),
  description: text("description").notNull(),
  isActive: boolean("is_active").default(true),
  scrapedAt: timestamp("scraped_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Internal notes table
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  applicationId: integer("application_id").references(() => applications.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const applicationsRelations = relations(applications, ({ many }) => ({
  notes: many(notes),
}));

export const notesRelations = relations(notes, ({ one }) => ({
  application: one(applications, {
    fields: [notes.applicationId],
    references: [applications.id],
  }),
  user: one(users, {
    fields: [notes.userId],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  notes: many(notes),
}));

// Schemas for validation
export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  status: true,
}).extend({
  // Override the decimal field to accept numbers
  annualIncome: z.number().min(0, "Annual income must be a positive number")
});

export const updateApplicationStatusSchema = z.object({
  status: z.enum(['new', 'contacted', 'viewing-arranged', 'approved', 'rejected']),
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  createdAt: true,
  userId: true,
});

export const upsertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type Application = typeof applications.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type UpdateApplicationStatus = z.infer<typeof updateApplicationStatusSchema>;
export type Note = typeof notes.$inferSelect;
export type InsertNote = z.infer<typeof insertNoteSchema>;

// System settings table for feature toggles
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key").notNull().unique(), // 'ai_chatbot_enabled', 'traditional_form_enabled', etc.
  value: jsonb("value").notNull(), // Flexible JSON for any setting type
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
  updatedBy: varchar("updated_by").references(() => users.id),
});

// Letting rules table for income calculations and requirements
export const lettingRules = pgTable("letting_rules", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(), // 'income_multiplier', 'self_employed_tax_returns', etc.
  ruleType: varchar("rule_type").notNull(), // 'calculation', 'requirement', 'threshold'
  config: jsonb("config").notNull(), // Flexible JSON for rule configuration
  isActive: boolean("is_active").default(true),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  updatedBy: varchar("updated_by").references(() => users.id),
});

// Conversation transcripts table for AI chat history
export const conversationTranscripts = pgTable("conversation_transcripts", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id").notNull(), // Unique session identifier
  applicationId: integer("application_id").references(() => applications.id), // Linked when application is submitted
  messages: jsonb("messages").notNull(), // Array of {role, content, timestamp}
  metadata: jsonb("metadata"), // Session info, IP, user agent, etc.
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Bot suggestions table for AI-learned rules pending approval
export const botSuggestions = pgTable("bot_suggestions", {
  id: serial("id").primaryKey(),
  suggestionType: varchar("suggestion_type").notNull(), // 'new_rule', 'rule_modification', 'pattern_detected'
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  suggestedConfig: jsonb("suggested_config").notNull(), // The proposed rule/change
  confidence: decimal("confidence", { precision: 5, scale: 2 }), // AI confidence score 0-100
  evidenceData: jsonb("evidence_data"), // Supporting data/patterns that led to suggestion
  status: varchar("status").default("pending").notNull(), // 'pending', 'approved', 'rejected'
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations for new tables
export const conversationTranscriptsRelations = relations(conversationTranscripts, ({ one }) => ({
  application: one(applications, {
    fields: [conversationTranscripts.applicationId],
    references: [applications.id],
  }),
}));

export const botSuggestionsRelations = relations(botSuggestions, ({ one }) => ({
  reviewer: one(users, {
    fields: [botSuggestions.reviewedBy],
    references: [users.id],
  }),
}));

// Schemas for validation
export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertLettingRuleSchema = createInsertSchema(lettingRules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertConversationTranscriptSchema = createInsertSchema(conversationTranscripts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBotSuggestionSchema = createInsertSchema(botSuggestions).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});

export const updateBotSuggestionSchema = z.object({
  status: z.enum(['pending', 'approved', 'rejected']),
  reviewNotes: z.string().optional(),
});

// Types for new tables
export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
export type LettingRule = typeof lettingRules.$inferSelect;
export type InsertLettingRule = z.infer<typeof insertLettingRuleSchema>;
export type ConversationTranscript = typeof conversationTranscripts.$inferSelect;
export type InsertConversationTranscript = z.infer<typeof insertConversationTranscriptSchema>;
export type BotSuggestion = typeof botSuggestions.$inferSelect;
export type InsertBotSuggestion = z.infer<typeof insertBotSuggestionSchema>;
export type UpdateBotSuggestion = z.infer<typeof updateBotSuggestionSchema>;

// Extended application type with notes
export type ApplicationWithNotes = Application & {
  notes: (Note & { user: User })[];
};

// Extended application type with conversation transcript
export type ApplicationWithTranscript = Application & {
  notes: (Note & { user: User })[];
  transcript?: ConversationTranscript;
};
